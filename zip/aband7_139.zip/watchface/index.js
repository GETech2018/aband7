﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 16;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 15;
        let normal_distance_TextRotate_dot_width = 9;
        let normal_calorie_icon_img = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 16;
        let normal_step_icon_img = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 16;
        let normal_step_TextRotate_error_img_width = 16;
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 11;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 11;
        let normal_battery_TextRotate_error_img_width = 11;
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 16;
        let normal_heart_rate_TextRotate_error_img_width = 16;
        let normal_heart_rate_image_progress_img_level = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 16;
        let normal_day_TextRotate_error_img_width = 16;
        let normal_date_img_date_month_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 26;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 26;
        let normal_digital_clock_img_time_AmPm = ''
        let idle_background_bg_img = ''
        let idle_step_icon_img = ''
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 16;
        let idle_step_TextRotate_error_img_width = 16;
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 11;
        let idle_battery_TextRotate_unit = null;
        let idle_battery_TextRotate_unit_width = 11;
        let idle_battery_TextRotate_error_img_width = 11;
        let idle_heart_rate_TextRotate = new Array(3);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 16;
        let idle_heart_rate_TextRotate_error_img_width = 16;
        let idle_heart_rate_image_progress_img_level = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 16;
        let idle_day_TextRotate_error_img_width = 16;
        let idle_date_img_date_month_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 26;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 26;
        let idle_digital_clock_img_time_AmPm = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_dot = 'ACT_Dot.png'


//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 7

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }
            hmUI.showToast({text: "Color " + parseInt(colornumber) });

          normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
            
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

        // Activity select
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 3
        let cc = 0

        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }

    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Steps'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Calorie'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Distance'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //steps
        function UpdateBackgroundOne(){


        normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_TextRotate_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, '0_Empty.png');
            normal_dot = "0_Empty.png";
                

       normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_TextRotate_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers
      

  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);            
            normal_step_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

const result = hmSetting.setScreenOff()


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Calorie
        function UpdateBackgroundTwo(){

        normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_TextRotate_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, '0_Empty.png');
            normal_dot = "0_Empty.png";

                

       normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_calorie_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers
      

  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_TextRotate_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers

  const result = hmSetting.setScreenOff()

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Distance
        function UpdateBackgroundThree(){
        normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_distance_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Act_KM.png');
            normal_dot = "ACT_Dot.png";
            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Act_MI.png');
            };
                

       normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_TextRotate_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers
      

  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_TextRotate_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers

const result = hmSetting.setScreenOff()

        }

//////////////////////////////////////////////////////////////////////////////////////////////////



        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 2,
              y: 189,
              src: 'icon_distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 34,
              // y: 278,
              // font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 90,
              // unit_en: 'Act_KM.png',
              // imperial_unit_en: 'Act_MI.png',
              // dot_image: 'ACT_Dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 34,
                center_y: 278,
                pos_x: 34,
                pos_y: 278,
                angle: 90,
                src: 'Act_Font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              center_x: 34,
              center_y: 278,
              pos_x: 34,
              pos_y: 278,
              angle: 90,
              src: 'Act_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Act_MI.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 4,
              y: 189,
              src: 'icon_calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 33,
              // y: 287,
              // font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 4,
              // angle: 90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 33,
                center_y: 287,
                pos_x: 33,
                pos_y: 287,
                angle: 90,
                src: 'Act_Font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 8,
              y: 196,
              src: 'icon_Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 33,
              // y: 287,
              // font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 4,
              // angle: 90,
              // invalid_image: 'Act_Font_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 33,
                center_y: 287,
                pos_x: 33,
                pos_y: 287,
                angle: 90,
                src: 'Act_Font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 154,
              y: 9,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 164,
              y: 234,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 39,
              y: 173,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 185,
              // y: 184,
              // font_array: ["Act_small_Font_0.png","Act_small_Font_1.png","Act_small_Font_2.png","Act_small_Font_3.png","Act_small_Font_4.png","Act_small_Font_5.png","Act_small_Font_6.png","Act_small_Font_7.png","Act_small_Font_8.png","Act_small_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 4,
              // angle: 90,
              // unit_en: 'Batt_symbo.png',
              // invalid_image: 'Act_small_Font_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'Act_small_Font_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'Act_small_Font_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'Act_small_Font_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'Act_small_Font_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'Act_small_Font_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'Act_small_Font_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'Act_small_Font_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'Act_small_Font_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'Act_small_Font_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'Act_small_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 185,
                center_y: 184,
                pos_x: 185,
                pos_y: 184,
                angle: 90,
                src: 'Act_small_Font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              center_x: 185,
              center_y: 184,
              pos_x: 185,
              pos_y: 184,
              angle: 90,
              src: 'Batt_symbo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 154,
              // y: 245,
              // font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 9,
              // angle: 90,
              // invalid_image: 'Act_Font_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 154,
                center_y: 245,
                pos_x: 154,
                pos_y: 245,
                angle: 90,
                src: 'Act_Font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 125,
              y: 278,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'week_Circle.png',
              center_x: 99,
              center_y: 92,
              posX: 66,
              posY: 67,
              start_angle: 247,
              end_angle: -112,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -100,
              day_startY: -100,
              day_sc_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              day_tc_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              day_en_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 51,
              y: 57,
              src: 'FG_week.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 101,
              // y: 66,
              // font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 6,
              // angle: 0,
              // invalid_image: 'Act_Font_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 101,
                center_y: 66,
                pos_x: 101,
                pos_y: 66,
                angle: 0,
                src: 'Act_Font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);
            timeNaw.addEventListener(timeNaw.event.DAYCHANGE, function() {
              text_update();
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 81,
              month_startY: 95,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 338,
              font_array: ["Act_small_Font_0.png","Act_small_Font_1.png","Act_small_Font_2.png","Act_small_Font_3.png","Act_small_Font_4.png","Act_small_Font_5.png","Act_small_Font_6.png","Act_small_Font_7.png","Act_small_Font_8.png","Act_small_Font_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Weather_symbo2.png',
              unit_tc: 'Weather_symbo2.png',
              unit_en: 'Weather_symbo2.png',
              negative_image: 'Weather_symbo1.png',
              invalid_image: 'Weather_symbo1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 157,
              y: 303,
              image_array: ["Weather_small_01.png","Weather_small_02.png","Weather_small_03.png","Weather_small_04.png","Weather_small_05.png","Weather_small_06.png","Weather_small_07.png","Weather_small_08.png","Weather_small_09.png","Weather_small_10.png","Weather_small_11.png","Weather_small_12.png","Weather_small_13.png","Weather_small_14.png","Weather_small_15.png","Weather_small_16.png","Weather_small_17.png","Weather_small_18.png","Weather_small_19.png","Weather_small_20.png","Weather_small_21.png","Weather_small_22.png","Weather_small_23.png","Weather_small_24.png","Weather_small_25.png","Weather_small_26.png","Weather_small_27.png","Weather_small_28.png","Weather_small_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 107,
              y: 342,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 115,
              // y: 186,
              // font_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 8,
              // angle: 90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'Time_font_01.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'Time_font_02.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'Time_font_03.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'Time_font_04.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'Time_font_05.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'Time_font_06.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'Time_font_07.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'Time_font_08.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'Time_font_09.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'Time_font_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 115,
                center_y: 186,
                pos_x: 115,
                pos_y: 186,
                angle: 90,
                src: 'Time_font_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            timeNaw.addEventListener(timeNaw.event.MINUTEEND, function() {
              text_update();
            });

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 115,
              // y: 264,
              // font_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 8,
              // angle: 90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'Time_font_01.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'Time_font_02.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'Time_font_03.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'Time_font_04.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'Time_font_05.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'Time_font_06.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'Time_font_07.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'Time_font_08.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'Time_font_09.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'Time_font_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 115,
                center_y: 264,
                pos_x: 115,
                pos_y: 264,
                angle: 90,
                src: 'Time_font_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 35,
              am_y: 201,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 35,
              pm_y: 201,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'main7.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 8,
              y: 196,
              src: 'icon_Step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 33,
              // y: 287,
              // font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 4,
              // angle: 90,
              // invalid_image: 'Act_Font_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 33,
                center_y: 287,
                pos_x: 33,
                pos_y: 287,
                angle: 90,
                src: 'Act_Font_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 154,
              y: 9,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 164,
              y: 234,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 39,
              y: 173,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 185,
              // y: 184,
              // font_array: ["Act_small_Font_0.png","Act_small_Font_1.png","Act_small_Font_2.png","Act_small_Font_3.png","Act_small_Font_4.png","Act_small_Font_5.png","Act_small_Font_6.png","Act_small_Font_7.png","Act_small_Font_8.png","Act_small_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 4,
              // angle: 90,
              // unit_en: 'Batt_symbo.png',
              // invalid_image: 'Act_small_Font_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'Act_small_Font_0.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'Act_small_Font_1.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'Act_small_Font_2.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'Act_small_Font_3.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'Act_small_Font_4.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'Act_small_Font_5.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'Act_small_Font_6.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'Act_small_Font_7.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'Act_small_Font_8.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'Act_small_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 185,
                center_y: 184,
                pos_x: 185,
                pos_y: 184,
                angle: 90,
                src: 'Act_small_Font_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              center_x: 185,
              center_y: 184,
              pos_x: 185,
              pos_y: 184,
              angle: 90,
              src: 'Batt_symbo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 154,
              // y: 245,
              // font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 9,
              // angle: 90,
              // invalid_image: 'Act_Font_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 154,
                center_y: 245,
                pos_x: 154,
                pos_y: 245,
                angle: 90,
                src: 'Act_Font_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 125,
              y: 278,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'week_Circle.png',
              center_x: 99,
              center_y: 92,
              posX: 66,
              posY: 67,
              start_angle: 247,
              end_angle: -112,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -100,
              day_startY: -100,
              day_sc_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              day_tc_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              day_en_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 51,
              y: 57,
              src: 'FG_week.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 101,
              // y: 66,
              // font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 6,
              // angle: 0,
              // invalid_image: 'Act_Font_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 101,
                center_y: 66,
                pos_x: 101,
                pos_y: 66,
                angle: 0,
                src: 'Act_Font_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 81,
              month_startY: 95,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 338,
              font_array: ["Act_small_Font_0.png","Act_small_Font_1.png","Act_small_Font_2.png","Act_small_Font_3.png","Act_small_Font_4.png","Act_small_Font_5.png","Act_small_Font_6.png","Act_small_Font_7.png","Act_small_Font_8.png","Act_small_Font_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Weather_symbo2.png',
              unit_tc: 'Weather_symbo2.png',
              unit_en: 'Weather_symbo2.png',
              negative_image: 'Weather_symbo1.png',
              invalid_image: 'Weather_symbo1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 157,
              y: 303,
              image_array: ["Weather_small_01.png","Weather_small_02.png","Weather_small_03.png","Weather_small_04.png","Weather_small_05.png","Weather_small_06.png","Weather_small_07.png","Weather_small_08.png","Weather_small_09.png","Weather_small_10.png","Weather_small_11.png","Weather_small_12.png","Weather_small_13.png","Weather_small_14.png","Weather_small_15.png","Weather_small_16.png","Weather_small_17.png","Weather_small_18.png","Weather_small_19.png","Weather_small_20.png","Weather_small_21.png","Weather_small_22.png","Weather_small_23.png","Weather_small_24.png","Weather_small_25.png","Weather_small_26.png","Weather_small_27.png","Weather_small_28.png","Weather_small_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 107,
              y: 342,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 115,
              // y: 186,
              // font_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 8,
              // angle: 90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'Time_font_01.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'Time_font_02.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'Time_font_03.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'Time_font_04.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'Time_font_05.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'Time_font_06.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'Time_font_07.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'Time_font_08.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'Time_font_09.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'Time_font_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 115,
                center_y: 186,
                pos_x: 115,
                pos_y: 186,
                angle: 90,
                src: 'Time_font_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 115,
              // y: 264,
              // font_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 8,
              // angle: 90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'Time_font_01.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'Time_font_02.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'Time_font_03.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'Time_font_04.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'Time_font_05.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'Time_font_06.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'Time_font_07.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'Time_font_08.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'Time_font_09.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'Time_font_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 115,
                center_y: 264,
                pos_x: 115,
                pos_y: 264,
                angle: 90,
                src: 'Time_font_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 35,
              am_y: 201,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 35,
              pm_y: 201,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 76,
              y: 273,
              w: 36,
              h: 36,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 76,
              y: 200,
              w: 36,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 36,
              y: 167,
              w: 25,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 102,
              y: 338,
              w: 30,
              h: 28,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 151,
              y: 307,
              w: 38,
              h: 56,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 129,
              y: 172,
              w: 30,
              h: 28,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 129,
              y: 214,
              w: 32,
              h: 79,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 66,
              y: 52,
              w: 68,
              h: 68,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});
/////////////////////////////////////////////////////////////////////////////////

		// GO ACTIVITY
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 2,
              y: 326,
              w: 40,
              h: 40,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'SportListScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});


            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 7,
              y: 230,
              w: 27,
              h: 87,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            function text_update() {

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset + 2 * (normal_distance_rotate_string.length - 1);
                  img_offset -= normal_distance_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 34 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width + 2;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 34 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_dot);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width + 2;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 34 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_img_width * normal_calorie_rotate_string.length;
                  normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_posOffset + 4 * (normal_calorie_rotate_string.length - 1);
                  img_offset -= normal_calorie_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 33 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + 4 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 33 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_step_TextRotate[0].setProperty(hmUI.prop.POS_X, 33 - normal_step_TextRotate_error_img_width / 2);
                  normal_step_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Font_0.png');
                  normal_step_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + 4 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 185 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 185 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.POS_X, 185 - normal_battery_TextRotate_error_img_width / 2);
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_small_Font_0.png');
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + 9 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 154 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 9;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.POS_X, 154 - normal_heart_rate_TextRotate_error_img_width / 2);
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Font_0.png');
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate TIME');
              let valueDay = timeNaw.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  normal_day_TextRotate_posOffset = normal_day_TextRotate_posOffset + 6 * (normal_day_rotate_string.length - 1);
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 101 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + 6;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_day_TextRotate[0].setProperty(hmUI.prop.POS_X, 101 - normal_day_TextRotate_error_img_width / 2);
                  normal_day_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Font_0.png');
                  normal_day_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 115 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + 8;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 115 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + 8;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  idle_step_TextRotate_posOffset = idle_step_TextRotate_posOffset + 4 * (idle_step_rotate_string.length - 1);
                  img_offset -= idle_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 33 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_step_TextRotate[0].setProperty(hmUI.prop.POS_X, 33 - idle_step_TextRotate_error_img_width / 2);
                  idle_step_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Font_0.png');
                  idle_step_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + 4 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 185 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 185 + img_offset);
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.POS_X, 185 - idle_battery_TextRotate_error_img_width / 2);
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_small_Font_0.png');
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_img_width * idle_heart_rate_rotate_string.length;
                  idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_posOffset + 9 * (idle_heart_rate_rotate_string.length - 1);
                  img_offset -= idle_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 154 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width + 9;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_heart_rate_TextRotate[0].setProperty(hmUI.prop.POS_X, 154 - idle_heart_rate_TextRotate_error_img_width / 2);
                  idle_heart_rate_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Font_0.png');
                  idle_heart_rate_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_day_TextRotate_posOffset = idle_day_TextRotate_img_width * idle_day_rotate_string.length;
                  idle_day_TextRotate_posOffset = idle_day_TextRotate_posOffset + 6 * (idle_day_rotate_string.length - 1);
                  img_offset -= idle_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 101 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width + 6;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_day_TextRotate[0].setProperty(hmUI.prop.POS_X, 101 - idle_day_TextRotate_error_img_width / 2);
                  idle_day_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Font_0.png');
                  idle_day_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 115 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + 8;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 115 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + 8;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_update();
              }),
            });

/////////////////Show element at the first time //////////

if (cc==0) {
  cc = 1
        normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_TextRotate_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, '0_Empty.png');
            normal_dot = "0_Empty.png";
                

       normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_TextRotate_ASCIIARRAY[0] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = '0_Empty.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = '0_Empty.png';  // set of images with numbers
      

  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);            
            normal_step_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

 
}
//////////////////////////////////////////////////////////////////////////////////////////////////
 
           // Element on/off
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 5,
              y: 193,
              text: '',
              w: 37,
              h: 37,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////

          // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 6,
              y: 10,
              text: '',
              w: 30,
              h: 40,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end

    
//////////////////////////////////////////////////////////////////////////////////////////////////




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}