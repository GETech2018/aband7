﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_battery_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 254,
              font_array: ["nrs_widgets_00.png","nrs_widgets_01.png","nrs_widgets_02.png","nrs_widgets_03.png","nrs_widgets_04.png","nrs_widgets_05.png","nrs_widgets_06.png","nrs_widgets_07.png","nrs_widgets_08.png","nrs_widgets_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'nrs_widgets_10.png',
              unit_tc: 'nrs_widgets_10.png',
              unit_en: 'nrs_widgets_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 276,
              image_array: ["bateria_progreso_circular_01.png","bateria_progreso_circular_02.png","bateria_progreso_circular_03.png","bateria_progreso_circular_04.png","bateria_progreso_circular_05.png","bateria_progreso_circular_06.png","bateria_progreso_circular_07.png","bateria_progreso_circular_08.png","bateria_progreso_circular_09.png","bateria_progreso_circular_10.png","bateria_progreso_circular_11.png","bateria_progreso_circular_12.png","bateria_progreso_circular_13.png","bateria_progreso_circular_14.png","bateria_progreso_circular_15.png","bateria_progreso_circular_16.png","bateria_progreso_circular_17.png","bateria_progreso_circular_18.png","bateria_progreso_circular_19.png","bateria_progreso_circular_20.png","bateria_progreso_circular_21.png","bateria_progreso_circular_22.png","bateria_progreso_circular_23.png","bateria_progreso_circular_24.png"],
              image_length: 24,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Reloj_hora.png',
              hour_centerX: 51,
              hour_centerY: 49,
              hour_posX: 42,
              hour_posY: 42,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Reloj_min_seg.png',
              minute_centerX: 144,
              minute_centerY: 49,
              minute_posX: 42,
              minute_posY: 42,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Reloj_min_seg.png',
              second_centerX: 51,
              second_centerY: 317,
              second_posX: 42,
              second_posY: 42,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 88,
              am_y: 175,
              am_sc_path: 'hora_am.png',
              am_en_path: 'hora_am.png',
              pm_x: 88,
              pm_y: 175,
              pm_sc_path: 'hora_pm.png',
              pm_en_path: 'hora_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 43,
              hour_startY: 98,
              hour_array: ["nrs_widgets_00.png","nrs_widgets_01.png","nrs_widgets_02.png","nrs_widgets_03.png","nrs_widgets_04.png","nrs_widgets_05.png","nrs_widgets_06.png","nrs_widgets_07.png","nrs_widgets_08.png","nrs_widgets_09.png"],
              hour_zero: 0,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 134,
              minute_startY: 98,
              minute_array: ["nrs_widgets_00.png","nrs_widgets_01.png","nrs_widgets_02.png","nrs_widgets_03.png","nrs_widgets_04.png","nrs_widgets_05.png","nrs_widgets_06.png","nrs_widgets_07.png","nrs_widgets_08.png","nrs_widgets_09.png"],
              minute_zero: 0,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 44,
              second_startY: 254,
              second_array: ["nrs_widgets_00.png","nrs_widgets_01.png","nrs_widgets_02.png","nrs_widgets_03.png","nrs_widgets_04.png","nrs_widgets_05.png","nrs_widgets_06.png","nrs_widgets_07.png","nrs_widgets_08.png","nrs_widgets_09.png"],
              second_zero: 0,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 276,
              image_array: ["bateria_progreso_circular_01.png","bateria_progreso_circular_02.png","bateria_progreso_circular_03.png","bateria_progreso_circular_04.png","bateria_progreso_circular_05.png","bateria_progreso_circular_06.png","bateria_progreso_circular_07.png","bateria_progreso_circular_08.png","bateria_progreso_circular_09.png","bateria_progreso_circular_10.png","bateria_progreso_circular_11.png","bateria_progreso_circular_12.png","bateria_progreso_circular_13.png","bateria_progreso_circular_14.png","bateria_progreso_circular_15.png","bateria_progreso_circular_16.png","bateria_progreso_circular_17.png","bateria_progreso_circular_18.png","bateria_progreso_circular_19.png","bateria_progreso_circular_20.png","bateria_progreso_circular_21.png","bateria_progreso_circular_22.png","bateria_progreso_circular_23.png","bateria_progreso_circular_24.png"],
              image_length: 24,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'AOD_hora.png',
              hour_centerX: 51,
              hour_centerY: 49,
              hour_posX: 42,
              hour_posY: 42,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'AOD_hora.png',
              minute_centerX: 144,
              minute_centerY: 49,
              minute_posX: 42,
              minute_posY: 42,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'AOD_hora.png',
              second_centerX: 51,
              second_centerY: 317,
              second_posX: 42,
              second_posY: 42,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}