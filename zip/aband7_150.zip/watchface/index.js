﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_moon_image_progress_img_level = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_year = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 241,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 19,
              y: 72,
              font_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 72,
              font_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 23,
              y: 115,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'battery_percent.png',
              unit_tc: 'battery_percent.png',
              unit_en: 'battery_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 92,
              image_array: ["wind_01.png","wind_02.png","wind_03.png","wind_04.png","wind_05.png","wind_06.png","wind_07.png","wind_08.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 27,
              y: 92,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'meterspersecond.png',
              unit_tc: 'meterspersecond.png',
              unit_en: 'meterspersecond.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 7,
              y: 332,
              font_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'mi.png',
              imperial_unit_tc: 'mi.png',
              imperial_unit_en: 'mi.png',
              dot_image: 'decimal.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 8,
              y: 22,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 106,
              font_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'celsius2.png',
              unit_tc: 'celsius2.png',
              unit_en: 'celsius2.png',
              negative_image: 'negative.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 105,
              y: 97,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 7,
              y: 42,
              w: 130,
              h: 30,
              text_size: 20,
              char_space: 1,
              line_space: 0,
              color: 0xFF8AB4FF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 30,
              day_startY: 219,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 70,
              month_startY: 219,
              month_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 110,
              year_startY: 219,
              year_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              year_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              year_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 332,
              font_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 352,
              image_array: ["b_10.png","b_20.png","b_30.png","b_40.png","b_50.png","b_60.png","b_70.png","b_80.png","b_90.png","b_100.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 23,
              font_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'battery_percent.png',
              unit_tc: 'battery_percent.png',
              unit_en: 'battery_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 7,
              image_array: ["b_10.png","b_20.png","b_30.png","b_40.png","b_50.png","b_60.png","b_70.png","b_80.png","b_90.png","b_100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 5,
              hour_startY: 156,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 105,
              minute_startY: 156,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 148,
              y: 51,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 136,
              day_startY: 219,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 95,
              month_startY: 219,
              month_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 28,
              year_startY: 219,
              year_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              year_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              year_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 5,
              hour_startY: 156,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 105,
              minute_startY: 156,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 153,
              w: 85,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 153,
              w: 85,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 90,
              w: 90,
              h: 49,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 325,
              w: 194,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 7,
              y: 42,
              w: 135,
              h: 44,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}