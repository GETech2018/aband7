﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: '00-fondo2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Analog_hora.png',
              hour_centerX: 96,
              hour_centerY: 96,
              hour_posX: 97,
              hour_posY: 97,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'analog_min.png',
              minute_centerX: 96,
              minute_centerY: 96,
              minute_posX: 97,
              minute_posY: 97,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Analog_seg.png',
              second_centerX: 96,
              second_centerY: 96,
              second_posX: 97,
              second_posY: 97,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 11,
              hour_startY: 182,
              hour_array: ["Hora_nros00.png","Hora_nros01.png","Hora_nros02.png","Hora_nros03.png","Hora_nros04.png","Hora_nros05.png","Hora_nros06.png","Hora_nros07.png","Hora_nros08.png","Hora_nros09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 49,
              minute_startY: 243,
              minute_array: ["Minuros_nros00.png","Minuros_nros01.png","Minuros_nros02.png","Minuros_nros03.png","Minuros_nros04.png","Minuros_nros05.png","Minuros_nros06.png","Minuros_nros07.png","Minuros_nros08.png","Minuros_nros09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 87,
              second_startY: 304,
              second_array: ["segundos_nros_00.png","segundos_nros_01.png","segundos_nros_02.png","segundos_nros_03.png","segundos_nros_04.png","segundos_nros_05.png","segundos_nros_06.png","segundos_nros_07.png","segundos_nros_08.png","segundos_nros_09.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'AOD_hora.png',
              hour_centerX: 96,
              hour_centerY: 96,
              hour_posX: 97,
              hour_posY: 97,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'AOD_min.png',
              minute_centerX: 96,
              minute_centerY: 96,
              minute_posX: 97,
              minute_posY: 97,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'AOD_seg.png',
              second_centerX: 96,
              second_centerY: 96,
              second_posX: 97,
              second_posY: 97,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 11,
              hour_startY: 182,
              hour_array: ["AOD_nros_00.png","AOD_nros_01.png","AOD_nros_02.png","AOD_nros_03.png","AOD_nros_04.png","AOD_nros_05.png","AOD_nros_06.png","AOD_nros_07.png","AOD_nros_08.png","AOD_nros_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 49,
              minute_startY: 243,
              minute_array: ["AOD_nros_00.png","AOD_nros_01.png","AOD_nros_02.png","AOD_nros_03.png","AOD_nros_04.png","AOD_nros_05.png","AOD_nros_06.png","AOD_nros_07.png","AOD_nros_08.png","AOD_nros_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 87,
              second_startY: 304,
              second_array: ["AOD_nros_00.png","AOD_nros_01.png","AOD_nros_02.png","AOD_nros_03.png","AOD_nros_04.png","AOD_nros_05.png","AOD_nros_06.png","AOD_nros_07.png","AOD_nros_08.png","AOD_nros_09.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}