try {
(()=>{
    const e = __$$hmAppManager$$__.currentApp;
    const o = e.current,
        {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)), e.__globals__),
        n = Logger.getLogger("dragynrainV1");

    // ==========================================================================
    // GENERATED FROM design.py - DO NOT EDIT MANUALLY
    // ==========================================================================
    // Screen dimensions
    const SCREEN_W = 194;
    const SCREEN_H = 368;
    // Theme management with persistence
    const THEME_COUNT = 30;
    const THEME_KEY = 'theme';
    let currentTheme = 0;
    let bgWidget = null;

    // Load saved theme on startup
    function loadTheme() {
        try {
            const saved = hmFS.SysProGetChars(THEME_KEY);
            if (saved) {
                const parsed = parseInt(saved, 10);
                if (!isNaN(parsed) && parsed >= 0 && parsed < THEME_COUNT) {
                    currentTheme = parsed;
                }
            }
        } catch (e) {
            // Use default theme if load fails
        }
    }

    // Save theme when changed
    function saveTheme() {
        try {
            hmFS.SysProSetChars(THEME_KEY, currentTheme.toString());
        } catch (e) {
            // Ignore save errors
        }
    }
    // Time layout
    const TIME_Y = 96;
    const TIME_DIGIT_W = 43;
    const TIME_DIGIT_H = 118;
    const TIME_COLON_X = 86;
    const TIME_COLON_W = 22;
    const TIME_MINUTE_X = 108;
    // Stat display positions
    const STAT_Y = [275, 306, 337];
    const STAT_ICON_X = 46;
    const STAT_VALUE_OFFSET_X = 37;
    const STAT_VALUE_OFFSET_Y = 2;
    const STAT_VALUE_W = 110;
    // Edit zone layout (full-screen for easy tapping)
    const EDIT_SLOT_X = 10;
    const EDIT_SLOT_Y = [0, 123, 245];
    const EDIT_SLOT_W = 174;
    const EDIT_SLOT_H = [123, 122, 123];
    // Edit mode tips
    const TIPS_W = 100;
    const TIPS_OFFSET_X = 37;
    const TIPS_OFFSET_Y = 95;
    // ==========================================================================
    // END GENERATED CONFIG
    // ==========================================================================

    // Asset arrays
    const cutoutTimeArray = ["tc_0.png","tc_1.png","tc_2.png","tc_3.png","tc_4.png","tc_5.png","tc_6.png","tc_7.png","tc_8.png","tc_9.png"];
    const whiteDateArray = ["t0_s0.png","t0_s1.png","t0_s2.png","t0_s3.png","t0_s4.png","t0_s5.png","t0_s6.png","t0_s7.png","t0_s8.png","t0_s9.png"];
    const whiteWeekArray = ["t0_mon.png","t0_tue.png","t0_wed.png","t0_thu.png","t0_fri.png","t0_sat.png","t0_sun.png"];
    const numArray = ["n0.png","n1.png","n2.png","n3.png","n4.png","n5.png","n6.png","n7.png","n8.png","n9.png"];

    // Edit group widgets (for reading selection)
    let editGroups = [];
    // Map edit_type to data_type (they are different enums in ZeppOS!)
    const EDIT_TO_DATA = {
        [hmUI.edit_type.STEP]: hmUI.data_type.STEP,
        [hmUI.edit_type.HEART]: hmUI.data_type.HEART,
        [hmUI.edit_type.CAL]: hmUI.data_type.CAL,
        [hmUI.edit_type.PAI_DAILY]: hmUI.data_type.PAI_DAILY,
        [hmUI.edit_type.DISTANCE]: hmUI.data_type.DISTANCE,
        [hmUI.edit_type.SPO2]: hmUI.data_type.SPO2,
        [hmUI.edit_type.STRESS]: hmUI.data_type.STRESS,
        [hmUI.edit_type.STAND]: hmUI.data_type.STAND,
        [hmUI.edit_type.BATTERY]: hmUI.data_type.BATTERY,
    };

    // Data type configurations - maps data_type to widget config
    const DATA_CONFIG = {
        [hmUI.data_type.STEP]: { icon: 'ic_steps.png', unit: null },
        [hmUI.data_type.HEART]: { icon: 'ic_heart.png', unit: null },
        [hmUI.data_type.CAL]: { icon: 'ic_calories.png', unit: null },
        [hmUI.data_type.PAI_DAILY]: { icon: 'ic_pai.png', unit: null },
        [hmUI.data_type.DISTANCE]: { icon: 'ic_distance.png', unit: 'km.png', imperial: 'mi.png', dot: 'dot.png' },
        [hmUI.data_type.SPO2]: { icon: 'ic_spo2.png', unit: 'percent.png' },
        [hmUI.data_type.STRESS]: { icon: 'ic_stress.png', unit: null },
        [hmUI.data_type.STAND]: { icon: 'ic_stand.png', unit: null },
        [hmUI.data_type.BATTERY]: { icon: 'ic_battery.png', unit: 'percent.png' },
    };

    // Default types for each slot
    const DEFAULT_TYPES = [hmUI.edit_type.STEP, hmUI.edit_type.DISTANCE, hmUI.edit_type.BATTERY];

    // Available types for selection
    // NOTE: Do NOT add title_* properties to standard edit types - the system provides them automatically.
    const OPTIONAL_TYPES = [
        { type: hmUI.edit_type.STEP, preview: 'preview_steps.png' },
        { type: hmUI.edit_type.HEART, preview: 'preview_heart.png' },
        { type: hmUI.edit_type.CAL, preview: 'preview_calories.png' },
        { type: hmUI.edit_type.PAI_DAILY, preview: 'preview_pai.png' },
        { type: hmUI.edit_type.DISTANCE, preview: 'preview_distance.png' },
        { type: hmUI.edit_type.SPO2, preview: 'preview_spo2.png' },
        { type: hmUI.edit_type.STRESS, preview: 'preview_stress.png' },
        { type: hmUI.edit_type.STAND, preview: 'preview_stand.png' },
        { type: hmUI.edit_type.BATTERY, preview: 'preview_battery.png' },
    ];

    function switchTheme(direction) {
        currentTheme = direction > 0
            ? (currentTheme + 1) % THEME_COUNT
            : (currentTheme - 1 + THEME_COUNT) % THEME_COUNT;
        bgWidget.setProperty(hmUI.prop.SRC, 'bg' + currentTheme + '.png');
        saveTheme();
    }

    function createDataWidget(dataType, yPos) {
        const config = DATA_CONFIG[dataType];
        if (!config) return;

        // Icon - only in normal mode (edit mode has its own preview)
        hmUI.createWidget(hmUI.widget.IMG, {
            x: STAT_ICON_X, y: yPos,
            src: config.icon,
            show_level: hmUI.show_level.ONLY_NORMAL
        });

        // Value - only in normal mode
        const valueConfig = {
            x: STAT_ICON_X + STAT_VALUE_OFFSET_X, y: yPos + STAT_VALUE_OFFSET_Y,
            w: STAT_VALUE_W,
            font_array: numArray,
            padding: false, h_space: 1, align_h: hmUI.align.LEFT,
            type: dataType,
            show_level: hmUI.show_level.ONLY_NORMAL
        };

        if (config.unit) {
            valueConfig.unit_sc = config.unit;
            valueConfig.unit_tc = config.unit;
            valueConfig.unit_en = config.unit;
        }
        if (config.imperial) {
            valueConfig.imperial_unit_sc = config.imperial;
            valueConfig.imperial_unit_tc = config.imperial;
            valueConfig.imperial_unit_en = config.imperial;
        }
        if (config.dot) {
            valueConfig.dot_image = config.dot;
        }

        hmUI.createWidget(hmUI.widget.TEXT_IMG, valueConfig);
    }
    o.module = DeviceRuntimeCore.WatchFace({
        onInit() {
            n.log("init");
            loadTheme();
        },

        build() {
            // Reset editGroups array (build() is called again after exiting edit mode)
            editGroups = [];

            // Background - only in normal mode (edit mode shows mask)
            bgWidget = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0, y: 0, w: SCREEN_W, h: SCREEN_H,
                src: 'bg' + currentTheme + '.png',
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            // Weather icon
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 20, y: 8,
                image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
                image_length: 29,
                type: hmUI.data_type.WEATHER,
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            // Temperature
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 100, y: 25, w: 89,
                font_array: ["temp0.png","temp1.png","temp2.png","temp3.png","temp4.png","temp5.png","temp6.png","temp7.png","temp8.png","temp9.png"],
                negative_image: 'neg.png',
                unit_sc: 'deg.png', unit_tc: 'deg.png', unit_en: 'deg.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            // Time (gradient cutout)
            hmUI.createWidget(hmUI.widget.IMG_TIME, {
                hour_startX: 0, hour_startY: TIME_Y,
                hour_array: cutoutTimeArray,
                hour_zero: 1, hour_space: 0, hour_align: hmUI.align.LEFT,
                minute_startX: TIME_MINUTE_X, minute_startY: TIME_Y,
                minute_array: cutoutTimeArray,
                minute_zero: 1, minute_space: 0, minute_follow: 0, minute_align: hmUI.align.LEFT,
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            hmUI.createWidget(hmUI.widget.IMG, {
                x: TIME_COLON_X, y: TIME_Y,
                src: 'tc_colon.png',
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            // Date + Weekday
            hmUI.createWidget(hmUI.widget.IMG_DATE, {
                month_startX: 94, month_startY: 222,
                month_sc_array: whiteDateArray, month_tc_array: whiteDateArray, month_en_array: whiteDateArray,
                month_zero: 1, month_space: 0, month_align: hmUI.align.LEFT, month_is_character: false,
                day_startX: 144, day_startY: 222,
                day_sc_array: whiteDateArray, day_tc_array: whiteDateArray, day_en_array: whiteDateArray,
                day_zero: 1, day_space: 0, day_align: hmUI.align.LEFT, day_is_character: false,
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            hmUI.createWidget(hmUI.widget.IMG, {
                x: 130, y: 225,
                src: 'slash.png',
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                x: 14, y: 222,
                week_en: whiteWeekArray, week_tc: whiteWeekArray, week_sc: whiteWeekArray,
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            // ===== EDIT MODE BACKGROUND =====
            // Solid black background only visible in edit mode
            hmUI.createWidget(hmUI.widget.IMG, {
                x: 0, y: 0, w: SCREEN_W, h: SCREEN_H,
                src: 'edit_bg.png',
                show_level: hmUI.show_level.ONLY_EDIT
            });

            // ===== EDIT MODE MASK =====
            hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
                x: 0, y: 0, w: SCREEN_W, h: SCREEN_H,
                src: 'edit_mask.png',
                show_level: hmUI.show_level.ONLY_EDIT
            });

            // ===== EDITABLE SLOTS (3 large full-screen buttons) =====
            for (let i = 0; i < 3; i++) {
                const editGroup = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 101 + i,
                    x: EDIT_SLOT_X,
                    y: EDIT_SLOT_Y[i],
                    w: EDIT_SLOT_W,
                    h: EDIT_SLOT_H[i],
                    select_image: 'edit_select_' + i + '.png',
                    un_select_image: 'edit_unselect_' + i + '.png',
                    default_type: DEFAULT_TYPES[i],
                    optional_types: OPTIONAL_TYPES,
                    count: OPTIONAL_TYPES.length,
                    tips_BG: 'tips_bg.png',
                    tips_x: TIPS_OFFSET_X,
                    tips_y: TIPS_OFFSET_Y,
                    tips_width: TIPS_W,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                editGroups.push(editGroup);

                const editType = editGroup.getProperty(hmUI.prop.CURRENT_TYPE);
                const dataType = EDIT_TO_DATA[editType];
                if (dataType !== undefined) {
                    createDataWidget(dataType, STAT_Y[i]);
                }
            }
            // ===== TAP ZONES =====
            // Weather tap
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                x: 0, y: 0, w: 194, h: 78,
                src: 'empty.png',
                type: hmUI.data_type.WEATHER,
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            // Stats tap (opens app based on slot 0 selection)
            const slot0Type = editGroups[0].getProperty(hmUI.prop.CURRENT_TYPE);
            const slot0DataType = EDIT_TO_DATA[slot0Type];
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                x: 0, y: 270, w: 194, h: 98,
                src: 'empty.png',
                type: slot0DataType,
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            // Theme switching
            hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 0, y: 96, w: 50, h: 118,
                press_src: '', normal_src: '',
                click_func: function() { switchTheme(-1); },
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 144, y: 96, w: 50, h: 118,
                press_src: '', normal_src: '',
                click_func: function() { switchTheme(1); },
                show_level: hmUI.show_level.ONLY_NORMAL
            });
        },

        onDestroy() {
            n.log("destroy");
        }
    })
})()
} catch (e) {
    console.log("Error", e);
}
