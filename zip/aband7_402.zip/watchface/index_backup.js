﻿/*
 ** DragynRainV1 Watch Face
 ** For Amazfit Band 7 (194x368)
 ** Minimalistic design with weather, time, date, steps, distance, battery
 ** Theme cycling feature included
 */

try {
  (() => {
    // ============= CONFIGURATION =============
    const SCREEN_WIDTH = 194;
    const SCREEN_HEIGHT = 368;

    // Vertical layout: thirds
    const TOP_SECTION_END = 115;      // Weather section
    const MIDDLE_SECTION_END = 260;   // Time + Date section
    // Bottom section: 260-368        // Stats section

    // Theme count
    const TOTAL_THEMES = 14;

    // Widget references
    let currentTheme = 0;

    // Normal mode widgets
    let weatherIcon = null;
    let tempDisplay = null;
    let timeDisplay = null;
    let timeColon = null;
    let dateDisplay = null;
    let weekdayDisplay = null;
    let stepsIcon = null;
    let stepsDisplay = null;
    let distanceIcon = null;
    let distanceDisplay = null;
    let batteryIcon = null;
    let batteryDisplay = null;
    let btnThemeLeft = null;
    let btnThemeRight = null;
    let btnWeather = null;
    let btnSteps = null;

    // AOD mode widgets (simplified)
    let aod_timeDisplay = null;
    let aod_timeColon = null;
    let aod_dateDisplay = null;
    let aod_batteryDisplay = null;

    // Weather icon mapping (Zepp OS weather codes)
    // Uses weather_X.png format where X is the weather code
    function getWeatherIconName(code) {
      // Ensure code is within valid range (0-28)
      if (code >= 0 && code <= 28) {
        return 'weather_' + code + '.png';
      }
      return 'weather_3.png'; // Default to sunny
    }

    function cycleTheme(increase) {
      if (increase) {
        currentTheme = currentTheme + 1;
        if (currentTheme > TOTAL_THEMES) {
          currentTheme = 0;
        }
      } else {
        currentTheme = currentTheme - 1;
        if (currentTheme < 0) {
          currentTheme = TOTAL_THEMES;
        }
      }

      hmUI.showToast({
        text: "Theme " + parseInt(currentTheme)
      });

      updateThemeAssets();
    }

    function getTimeDigitArray(theme) {
      var prefix = 't' + theme + '_';
      return [
        prefix + '0.png', prefix + '1.png', prefix + '2.png',
        prefix + '3.png', prefix + '4.png', prefix + '5.png',
        prefix + '6.png', prefix + '7.png', prefix + '8.png',
        prefix + '9.png'
      ];
    }

    function getDateDigitArray(theme) {
      var prefix = 't' + theme + '_s';
      return [
        prefix + '0.png', prefix + '1.png', prefix + '2.png',
        prefix + '3.png', prefix + '4.png', prefix + '5.png',
        prefix + '6.png', prefix + '7.png', prefix + '8.png',
        prefix + '9.png'
      ];
    }

    function getWeekdayArray(theme) {
      var prefix = 't' + theme + '_';
      return [
        prefix + 'sun.png', prefix + 'mon.png', prefix + 'tue.png',
        prefix + 'wed.png', prefix + 'thu.png', prefix + 'fri.png',
        prefix + 'sat.png'
      ];
    }

    function updateThemeAssets() {
      var themePrefix = 't' + currentTheme + '_';
      var timeArr = getTimeDigitArray(currentTheme);
      var dateArr = getDateDigitArray(currentTheme);
      var weekArr = getWeekdayArray(currentTheme);

      // Update time display
      if (timeDisplay) {
        timeDisplay.setProperty(hmUI.prop.MORE, {
          hour_array: timeArr,
          minute_array: timeArr,
          am_sc_path: themePrefix + 'am.png',
          am_en_path: themePrefix + 'am.png',
          pm_sc_path: themePrefix + 'pm.png',
          pm_en_path: themePrefix + 'pm.png'
        });
      }

      // Update time colon
      if (timeColon) {
        timeColon.setProperty(hmUI.prop.SRC, themePrefix + 'colon.png');
      }

      // Update date display
      if (dateDisplay) {
        dateDisplay.setProperty(hmUI.prop.MORE, {
          month_sc_array: dateArr,
          month_tc_array: dateArr,
          month_en_array: dateArr,
          day_sc_array: dateArr,
          day_tc_array: dateArr,
          day_en_array: dateArr
        });
      }

      // Update weekday display
      if (weekdayDisplay) {
        weekdayDisplay.setProperty(hmUI.prop.MORE, {
          week_en: weekArr,
          week_tc: weekArr,
          week_sc: weekArr
        });
      }
    }

    // ============= MAIN APP SETUP =============
    const e = __$$hmAppManager$$__.currentApp;
    const o = e.current;
    const widgetFactory = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, o));
    const globals = e.__globals__;
    const n = Logger.getLogger("dragynrainV1");

    o.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        var screenType = hmSetting.getScreenType();
        var isAOD = screenType === hmSetting.screen_type.AOD;

        // ============= TOP SECTION: WEATHER =============
        if (!isAOD) {
          // Weather icon - large, centered at top
          weatherIcon = hmUI.createWidget(hmUI.widget.IMG, {
            x: 67,
            y: 8,
            w: 60,
            h: 60,
            src: 'weather_3.png',
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          // Temperature display
          tempDisplay = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 10,
            y: 72,
            w: 174,
            font_array: ['n0.png', 'n1.png', 'n2.png', 'n3.png', 'n4.png',
                         'n5.png', 'n6.png', 'n7.png', 'n8.png', 'n9.png'],
            negative_image: 'neg.png',
            unit_sc: 'deg.png',
            unit_tc: 'deg.png',
            unit_en: 'deg.png',
            padding: false,
            h_space: 1,
            align_h: hmUI.align.CENTER_H,
            type: hmUI.data_type.WEATHER_CURRENT,
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          // Weather tap zone - opens weather app
          btnWeather = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 0,
            y: 0,
            w: SCREEN_WIDTH,
            h: TOP_SECTION_END,
            text: '',
            normal_src: 'empty.png',
            press_src: 'empty.png',
            click_func: function() {
              hmApp.gotoPage({ url: 'Weather' });
            },
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          // Update weather icon based on current conditions
          try {
            var weather = hmSensor.createSensor(hmSensor.id.WEATHER);
            var updateWeatherIcon = function() {
              var weatherData = weather.getForecastWeather();
              if (weatherData && weatherData.forecastData && weatherData.forecastData.data &&
                  weatherData.forecastData.data[0]) {
                var todayWeather = weatherData.forecastData.data[0];
                var iconName = getWeatherIconName(todayWeather.index);
                weatherIcon.setProperty(hmUI.prop.SRC, iconName);
              }
            };
            updateWeatherIcon();
            weather.addEventListener(hmSensor.event.CHANGE, updateWeatherIcon);
          } catch (err) {
            console.log('Weather sensor error:', err);
          }
        }

        // ============= MIDDLE SECTION: TIME + DATE =============
        // Layout math for 194px screen with 38px wide digits + colon:
        // Hours: 2Ã—38=76px, Colon: 10px, Minutes: 76px, AM/PM: ~24px
        // Total: 76 + 10 + 76 + 24 = 186px, with ~4px margins each side
        var timeY = 120;
        var timeDigits = getTimeDigitArray(0);
        var dateDigits = getDateDigitArray(0);
        var weekdays = getWeekdayArray(0);

        if (!isAOD) {
          // Large time display - 12 hour format with AM/PM
          timeDisplay = hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_startX: 2,
            hour_startY: timeY,
            hour_array: timeDigits,
            hour_zero: 1,
            hour_space: 0,
            hour_align: hmUI.align.LEFT,

            minute_startX: 90,
            minute_startY: timeY,
            minute_array: timeDigits,
            minute_zero: 1,
            minute_space: 0,
            minute_follow: 0,
            minute_align: hmUI.align.LEFT,

            am_x: 168,
            am_y: timeY + 8,
            am_sc_path: 't0_am.png',
            am_en_path: 't0_am.png',
            pm_x: 168,
            pm_y: timeY + 28,
            pm_sc_path: 't0_pm.png',
            pm_en_path: 't0_pm.png',

            show_level: hmUI.show_level.ONLY_NORMAL
          });

          // Colon between hours and minutes
          timeColon = hmUI.createWidget(hmUI.widget.IMG, {
            x: 78,
            y: timeY,
            src: 't0_colon.png',
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        } else {
          // AOD time display
          aod_timeDisplay = hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_startX: 2,
            hour_startY: timeY,
            hour_array: timeDigits,
            hour_zero: 1,
            hour_space: 0,
            hour_align: hmUI.align.LEFT,

            minute_startX: 90,
            minute_startY: timeY,
            minute_array: timeDigits,
            minute_zero: 1,
            minute_space: 0,
            minute_follow: 0,
            minute_align: hmUI.align.LEFT,

            am_x: 168,
            am_y: timeY + 8,
            am_sc_path: 't0_am.png',
            am_en_path: 't0_am.png',
            pm_x: 168,
            pm_y: timeY + 28,
            pm_sc_path: 't0_pm.png',
            pm_en_path: 't0_pm.png',

            show_level: hmUI.show_level.ONLY_AOD
          });

          // Colon for AOD
          aod_timeColon = hmUI.createWidget(hmUI.widget.IMG, {
            x: 78,
            y: timeY,
            src: 't0_colon.png',
            show_level: hmUI.show_level.ONLY_AOD
          });
        }

        // Date display: MM/DD format
        // Date digits: 18px wide, slash: ~12px
        // MM (36px) + slash (12px) + DD (36px) = 84px
        // Centered: (194 - 84) / 2 = 55px start
        var dateY = 178;

        if (!isAOD) {
          dateDisplay = hmUI.createWidget(hmUI.widget.IMG_DATE, {
            month_startX: 55,
            month_startY: dateY,
            month_sc_array: dateDigits,
            month_tc_array: dateDigits,
            month_en_array: dateDigits,
            month_zero: 1,
            month_space: 0,
            month_align: hmUI.align.LEFT,
            month_is_character: false,

            day_startX: 103,
            day_startY: dateY,
            day_sc_array: dateDigits,
            day_tc_array: dateDigits,
            day_en_array: dateDigits,
            day_zero: 1,
            day_space: 0,
            day_align: hmUI.align.LEFT,
            day_is_character: false,

            show_level: hmUI.show_level.ONLY_NORMAL
          });

          // Date separator slash (centered between MM and DD)
          hmUI.createWidget(hmUI.widget.IMG, {
            x: 91,
            y: dateY,
            src: 'slash.png',
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        } else {
          aod_dateDisplay = hmUI.createWidget(hmUI.widget.IMG_DATE, {
            month_startX: 55,
            month_startY: dateY,
            month_sc_array: dateDigits,
            month_tc_array: dateDigits,
            month_en_array: dateDigits,
            month_zero: 1,
            month_space: 0,
            month_align: hmUI.align.LEFT,
            month_is_character: false,

            day_startX: 103,
            day_startY: dateY,
            day_sc_array: dateDigits,
            day_tc_array: dateDigits,
            day_en_array: dateDigits,
            day_zero: 1,
            day_space: 0,
            day_align: hmUI.align.LEFT,
            day_is_character: false,

            show_level: hmUI.show_level.ONLY_AOD
          });

          // Date separator slash for AOD
          hmUI.createWidget(hmUI.widget.IMG, {
            x: 91,
            y: dateY,
            src: 'slash.png',
            show_level: hmUI.show_level.ONLY_AOD
          });
        }

        // Weekday display - centered
        // Weekday text ~50px wide, centered: (194 - 50) / 2 = 72px
        var weekdayY = 208;

        if (!isAOD) {
          weekdayDisplay = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
            x: 72,
            y: weekdayY,
            week_en: weekdays,
            week_tc: weekdays,
            week_sc: weekdays,
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          // Theme change buttons - tap left/right of time area
          btnThemeLeft = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 0,
            y: TOP_SECTION_END,
            w: 50,
            h: MIDDLE_SECTION_END - TOP_SECTION_END,
            text: '',
            normal_src: 'empty.png',
            press_src: 'empty.png',
            click_func: function() {
              cycleTheme(false);
            },
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          btnThemeRight = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: SCREEN_WIDTH - 50,
            y: TOP_SECTION_END,
            w: 50,
            h: MIDDLE_SECTION_END - TOP_SECTION_END,
            text: '',
            normal_src: 'empty.png',
            press_src: 'empty.png',
            click_func: function() {
              cycleTheme(true);
            },
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        }

        // ============= BOTTOM SECTION: STEPS, DISTANCE, BATTERY =============
        // Centered layout: icon (26px) + gap (6px) + text (~100px) = ~132px
        // Centered start: (194 - 132) / 2 = 31px
        var statsY = 270;
        var statsSpacing = 32;
        var statsIconX = 53;
        var statsTextX = 85;

        if (!isAOD) {
          // Steps row
          stepsIcon = hmUI.createWidget(hmUI.widget.IMG, {
            x: statsIconX,
            y: statsY,
            src: 'ic_steps.png',
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          stepsDisplay = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: statsTextX,
            y: statsY,
            w: 120,
            font_array: ['n0.png', 'n1.png', 'n2.png', 'n3.png', 'n4.png',
                         'n5.png', 'n6.png', 'n7.png', 'n8.png', 'n9.png'],
            padding: false,
            h_space: 1,
            align_h: hmUI.align.LEFT,
            type: hmUI.data_type.STEP,
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          // Distance row
          distanceIcon = hmUI.createWidget(hmUI.widget.IMG, {
            x: statsIconX,
            y: statsY + statsSpacing,
            src: 'ic_distance.png',
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          distanceDisplay = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: statsTextX,
            y: statsY + statsSpacing,
            w: 110,
            font_array: ['n0.png', 'n1.png', 'n2.png', 'n3.png', 'n4.png',
                         'n5.png', 'n6.png', 'n7.png', 'n8.png', 'n9.png'],
            dot_image: 'dot.png',
            padding: false,
            h_space: 1,
            align_h: hmUI.align.LEFT,
            type: hmUI.data_type.DISTANCE,
            unit_sc: 'km.png',
            unit_tc: 'km.png',
            unit_en: 'km.png',
            imperial_unit_sc: 'mi.png',
            imperial_unit_tc: 'mi.png',
            imperial_unit_en: 'mi.png',
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          // Battery row
          batteryIcon = hmUI.createWidget(hmUI.widget.IMG, {
            x: statsIconX,
            y: statsY + statsSpacing * 2,
            src: 'ic_battery.png',
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          batteryDisplay = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: statsTextX,
            y: statsY + statsSpacing * 2,
            w: 100,
            font_array: ['n0.png', 'n1.png', 'n2.png', 'n3.png', 'n4.png',
                         'n5.png', 'n6.png', 'n7.png', 'n8.png', 'n9.png'],
            padding: false,
            h_space: 1,
            align_h: hmUI.align.LEFT,
            unit_sc: 'percent.png',
            unit_tc: 'percent.png',
            unit_en: 'percent.png',
            type: hmUI.data_type.BATTERY,
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          // Steps/Distance tap zone - opens activity
          btnSteps = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 0,
            y: MIDDLE_SECTION_END,
            w: SCREEN_WIDTH,
            h: SCREEN_HEIGHT - MIDDLE_SECTION_END,
            text: '',
            normal_src: 'empty.png',
            press_src: 'empty.png',
            click_func: function() {
              hmApp.gotoPage({ url: 'Activity' });
            },
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        } else {
          // AOD: Just battery at bottom
          aod_batteryDisplay = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 60,
            y: statsY + statsSpacing,
            w: 100,
            font_array: ['n0.png', 'n1.png', 'n2.png', 'n3.png', 'n4.png',
                         'n5.png', 'n6.png', 'n7.png', 'n8.png', 'n9.png'],
            padding: false,
            h_space: 1,
            align_h: hmUI.align.CENTER_H,
            unit_sc: 'percent.png',
            unit_tc: 'percent.png',
            unit_en: 'percent.png',
            type: hmUI.data_type.BATTERY,
            show_level: hmUI.show_level.ONLY_AOD
          });
        }

        // Widget delegate for updates
        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function() {
            // Refresh displays on resume if needed
          }
        });
      },

      onInit() {
        n.log("DragynRainV1 watchface init");
      },

      build() {
        this.init_view();
        n.log("DragynRainV1 watchface build complete");
      },

      onDestroy() {
        n.log("DragynRainV1 watchface destroy");
      }
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);
  if (e && e.stack) {
    e.stack.split(/\n/).forEach(function(line) {
      console.log("error stack", line);
    });
  }
}
