#!/bin/bash
# Build script for DragynrainV1 watchface
# Usage: ./build.sh [--no-bin]
#
# This rebuilds the watchface from design.py:
#   - Generates watchface/index.js
#   - Creates all asset images
#   - Builds the .bin file (unless --no-bin)
#
# Output: dist/DragynrainV1.bin

cd "$(dirname "$0")"
python ../../scripts/build.py . "$@"
