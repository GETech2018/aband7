﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 33;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 33;
        let normal_digital_clock_img_time = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 33;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 33;
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: '00-fondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 60,
              month_startY: 316,
              month_sc_array: ["widget_nro_00.png","widget_nro_01.png","widget_nro_02.png","widget_nro_03.png","widget_nro_04.png","widget_nro_05.png","widget_nro_06.png","widget_nro_07.png","widget_nro_08.png","widget_nro_09.png"],
              month_tc_array: ["widget_nro_00.png","widget_nro_01.png","widget_nro_02.png","widget_nro_03.png","widget_nro_04.png","widget_nro_05.png","widget_nro_06.png","widget_nro_07.png","widget_nro_08.png","widget_nro_09.png"],
              month_en_array: ["widget_nro_00.png","widget_nro_01.png","widget_nro_02.png","widget_nro_03.png","widget_nro_04.png","widget_nro_05.png","widget_nro_06.png","widget_nro_07.png","widget_nro_08.png","widget_nro_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 39,
              day_startY: 316,
              day_sc_array: ["widget_nro_00.png","widget_nro_01.png","widget_nro_02.png","widget_nro_03.png","widget_nro_04.png","widget_nro_05.png","widget_nro_06.png","widget_nro_07.png","widget_nro_08.png","widget_nro_09.png"],
              day_tc_array: ["widget_nro_00.png","widget_nro_01.png","widget_nro_02.png","widget_nro_03.png","widget_nro_04.png","widget_nro_05.png","widget_nro_06.png","widget_nro_07.png","widget_nro_08.png","widget_nro_09.png"],
              day_en_array: ["widget_nro_00.png","widget_nro_01.png","widget_nro_02.png","widget_nro_03.png","widget_nro_04.png","widget_nro_05.png","widget_nro_06.png","widget_nro_07.png","widget_nro_08.png","widget_nro_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'widget_nro_11.png',
              day_unit_tc: 'widget_nro_11.png',
              day_unit_en: 'widget_nro_11.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 329,
              week_en: ["ES_Dia_nombre_00.png","ES_Dia_nombre_01.png","ES_Dia_nombre_02.png","ES_Dia_nombre_03.png","ES_Dia_nombre_04.png","ES_Dia_nombre_05.png","ES_Dia_nombre_06.png"],
              week_tc: ["ES_Dia_nombre_00.png","ES_Dia_nombre_01.png","ES_Dia_nombre_02.png","ES_Dia_nombre_03.png","ES_Dia_nombre_04.png","ES_Dia_nombre_05.png","ES_Dia_nombre_06.png"],
              week_sc: ["ES_Dia_nombre_00.png","ES_Dia_nombre_01.png","ES_Dia_nombre_02.png","ES_Dia_nombre_03.png","ES_Dia_nombre_04.png","ES_Dia_nombre_05.png","ES_Dia_nombre_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 39,
              y: 350,
              font_array: ["widget_nro_00.png","widget_nro_01.png","widget_nro_02.png","widget_nro_03.png","widget_nro_04.png","widget_nro_05.png","widget_nro_06.png","widget_nro_07.png","widget_nro_08.png","widget_nro_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'widget_nro_10.png',
              unit_tc: 'widget_nro_10.png',
              unit_en: 'widget_nro_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 34,
              y: 351,
              src: 'ico_bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 37,
              // y: 8,
              // font_array: ["02_hora_chica_00.png","02_hora_chica_01.png","02_hora_chica_02.png","02_hora_chica_03.png","02_hora_chica_04.png","02_hora_chica_05.png","02_hora_chica_06.png","02_hora_chica_07.png","02_hora_chica_08.png","02_hora_chica_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = '02_hora_chica_00.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = '02_hora_chica_01.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = '02_hora_chica_02.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = '02_hora_chica_03.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = '02_hora_chica_04.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = '02_hora_chica_05.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = '02_hora_chica_06.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = '02_hora_chica_07.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = '02_hora_chica_08.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = '02_hora_chica_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 37,
                center_y: 8,
                pos_x: 37,
                pos_y: 8,
                angle: 0,
                src: '02_hora_chica_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 37,
              // y: 37,
              // font_array: ["02_hora_chica_00.png","02_hora_chica_01.png","02_hora_chica_02.png","02_hora_chica_03.png","02_hora_chica_04.png","02_hora_chica_05.png","02_hora_chica_06.png","02_hora_chica_07.png","02_hora_chica_08.png","02_hora_chica_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = '02_hora_chica_00.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = '02_hora_chica_01.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = '02_hora_chica_02.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = '02_hora_chica_03.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = '02_hora_chica_04.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = '02_hora_chica_05.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = '02_hora_chica_06.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = '02_hora_chica_07.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = '02_hora_chica_08.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = '02_hora_chica_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 37,
                center_y: 37,
                pos_x: 37,
                pos_y: 37,
                angle: 0,
                src: '02_hora_chica_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 83,
              hour_startY: 0,
              hour_array: ["00_Superior_hora_01.png","00_Superior_hora_02.png","00_Superior_hora_03.png","00_Superior_hora_04.png","00_Superior_hora_05.png","00_Superior_hora_06.png","00_Superior_hora_07.png","00_Superior_hora_08.png","00_Superior_hora_09.png","00_Superior_hora_10.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 83,
              minute_startY: 156,
              minute_array: ["01_inferior_hora_01.png","01_inferior_hora_02.png","01_inferior_hora_03.png","01_inferior_hora_04.png","01_inferior_hora_05.png","01_inferior_hora_06.png","01_inferior_hora_07.png","01_inferior_hora_08.png","01_inferior_hora_09.png","01_inferior_hora_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 37,
              // y: 8,
              // font_array: ["AOD_hora_chica_00.png","AOD_hora_chica_01.png","AOD_hora_chica_02.png","AOD_hora_chica_03.png","AOD_hora_chica_04.png","AOD_hora_chica_05.png","AOD_hora_chica_06.png","AOD_hora_chica_07.png","AOD_hora_chica_08.png","AOD_hora_chica_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'AOD_hora_chica_00.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'AOD_hora_chica_01.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'AOD_hora_chica_02.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'AOD_hora_chica_03.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'AOD_hora_chica_04.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'AOD_hora_chica_05.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'AOD_hora_chica_06.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'AOD_hora_chica_07.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'AOD_hora_chica_08.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'AOD_hora_chica_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 37,
                center_y: 8,
                pos_x: 37,
                pos_y: 8,
                angle: 0,
                src: 'AOD_hora_chica_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 37,
              // y: 37,
              // font_array: ["AOD_hora_chica_00.png","AOD_hora_chica_01.png","AOD_hora_chica_02.png","AOD_hora_chica_03.png","AOD_hora_chica_04.png","AOD_hora_chica_05.png","AOD_hora_chica_06.png","AOD_hora_chica_07.png","AOD_hora_chica_08.png","AOD_hora_chica_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'AOD_hora_chica_00.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'AOD_hora_chica_01.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'AOD_hora_chica_02.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'AOD_hora_chica_03.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'AOD_hora_chica_04.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'AOD_hora_chica_05.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'AOD_hora_chica_06.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'AOD_hora_chica_07.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'AOD_hora_chica_08.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'AOD_hora_chica_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 37,
                center_y: 37,
                pos_x: 37,
                pos_y: 37,
                angle: 0,
                src: 'AOD_hora_chica_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 83,
              hour_startY: 0,
              hour_array: ["00_Superior_hora_01.png","00_Superior_hora_02.png","00_Superior_hora_03.png","00_Superior_hora_04.png","00_Superior_hora_05.png","00_Superior_hora_06.png","00_Superior_hora_07.png","00_Superior_hora_08.png","00_Superior_hora_09.png","00_Superior_hora_10.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 83,
              minute_startY: 156,
              minute_array: ["01_inferior_hora_01.png","01_inferior_hora_02.png","01_inferior_hora_03.png","01_inferior_hora_04.png","01_inferior_hora_05.png","01_inferior_hora_06.png","01_inferior_hora_07.png","01_inferior_hora_08.png","01_inferior_hora_09.png","01_inferior_hora_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  img_offset -= normal_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 37 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_minute_TextRotate_posOffset = normal_minute_TextRotate_img_width * normal_minute_rotate_string.length;
                  img_offset -= normal_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 37 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_hour_TextRotate_posOffset = idle_hour_TextRotate_img_width * idle_hour_rotate_string.length;
                  img_offset -= idle_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 37 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_minute_TextRotate_posOffset = idle_minute_TextRotate_img_width * idle_minute_rotate_string.length;
                  img_offset -= idle_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 37 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}