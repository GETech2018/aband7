﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_wind_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_pai_day_text_img = ''
        let normal_pai_day_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


//////////////////////////////////////////////////////////////////////////////////////////////////

        // Activity select
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 3
        let cc = 0

        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UV();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  Humidity();
                }

                if(backgroundnumber==3) {
                  Wind();
                }



            }

        }

//////////////////////////////////////////////////////////////////////////////////////////////////


//UV
function UV(){

        hmUI.showToast({text: 'UV'});

        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

        }



//Humidity
function Humidity(){

        hmUI.showToast({text: 'Humidity'});

        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

        }

//Wind
function Wind(){

        hmUI.showToast({text: 'Wind'});

        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);

        }


//////////////////////////////////////////////////////////////////////////////////////////////////


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 44,
              font_array: ["sun_0.png","sun_1.png","sun_2.png","sun_3.png","sun_4.png","sun_5.png","sun_6.png","sun_7.png","sun_8.png","sun_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 44,
              font_array: ["sun_0.png","sun_1.png","sun_2.png","sun_3.png","sun_4.png","sun_5.png","sun_6.png","sun_7.png","sun_8.png","sun_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 44,
              font_array: ["sun_0.png","sun_1.png","sun_2.png","sun_3.png","sun_4.png","sun_5.png","sun_6.png","sun_7.png","sun_8.png","sun_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 107,
              y: 226,
              src: '0127.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 128,
              y: 258,
              src: '0126.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 130,
              y: 196,
              src: '0128.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 23,
              y: 228,
              font_array: ["digits_0.png","digits_1.png","digits_2.png","digits_3.png","digits_4.png","digits_5.png","digits_6.png","digits_7.png","digits_8.png","digits_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 11,
              y: 204,
              image_array: ["circle_gauge1.png","circle_gauge2.png","circle_gauge3.png","circle_gauge4.png","circle_gauge5.png","circle_gauge6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 25,
              y: 314,
              font_array: ["weather_digits_0.png","weather_digits_1.png","weather_digits_2.png","weather_digits_3.png","weather_digits_4.png","weather_digits_5.png","weather_digits_6.png","weather_digits_7.png","weather_digits_8.png","weather_digits_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 318,
              src: '0090.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 344,
              font_array: ["sun_0.png","sun_1.png","sun_2.png","sun_3.png","sun_4.png","sun_5.png","sun_6.png","sun_7.png","sun_8.png","sun_9.png"],
              padding: true,
              h_space: 1,
              dot_image: 'separator.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 150,
              y: 345,
              src: 'unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 293,
              font_array: ["sun_0.png","sun_1.png","sun_2.png","sun_3.png","sun_4.png","sun_5.png","sun_6.png","sun_7.png","sun_8.png","sun_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 294,
              src: '0125.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 318,
              font_array: ["weather_digits_0.png","weather_digits_1.png","weather_digits_2.png","weather_digits_3.png","weather_digits_4.png","weather_digits_5.png","weather_digits_6.png","weather_digits_7.png","weather_digits_8.png","weather_digits_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 11,
              y: 293,
              image_array: ["circle01.png","circle02.png","circle03.png","circle04.png","circle05.png","circle06.png","circle07.png","circle08.png","circle09.png","circle10.png","circle11.png","circle12.png"],
              image_length: 12,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 128,
              y: 228,
              font_array: ["weather_digits_0.png","weather_digits_1.png","weather_digits_2.png","weather_digits_3.png","weather_digits_4.png","weather_digits_5.png","weather_digits_6.png","weather_digits_7.png","weather_digits_8.png","weather_digits_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 153,
              y: 203,
              image_array: ["0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 119,
              y: 3,
              font_array: ["weather_digits_0.png","weather_digits_1.png","weather_digits_2.png","weather_digits_3.png","weather_digits_4.png","weather_digits_5.png","weather_digits_6.png","weather_digits_7.png","weather_digits_8.png","weather_digits_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'weather_digits_11.png',
              unit_tc: 'weather_digits_11.png',
              unit_en: 'weather_digits_11.png',
              negative_image: 'weather_digits_10.png',
              invalid_image: 'weather_digits_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 119,
              y: 74,
              font_array: ["weather_digits_0.png","weather_digits_1.png","weather_digits_2.png","weather_digits_3.png","weather_digits_4.png","weather_digits_5.png","weather_digits_6.png","weather_digits_7.png","weather_digits_8.png","weather_digits_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'weather_digits_11.png',
              unit_tc: 'weather_digits_11.png',
              unit_en: 'weather_digits_11.png',
              negative_image: 'weather_digits_10.png',
              invalid_image: 'weather_digits_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 39,
              font_array: ["digits_0.png","digits_1.png","digits_2.png","digits_3.png","digits_4.png","digits_5.png","digits_6.png","digits_7.png","digits_8.png","digits_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digits_11.png',
              unit_tc: 'digits_11.png',
              unit_en: 'digits_11.png',
              negative_image: 'digits_10.png',
              invalid_image: 'digits_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 13,
              y: 23,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 102,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 0,
              y: 0,
              font_array: ["sun_0.png","sun_1.png","sun_2.png","sun_3.png","sun_4.png","sun_5.png","sun_6.png","sun_7.png","sun_8.png","sun_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'sun_11.png',
              dot_image: 'sun_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: -5,
              y: 86,
              font_array: ["sun_0.png","sun_1.png","sun_2.png","sun_3.png","sun_4.png","sun_5.png","sun_6.png","sun_7.png","sun_8.png","sun_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'sun_11.png',
              dot_image: 'sun_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 97,
              y: 146,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "dots",
              anim_fps: 2,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 39,
              y: 195,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "heart",
              anim_fps: 5,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 12,
              hour_startY: 134,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 112,
              minute_startY: 134,
              minute_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 12,
              y: 130,
              w: 83,
              h: 67,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 82,
              w: 77,
              h: 24,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 17,
              w: 61,
              h: 63,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 22,
              y: 213,
              w: 50,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 284,
              w: 100,
              h: 81,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });


/////////////////Show element at the first time //////////

if (cc==0) {
cc = 1
        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
 
}
//////////////////////////////////////////////////////////////////////////////////////////////////
 
           // Element on/off
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 81,
              y: 30,
              text: '',
              w: 40,
              h: 40,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}