﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_icon_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

//////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////
// Color Background change
//////////////////////////////////

        let btncolor = ''
        let colornumber_background = 1
        let totalcolors_background = 2
        let namecolor_background = ''

function click_Color_Background() 
{

 if(colornumber_background>=totalcolors_background) 
    {
     colornumber_background=1;
    }

 else 
     {
      colornumber_background=colornumber_background+1;
     }

 if ( colornumber_background == 1) { namecolor_background = "White"

                          };

 if ( colornumber_background == 2) { namecolor_background = "Black"

                          };

 hmUI.showToast({text: namecolor_background });

 normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber_background) + ".png");



}

//////////////////////////////////
// Color Background change ///////
//////////////////////////////////


//////////////////////////
////// Color Change //////
//////////////////////////

	let colornumber_main = 1
        let totalcolors_main = 9
        let namecolor_main = ''
	let secstring = 't_sec1.png'
	let datestring = 'date1.png'
	let pointerstring = 'pointer1.png'

function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

			if ( colornumber_main == 1) { namecolor_main = "RED STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}


			if ( colornumber_main == 2) { namecolor_main = "CYAN STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 3) { namecolor_main = "ORANGE STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 4) { namecolor_main = " BLUE STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 5) { namecolor_main = "YELLOW STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 6) { namecolor_main = "FUCHSIA STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 7) { namecolor_main = "GREEN STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 8) { namecolor_main = "PURPLE STYLE"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 9) { namecolor_main = "COLORLESS"
				secstring = 't_sec' +colornumber_main+ '.png'
				datestring = "date" + parseInt(colornumber_main) + ".png"
				pointerstring = "pointer" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main <= 9) { 

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 99,
              second_centerY: 184,
              second_posX: 184,
              second_posY: 185,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
	    normal_month_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: datestring,
              center_x: 99,
              center_y: 274,
              posX: 16,
              posY: 36,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: pointerstring,
              center_x: 18,
              center_y: 181,
              x: 19,
              y: 52,
              start_angle: -15,
              end_angle: 107,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: pointerstring,
              center_x: 178,
              center_y: 181,
              x: 19,
              y: 52,
              start_angle: -138,
              end_angle: 20,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			}

   	    hmUI.showToast({text: namecolor_main });
            normal_battery_icon_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber_main) + ".png");
         
        }
//////////////////////////
////// Color Change //////
//////////////////////////


///////////////////////////////
////// Line Color Change //////
///////////////////////////////


let colornumber = 1
let totalcolors = 9
		
function click_Line() 
{
  if(colornumber==totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }
			{
                 if(colornumber==2) hmUI.showToast({text: 'RED LINES'});
				 if(colornumber==3) hmUI.showToast({text: 'LIGHT LINES'});
                 if(colornumber==4) hmUI.showToast({text: 'CYAN LINES'});
				 if(colornumber==5) hmUI.showToast({text: 'GREEN LINES'});
                 if(colornumber==6) hmUI.showToast({text: 'BLUE LINES'});
				 if(colornumber==7) hmUI.showToast({text: 'ORANGE LINES'});
				 if(colornumber==8) hmUI.showToast({text: 'PURPLE LINES'});
				 if(colornumber==9) hmUI.showToast({text: 'YELLOW LINES'});
   }

  if(colornumber==1) hmUI.showToast({text: 'DARK LINES'});
            normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "line" + parseInt(colornumber) + ".png");
}

///////////////////////////////
////// Line Color Change //////
///////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////



        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'line1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 252,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'date1.png',
              center_x: 99,
              center_y: 274,
              posX: 16,
              posY: 36,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 85,
              day_startY: 257,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 77,
              y: 278,
              week_en: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_tc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_sc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer1.png',
              center_x: 18,
              center_y: 181,
              x: 19,
              y: 52,
              start_angle: -15,
              end_angle: 107,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: -3,
              y: 198,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer1.png',
              center_x: 178,
              center_y: 181,
              x: 19,
              y: 52,
              start_angle: -138,
              end_angle: 20,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 198,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 78,
              y: 55,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour.png',
              hour_centerX: 99,
              hour_centerY: 184,
              hour_posX: 184,
              hour_posY: 165,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min.png',
              minute_centerX: 99,
              minute_centerY: 184,
              minute_posX: 184,
              minute_posY: 165,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 't_sec1.png',
              second_centerX: 99,
              second_centerY: 184,
              second_posX: 184,
              second_posY: 185,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 't_hour.png',
              hour_centerX: 99,
              hour_centerY: 184,
              hour_posX: 184,
              hour_posY: 165,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 't_min.png',
              minute_centerX: 99,
              minute_centerY: 184,
              minute_posX: 184,
              minute_posY: 165,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 168,
              y: 256,
              w: 26,
              h: 43,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 251,
              w: 57,
              h: 54,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 240,
              w: 48,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 122,
              w: 74,
              h: 108,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 128,
              y: 120,
              w: 66,
              h: 108,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


//////////////////////////////////////////////////////////////////////////////////////////////////  

          // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 58,
              text: '',
              w: 36,
              h: 36,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
               click_Color_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end


          // Change color LEFT
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 53,
              text: '',
              w: 34,
              h: 52,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end



          // Change color RIGHT
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 169,
              y: 70,
              text: '',
              w: 34,
              h: 52,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
               click_Line();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end


    
//////////////////////////////////////////////////////////////////////////////////////////////////


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}