﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 144;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 144;
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 144;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 144;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: '00-fondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 144,
              // y: 47,
              // font_array: ["Hora00.png","Hora01.png","Hora02.png","Hora03.png","Hora04.png","Hora05.png","Hora06.png","Hora07.png","Hora08.png","Hora09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -38,
              // angle: 37,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'Hora00.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'Hora01.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'Hora02.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'Hora03.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'Hora04.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'Hora05.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'Hora06.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'Hora07.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'Hora08.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'Hora09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 144,
                center_y: 47,
                pos_x: 144,
                pos_y: 47,
                angle: 37,
                src: 'Hora00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 145,
              // y: 192,
              // font_array: ["Hora00.png","Hora01.png","Hora02.png","Hora03.png","Hora04.png","Hora05.png","Hora06.png","Hora07.png","Hora08.png","Hora09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -38,
              // angle: 37,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'Hora00.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'Hora01.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'Hora02.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'Hora03.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'Hora04.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'Hora05.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'Hora06.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'Hora07.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'Hora08.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'Hora09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 145,
                center_y: 192,
                pos_x: 145,
                pos_y: 192,
                angle: 37,
                src: 'Hora00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block


            console.log('Watch_Face.ScreenAOD');

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 144,
              // y: 47,
              // font_array: ["AOD_HORA_00.png","AOD_HORA_01.png","AOD_HORA_02.png","AOD_HORA_03.png","AOD_HORA_04.png","AOD_HORA_05.png","AOD_HORA_06.png","AOD_HORA_07.png","AOD_HORA_08.png","AOD_HORA_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -38,
              // angle: 37,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'AOD_HORA_00.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'AOD_HORA_01.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'AOD_HORA_02.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'AOD_HORA_03.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'AOD_HORA_04.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'AOD_HORA_05.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'AOD_HORA_06.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'AOD_HORA_07.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'AOD_HORA_08.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'AOD_HORA_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 144,
                center_y: 47,
                pos_x: 144,
                pos_y: 47,
                angle: 37,
                src: 'AOD_HORA_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 145,
              // y: 192,
              // font_array: ["AOD_HORA_00.png","AOD_HORA_01.png","AOD_HORA_02.png","AOD_HORA_03.png","AOD_HORA_04.png","AOD_HORA_05.png","AOD_HORA_06.png","AOD_HORA_07.png","AOD_HORA_08.png","AOD_HORA_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -38,
              // angle: 37,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'AOD_HORA_00.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'AOD_HORA_01.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'AOD_HORA_02.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'AOD_HORA_03.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'AOD_HORA_04.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'AOD_HORA_05.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'AOD_HORA_06.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'AOD_HORA_07.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'AOD_HORA_08.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'AOD_HORA_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 145,
                center_y: 192,
                pos_x: 145,
                pos_y: 192,
                angle: 37,
                src: 'AOD_HORA_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  normal_hour_TextRotate_posOffset = normal_hour_TextRotate_posOffset + -38 * (normal_hour_rotate_string.length - 1);
                  img_offset -= normal_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 144 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + -38;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_minute_TextRotate_posOffset = normal_minute_TextRotate_img_width * normal_minute_rotate_string.length;
                  normal_minute_TextRotate_posOffset = normal_minute_TextRotate_posOffset + -38 * (normal_minute_rotate_string.length - 1);
                  img_offset -= normal_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 145 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + -38;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_hour_TextRotate_posOffset = idle_hour_TextRotate_img_width * idle_hour_rotate_string.length;
                  idle_hour_TextRotate_posOffset = idle_hour_TextRotate_posOffset + -38 * (idle_hour_rotate_string.length - 1);
                  img_offset -= idle_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 144 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + -38;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_minute_TextRotate_posOffset = idle_minute_TextRotate_img_width * idle_minute_rotate_string.length;
                  idle_minute_TextRotate_posOffset = idle_minute_TextRotate_posOffset + -38 * (idle_minute_rotate_string.length - 1);
                  img_offset -= idle_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 145 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + -38;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}