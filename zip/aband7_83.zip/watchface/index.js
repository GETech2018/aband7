﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    **
    ** Brightness buttons by shockwave55
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_year = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

        let btnbrightnessdown = ''
        let btnbrightnessup = ''

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 7,
              y: 332,
              font_array: ["batteryDigits_0000_0.png","batteryDigits_0001_1.png","batteryDigits_0002_2.png","batteryDigits_0003_3.png","batteryDigits_0004_4.png","batteryDigits_0005_5.png","batteryDigits_0006_6.png","batteryDigits_0007_7.png","batteryDigits_0008_8.png","batteryDigits_0009_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'decimal.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 8,
              y: 22,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 93,
              font_array: ["pulseDigit__0000_0.png","pulseDigit__0001_1.png","pulseDigit__0002_2.png","pulseDigit__0003_3.png","pulseDigit__0004_4.png","pulseDigit__0005_5.png","pulseDigit__0006_6.png","pulseDigit__0007_7.png","pulseDigit__0008_8.png","pulseDigit__0009_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'celsius.png',
              unit_tc: 'celsius.png',
              unit_en: 'celsius.png',
              negative_image: 'negative.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 56,
              image_array: ["weatherIcon_0000_01.png","weatherIcon_0001_02.png","weatherIcon_0002_03.png","weatherIcon_0003_04.png","weatherIcon_0004_05.png","weatherIcon_0005_06.png","weatherIcon_0006_07.png","weatherIcon_0007_08.png","weatherIcon_0008_09.png","weatherIcon_0009_10.png","weatherIcon_0010_11.png","weatherIcon_0011_12.png","weatherIcon_0012_13.png","weatherIcon_0013_14.png","weatherIcon_0014_15.png","weatherIcon_0015_16.png","weatherIcon_0016_17.png","weatherIcon_0017_18.png","weatherIcon_0018_19.png","weatherIcon_0019_20.png","weatherIcon_0020_21.png","weatherIcon_0021_22.png","weatherIcon_0022_23.png","weatherIcon_0023_24.png","weatherIcon_0024_25.png","weatherIcon_0025_26.png","weatherIcon_0026_27.png","weatherIcon_0027_28.png","weatherIcon_0028_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 136,
              day_startY: 219,
              day_sc_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              day_tc_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              day_en_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 95,
              month_startY: 219,
              month_sc_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              month_tc_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              month_en_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 28,
              year_startY: 219,
              year_sc_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              year_tc_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              year_en_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 93,
              font_array: ["pulseDigit__0000_0.png","pulseDigit__0001_1.png","pulseDigit__0002_2.png","pulseDigit__0003_3.png","pulseDigit__0004_4.png","pulseDigit__0005_5.png","pulseDigit__0006_6.png","pulseDigit__0007_7.png","pulseDigit__0008_8.png","pulseDigit__0009_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 332,
              font_array: ["batteryDigits_0000_0.png","batteryDigits_0001_1.png","batteryDigits_0002_2.png","batteryDigits_0003_3.png","batteryDigits_0004_4.png","batteryDigits_0005_5.png","batteryDigits_0006_6.png","batteryDigits_0007_7.png","batteryDigits_0008_8.png","batteryDigits_0009_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 352,
              image_array: ["b_10.png","b_20.png","b_30.png","b_40.png","b_50.png","b_60.png","b_70.png","b_80.png","b_90.png","b_100.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 23,
              font_array: ["batteryDigits_0000_0.png","batteryDigits_0001_1.png","batteryDigits_0002_2.png","batteryDigits_0003_3.png","batteryDigits_0004_4.png","batteryDigits_0005_5.png","batteryDigits_0006_6.png","batteryDigits_0007_7.png","batteryDigits_0008_8.png","batteryDigits_0009_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'battery_percent.png',
              unit_tc: 'battery_percent.png',
              unit_en: 'battery_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 7,
              image_array: ["b_10.png","b_20.png","b_30.png","b_40.png","b_50.png","b_60.png","b_70.png","b_80.png","b_90.png","b_100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 5,
              hour_startY: 156,
              hour_array: ["timeDigits_0000_0.png","timeDigits_0001_1.png","timeDigits_0002_2.png","timeDigits_0003_3.png","timeDigits_0004_4.png","timeDigits_0005_5.png","timeDigits_0006_6.png","timeDigits_0007_7.png","timeDigits_0008_8.png","timeDigits_0009_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 105,
              minute_startY: 156,
              minute_array: ["timeDigits_0000_0.png","timeDigits_0001_1.png","timeDigits_0002_2.png","timeDigits_0003_3.png","timeDigits_0004_4.png","timeDigits_0005_5.png","timeDigits_0006_6.png","timeDigits_0007_7.png","timeDigits_0008_8.png","timeDigits_0009_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 136,
              day_startY: 219,
              day_sc_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              day_tc_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              day_en_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 95,
              month_startY: 219,
              month_sc_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              month_tc_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              month_en_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 28,
              year_startY: 219,
              year_sc_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              year_tc_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              year_en_array: ["dateDigit_0000_0.png","dateDigit_0001_1.png","dateDigit_0002_2.png","dateDigit_0003_3.png","dateDigit_0004_4.png","dateDigit_0005_5.png","dateDigit_0006_6.png","dateDigit_0007_7.png","dateDigit_0008_8.png","dateDigit_0009_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 5,
              hour_startY: 156,
              hour_array: ["timeDigits_0000_0.png","timeDigits_0001_1.png","timeDigits_0002_2.png","timeDigits_0003_3.png","timeDigits_0004_4.png","timeDigits_0005_5.png","timeDigits_0006_6.png","timeDigits_0007_7.png","timeDigits_0008_8.png","timeDigits_0009_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 105,
              minute_startY: 156,
              minute_array: ["timeDigits_0000_0.png","timeDigits_0001_1.png","timeDigits_0002_2.png","timeDigits_0003_3.png","timeDigits_0004_4.png","timeDigits_0005_5.png","timeDigits_0006_6.png","timeDigits_0007_7.png","timeDigits_0008_8.png","timeDigits_0009_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });




            btnbrightnessdown = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 97,
              h: 43,
              text: '',
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                
                const currentBrightness = hmSetting.getBrightness();
                if (currentBrightness >= 10){
                  hmSetting.setBrightness(currentBrightness - 10);
                }

              },
              show_level: hmUI.show_level.ONLY_NORMAL
            });

            btnbrightnessdown.setProperty(hmUI.prop.VISIBLE, true);

            btnbrightnessup = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 97,
              y: 0,
              w: 97,
              h: 43,
              text: '',
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                
                const currentBrightness = hmSetting.getBrightness();
                if (currentBrightness <= 90){
                  hmSetting.setBrightness(currentBrightness + 10);
                }

              },
              show_level: hmUI.show_level.ONLY_NORMAL
            });

            btnbrightnessup.setProperty(hmUI.prop.VISIBLE, true);




            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 153,
              w: 85,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 153,
              w: 85,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 258,
              w: 60,
              h: 60,
              src: 'alarm.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 52,
              w: 60,
              h: 74,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 26,
              y: 258,
              w: 60,
              h: 60,
              src: 'bubbles.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 52,
              w: 60,
              h: 74,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 325,
              w: 194,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
