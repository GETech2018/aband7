﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_date_img_date_week_img = ''
        let idle_background_bg = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_date_img_date_week_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 4,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 173,
              y: 2,
              src: 'Rr5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 68,
              y: 5,
              src: 'Off_-_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 8,
              y: 3,
              src: 'Time-4.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 115,
              month_startY: 300,
              month_sc_array: ["GreyNoBorder-0.png","GreyNoBorder-1.png","GreyNoBorder-2.png","GreyNoBorder-3.png","GreyNoBorder-4.png","GreyNoBorder-5.png","GreyNoBorder-6.png","GreyNoBorder-7.png","GreyNoBorder-8.png","GreyNoBorder-9.png"],
              month_tc_array: ["GreyNoBorder-0.png","GreyNoBorder-1.png","GreyNoBorder-2.png","GreyNoBorder-3.png","GreyNoBorder-4.png","GreyNoBorder-5.png","GreyNoBorder-6.png","GreyNoBorder-7.png","GreyNoBorder-8.png","GreyNoBorder-9.png"],
              month_en_array: ["GreyNoBorder-0.png","GreyNoBorder-1.png","GreyNoBorder-2.png","GreyNoBorder-3.png","GreyNoBorder-4.png","GreyNoBorder-5.png","GreyNoBorder-6.png","GreyNoBorder-7.png","GreyNoBorder-8.png","GreyNoBorder-9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 5,
              day_startY: 300,
              day_sc_array: ["GreyNoBorder-0.png","GreyNoBorder-1.png","GreyNoBorder-2.png","GreyNoBorder-3.png","GreyNoBorder-4.png","GreyNoBorder-5.png","GreyNoBorder-6.png","GreyNoBorder-7.png","GreyNoBorder-8.png","GreyNoBorder-9.png"],
              day_tc_array: ["GreyNoBorder-0.png","GreyNoBorder-1.png","GreyNoBorder-2.png","GreyNoBorder-3.png","GreyNoBorder-4.png","GreyNoBorder-5.png","GreyNoBorder-6.png","GreyNoBorder-7.png","GreyNoBorder-8.png","GreyNoBorder-9.png"],
              day_en_array: ["GreyNoBorder-0.png","GreyNoBorder-1.png","GreyNoBorder-2.png","GreyNoBorder-3.png","GreyNoBorder-4.png","GreyNoBorder-5.png","GreyNoBorder-6.png","GreyNoBorder-7.png","GreyNoBorder-8.png","GreyNoBorder-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 78,
              y: 300,
              src: 'slash_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 5,
              minute_startY: 120,
              minute_array: ["CGR-blu-0.png","CGR-blu-1.png","CGR-blu-2.png","CGR-blu-3.png","CGR-blu-4.png","CGR-blu-5.png","CGR-blu-6.png","CGR-blu-7.png","CGR-blu-8.png","CGR-blu-9.png"],
              minute_zero: 1,
              minute_space: -22,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 15,
              hour_startY: 28,
              hour_array: ["GreyNeon-0.png","GreyNeon-1.png","GreyNeon-2.png","GreyNeon-3.png","GreyNeon-4.png","GreyNeon-5.png","GreyNeon-6.png","GreyNeon-7.png","GreyNeon-8.png","GreyNeon-9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: -1,
              y: 246,
              week_en: ["RusKG-1.png","RusKG-2.png","RusKG-3.png","RusKG-4.png","RusKG-5.png","RusKG-6.png","RusKG-7.png"],
              week_tc: ["RusKG-1.png","RusKG-2.png","RusKG-3.png","RusKG-4.png","RusKG-5.png","RusKG-6.png","RusKG-7.png"],
              week_sc: ["RusKG-1.png","RusKG-2.png","RusKG-3.png","RusKG-4.png","RusKG-5.png","RusKG-6.png","RusKG-7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 115,
              month_startY: 300,
              month_sc_array: ["GreyNoBorder-0.png","GreyNoBorder-1.png","GreyNoBorder-2.png","GreyNoBorder-3.png","GreyNoBorder-4.png","GreyNoBorder-5.png","GreyNoBorder-6.png","GreyNoBorder-7.png","GreyNoBorder-8.png","GreyNoBorder-9.png"],
              month_tc_array: ["GreyNoBorder-0.png","GreyNoBorder-1.png","GreyNoBorder-2.png","GreyNoBorder-3.png","GreyNoBorder-4.png","GreyNoBorder-5.png","GreyNoBorder-6.png","GreyNoBorder-7.png","GreyNoBorder-8.png","GreyNoBorder-9.png"],
              month_en_array: ["GreyNoBorder-0.png","GreyNoBorder-1.png","GreyNoBorder-2.png","GreyNoBorder-3.png","GreyNoBorder-4.png","GreyNoBorder-5.png","GreyNoBorder-6.png","GreyNoBorder-7.png","GreyNoBorder-8.png","GreyNoBorder-9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 5,
              day_startY: 300,
              day_sc_array: ["GreyNoBorder-0.png","GreyNoBorder-1.png","GreyNoBorder-2.png","GreyNoBorder-3.png","GreyNoBorder-4.png","GreyNoBorder-5.png","GreyNoBorder-6.png","GreyNoBorder-7.png","GreyNoBorder-8.png","GreyNoBorder-9.png"],
              day_tc_array: ["GreyNoBorder-0.png","GreyNoBorder-1.png","GreyNoBorder-2.png","GreyNoBorder-3.png","GreyNoBorder-4.png","GreyNoBorder-5.png","GreyNoBorder-6.png","GreyNoBorder-7.png","GreyNoBorder-8.png","GreyNoBorder-9.png"],
              day_en_array: ["GreyNoBorder-0.png","GreyNoBorder-1.png","GreyNoBorder-2.png","GreyNoBorder-3.png","GreyNoBorder-4.png","GreyNoBorder-5.png","GreyNoBorder-6.png","GreyNoBorder-7.png","GreyNoBorder-8.png","GreyNoBorder-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 78,
              y: 300,
              src: 'slash_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 5,
              minute_startY: 120,
              minute_array: ["CGR-blu-0.png","CGR-blu-1.png","CGR-blu-2.png","CGR-blu-3.png","CGR-blu-4.png","CGR-blu-5.png","CGR-blu-6.png","CGR-blu-7.png","CGR-blu-8.png","CGR-blu-9.png"],
              minute_zero: 1,
              minute_space: -22,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 15,
              hour_startY: 28,
              hour_array: ["GreyNeon-0.png","GreyNeon-1.png","GreyNeon-2.png","GreyNeon-3.png","GreyNeon-4.png","GreyNeon-5.png","GreyNeon-6.png","GreyNeon-7.png","GreyNeon-8.png","GreyNeon-9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: -1,
              y: 246,
              week_en: ["RusKG-1.png","RusKG-2.png","RusKG-3.png","RusKG-4.png","RusKG-5.png","RusKG-6.png","RusKG-7.png"],
              week_tc: ["RusKG-1.png","RusKG-2.png","RusKG-3.png","RusKG-4.png","RusKG-5.png","RusKG-6.png","RusKG-7.png"],
              week_sc: ["RusKG-1.png","RusKG-2.png","RusKG-3.png","RusKG-4.png","RusKG-5.png","RusKG-6.png","RusKG-7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}