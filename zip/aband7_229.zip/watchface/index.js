﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'fondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'cora-punto-largo.png',
              center_x: 150,
              center_y: 324,
              x: 7,
              y: 7,
              start_angle: 45,
              end_angle: 320,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 313,
              font_array: ["nro-01.png","nro-02.png","nro-03.png","nro-04.png","nro-05.png","nro-06.png","nro-07.png","nro-08.png","nro-09.png","nro-10.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 293,
              font_array: ["distancia-01.png","distancia-02.png","distancia-03.png","distancia-04.png","distancia-05.png","distancia-06.png","distancia-07.png","distancia-08.png","distancia-09.png","distancia-10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'distancia-11.png',
              unit_tc: 'distancia-11.png',
              unit_en: 'distancia-11.png',
              dot_image: 'distancia-12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 343,
              font_array: ["calorias01.png","calorias02.png","calorias03.png","calorias04.png","calorias05.png","calorias06.png","calorias07.png","calorias08.png","calorias09.png","calorias10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 317,
              font_array: ["Pasoss-01.png","Pasoss-02.png","Pasoss-03.png","Pasoss-04.png","Pasoss-05.png","Pasoss-06.png","Pasoss-07.png","Pasoss-08.png","Pasoss-09.png","Pasoss-10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 49,
              font_array: ["0-nro-clima.png","1-nro-clima-1.png","2-nro-clima-1b.png","3-nro-clima-2.png","4-nro-clima-3.png","5-nro-clima-4.png","6-nro-clima-5.png","7-nro-clima-6.png","8-nro-clima-7.png","9-nro-clima-8.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'nro-clima-10.png',
              unit_tc: 'nro-clima-10.png',
              unit_en: 'nro-clima-10.png',
              negative_image: 'nro-clima-9.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 42,
              image_array: ["weather01.png","weather02.png","weather03.png","weather04.png","weather05.png","weather06.png","weather07.png","weather08.png","weather09.png","weather10.png","weather11.png","weather12.png","weather13.png","weather14.png","weather15.png","weather16.png","weather17.png","weather18.png","weather19.png","weather20.png","weather21.png","weather22.png","weather23.png","weather24.png","weather25.png","weather26.png","weather27.png","weather28.png","weather29.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 14,
              font_array: ["bateria-01.png","bateria-02.png","bateria-03.png","bateria-04.png","bateria-05.png","bateria-06.png","bateria-07.png","bateria-08.png","bateria-09.png","bateria-10.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'bateria-nro-porcentaje.png',
              unit_tc: 'bateria-nro-porcentaje.png',
              unit_en: 'bateria-nro-porcentaje.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 8,
              y: 12,
              week_en: ["nombre-dia.png","nombre-dia-1.png","nombre-dia-2.png","nombre-dia-3.png","nombre-dia-4.png","nombre-dia-5.png","nombre-dia-6.png"],
              week_tc: ["nombre-dia.png","nombre-dia-1.png","nombre-dia-2.png","nombre-dia-3.png","nombre-dia-4.png","nombre-dia-5.png","nombre-dia-6.png"],
              week_sc: ["nombre-dia.png","nombre-dia-1.png","nombre-dia-2.png","nombre-dia-3.png","nombre-dia-4.png","nombre-dia-5.png","nombre-dia-6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 60,
              month_startY: 38,
              month_sc_array: ["nombre-mes.png","nombre-mes-1.png","nombre-mes-2.png","nombre-mes-3.png","nombre-mes-4.png","nombre-mes-5.png","nombre-mes-6.png","nombre-mes-7.png","nombre-mes-8.png","nombre-mes-9.png","nombre-mes-10.png","nombre-mes-11.png"],
              month_tc_array: ["nombre-mes.png","nombre-mes-1.png","nombre-mes-2.png","nombre-mes-3.png","nombre-mes-4.png","nombre-mes-5.png","nombre-mes-6.png","nombre-mes-7.png","nombre-mes-8.png","nombre-mes-9.png","nombre-mes-10.png","nombre-mes-11.png"],
              month_en_array: ["nombre-mes.png","nombre-mes-1.png","nombre-mes-2.png","nombre-mes-3.png","nombre-mes-4.png","nombre-mes-5.png","nombre-mes-6.png","nombre-mes-7.png","nombre-mes-8.png","nombre-mes-9.png","nombre-mes-10.png","nombre-mes-11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 16,
              day_startY: 34,
              day_sc_array: ["nro-dia.png","nro-dia-1.png","nro-dia-2.png","nro-dia-3.png","nro-dia-4.png","nro-dia-5.png","nro-dia-6.png","nro-dia-7.png","nro-dia-8.png","nro-dia-9.png"],
              day_tc_array: ["nro-dia.png","nro-dia-1.png","nro-dia-2.png","nro-dia-3.png","nro-dia-4.png","nro-dia-5.png","nro-dia-6.png","nro-dia-7.png","nro-dia-8.png","nro-dia-9.png"],
              day_en_array: ["nro-dia.png","nro-dia-1.png","nro-dia-2.png","nro-dia-3.png","nro-dia-4.png","nro-dia-5.png","nro-dia-6.png","nro-dia-7.png","nro-dia-8.png","nro-dia-9.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 74,
              hour_array: ["hora-nro.png","hora-nro-1.png","hora-nro-2.png","hora-nro-3.png","hora-nro-4.png","hora-nro-5.png","hora-nro-6.png","hora-nro-7.png","hora-nro-8.png","hora-nro-9.png"],
              hour_zero: 1,
              hour_space: -9,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 20,
              minute_startY: 179,
              minute_array: ["hora-nro.png","hora-nro-1.png","hora-nro-2.png","hora-nro-3.png","hora-nro-4.png","hora-nro-5.png","hora-nro-6.png","hora-nro-7.png","hora-nro-8.png","hora-nro-9.png"],
              minute_zero: 1,
              minute_space: -9,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 74,
              hour_array: ["always-01.png","always-02.png","always-03.png","always-04.png","always-05.png","always-06.png","always-07.png","always-08.png","always-09.png","always-10.png"],
              hour_zero: 1,
              hour_space: -9,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 20,
              minute_startY: 179,
              minute_array: ["always-01.png","always-02.png","always-03.png","always-04.png","always-05.png","always-06.png","always-07.png","always-08.png","always-09.png","always-10.png"],
              minute_zero: 1,
              minute_space: -9,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}