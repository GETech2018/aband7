﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright c SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Overlay/Pop-up perpetual calendar by OnocoroMM
// Alrights reserved.


// for calendar
let Transparent_Switch_BG = null;
let temporary_button = null;
let isLikeVisible = false;

// for brightness controll by @shockwave55
let btnbrightnessdown = ''
let btnbrightnessup = ''

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''




        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 40,
              y: 274,
              src: 'calendar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 7,
              y: 332,
              font_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'mi.png',
              imperial_unit_tc: 'mi.png',
              imperial_unit_en: 'mi.png',
              dot_image: 'decimal.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 8,
              y: 22,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 93,
              font_array: ["pulse_0.png","pulse_1.png","pulse_2.png","pulse_3.png","pulse_4.png","pulse_5.png","pulse_6.png","pulse_7.png","pulse_8.png","pulse_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'celsius2.png',
              unit_tc: 'celsius2.png',
              unit_en: 'celsius2.png',
              negative_image: 'negative.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 123,
              y: 51,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 136,
              day_startY: 219,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 95,
              month_startY: 219,
              month_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 28,
              year_startY: 219,
              year_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              year_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              year_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 93,
              font_array: ["pulse_0.png","pulse_1.png","pulse_2.png","pulse_3.png","pulse_4.png","pulse_5.png","pulse_6.png","pulse_7.png","pulse_8.png","pulse_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 332,
              font_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 352,
              image_array: ["b_10.png","b_20.png","b_30.png","b_40.png","b_50.png","b_60.png","b_70.png","b_80.png","b_90.png","b_100.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 23,
              font_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'battery_percent.png',
              unit_tc: 'battery_percent.png',
              unit_en: 'battery_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 7,
              image_array: ["b_10.png","b_20.png","b_30.png","b_40.png","b_50.png","b_60.png","b_70.png","b_80.png","b_90.png","b_100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 5,
              hour_startY: 156,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 105,
              minute_startY: 156,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'AnaBackground-01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hours.png',
              hour_centerX: 99,
              hour_centerY: 184,
              hour_posX: 16,
              hour_posY: 113,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'MinuteswSec.png',
              minute_centerX: 99,
              minute_centerY: 184,
              minute_posX: 16,
              minute_posY: 152,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Seconds.png',
              second_centerX: 100,
              second_centerY: 184,
              second_posX: 14,
              second_posY: 151,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

//
// brightness controll by @shockwave55
//
btnbrightnessdown = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 0,
  y: 0,
  w: 97,
  h: 43,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  click_func: () => {
    const currentBrightness = hmSetting.getBrightness();
    if (currentBrightness >= 10){
      hmSetting.setBrightness(currentBrightness - 10);
    }
  },
  show_level: hmUI.show_level.ONLY_NORMAL
});
btnbrightnessdown.setProperty(hmUI.prop.VISIBLE, true);

btnbrightnessup = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 97,
  y: 0,
  w: 97,
  h: 43,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  click_func: () => {
    const currentBrightness = hmSetting.getBrightness();
    if (currentBrightness <= 90){
      hmSetting.setBrightness(currentBrightness + 10);
    }
  },
  show_level: hmUI.show_level.ONLY_NORMAL
});
btnbrightnessup.setProperty(hmUI.prop.VISIBLE, true);

//
// end brightness controll
//
            // end user_script_beforeShortcuts.js
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 98,
              y: 325,
              w: 96,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 52,
              w: 60,
              h: 74,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 52,
              w: 60,
              h: 74,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 153,
              w: 85,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 153,
              w: 85,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 258,
              w: 60,
              h: 60,
              src: 'alarm.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_end.js');
            // start user_script_end.js

// カレンダー画像を事前に作成（非表示でスタート）
let temporary_background_img = hmUI.createWidget(hmUI.widget.IMG, {
  x: 0,
  y: 0,
  w: 194,
  h: 368,
  src: "like.png",
  visible: true,
  show_level: hmUI.show_level.ONLY_NORMAL,
});

// 後から非表示に設定（createWidget 後に必ず呼ぶ）
temporary_background_img.setProperty(hmUI.prop.VISIBLE, false);


// 透明ボタンを配置（0, 264）に w96xh110
 temporary_button = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 0,
  y: 264,
  w: 96,
  h: 110,
  text: '',
  color: 0x00000000,         // 完全透明
  text_size: 0,
  radius: 0,
  press_src: '0_Empty.png',  // 透明画像
  normal_src: '0_Empty.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: function () {
    // トグル処理
    isLikeVisible = !isLikeVisible;
    temporary_background_img.setProperty(hmUI.prop.VISIBLE, isLikeVisible);

   // Calendar
    syncCalendarWithLikeVisibility();
  }
});

// === Calendar overlay ===
// ▼ CAL_Y を約10px上げる（74 → 64）
const CAL_X = 8;
const CAL_Y = 64;
const HEADER_W = 194;
const HEADER_H = 20;      // 見出し高さは流用

// ▼ 曜日行の追加
const WEEK_LABELS = ['S','M','T','W','T','F','S'];
const WEEK_TEXT_SIZE = 16;
const WEEK_H = 18;        // 曜日テキストの行高さ
const WEEK_SPACING = 10;  // 見出しとの間隔 ≒10px

// ▼ グリッドの位置を「曜日行の下」に変更
// （以前は GRID_Y = CAL_Y + 24 でしたが、以下のように差し替え）
const GRID_TOP_GAP = 4;   // 曜日行とグリッドの間の小さな余白
const GRID_Y = CAL_Y + HEADER_H + WEEK_SPACING + WEEK_H + GRID_TOP_GAP;

// 以降は既存どおり
const CELL_W = 26;
const CELL_H = 26;
const COLS = 7;
const ROWS = 6;
const GAP_X = 2;
const GAP_Y = 2;
const CAL_W = (CELL_W * COLS) + (GAP_X * (COLS - 1));
const CAL_H = (CELL_H * ROWS) + (GAP_Y * (ROWS - 1));


let calendarVisible = false;
let calendarMonthOffset = 0; // 0=当月, -1=前月, +1=翌月
let calendarHeaderText = null;
let calendarDateTextArr = [];
let calendarTodayCircleArr = [];
let calTapLeft = null, calTapCenter = null, calTapRight = null;

let calendarWeekTextArr = [];  // ← 追加（曜日テキスト配列）

// ヘッダー（年/月）表示（既存）
calendarHeaderText = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 0,
  y: CAL_Y,
  w: HEADER_W,
  h: HEADER_H,
  text: '',
  text_size: 20,                 // 見出しのサイズは必要に応じて調整可
  color: 0xFFFFFFFF,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  show_level: hmUI.show_level.ONLY_NORMAL,
  visible: false,
});

// ▼ 曜日テキスト行（新規追加）
const weekBaseX = Math.floor((194 - CAL_W) / 2); // グリッドと同じ中央寄せ
const weekY = CAL_Y + HEADER_H + WEEK_SPACING;

for (let c = 0; c < COLS; c++) {
  const wx = weekBaseX + c * (CELL_W + GAP_X);
  const wtxt = hmUI.createWidget(hmUI.widget.TEXT, {
    x: wx,
    y: weekY,
    w: CELL_W,
    h: WEEK_H,
    text: WEEK_LABELS[c],
    text_size: WEEK_TEXT_SIZE,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    color: (c === 0) ? 0xFFFF0000       // 日曜=赤
         : (c === 6) ? 0xFF00BFFF       // 土曜=ディープスカイブルー
         : 0xFFFFFFFF,                  // 平日=白
    show_level: hmUI.show_level.ONLY_NORMAL,
    visible: false,
  });
  calendarWeekTextArr.push(wtxt);
}

// 42個のセル（テキスト＋今日○用IMG）
for (let i = 0; i < ROWS * COLS; i++) {
  const col = i % COLS;
  const row = Math.floor(i / COLS);
  const x = Math.floor((194 - CAL_W) / 2) + col * (CELL_W + GAP_X); // 画面中央寄せ
  const y = GRID_Y + row * (CELL_H + GAP_Y);

  // ○（今日マーク）
  const circle = hmUI.createWidget(hmUI.widget.IMG, {
    x: x + Math.floor((CELL_W - 20) / 2),
    y: y + Math.floor((CELL_H - 20) / 2),
    w: 20,
    h: 20,
    src: 'circle_hotpink.png', // 透過背景のホットピンク輪
    visible: false,
    show_level: hmUI.show_level.ONLY_NORMAL,
  });
  calendarTodayCircleArr.push(circle);

  // 日付テキスト
  const txt = hmUI.createWidget(hmUI.widget.TEXT, {
    x,
    y,
    w: CELL_W,
    h: CELL_H,
    text: '',
    text_size: 18,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    color: 0xFFFFFFFF,
    show_level: hmUI.show_level.ONLY_NORMAL,
    visible: false,
  });
  calendarDateTextArr.push(txt);
}

// 3分割タップ（左=前月 / 中=当月 / 右=翌月）
// カレンダーが非表示のときは自動的に無効化（visible=false）
const TAP_Y = CAL_Y;                 // ヘッダーからグリッド全体まで覆う
//const TAP_H = HEADER_H + 6 + CAL_H;  // ざっくり全体をカバー
const TAP_H = 312 - TAP_Y;  // 高さを312pxまでにする
const THIRD = Math.floor(194 / 3);

calTapLeft = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 0,
  y: TAP_Y,
  w: THIRD,
  h: TAP_H,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  color: 0x00000000,
  radius: 0,
  visible: false,
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    if (!calendarVisible) return;
    calendarMonthOffset -= 1;
    updateCalendar();
  }
});

calTapCenter = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: THIRD,
  y: TAP_Y,
  w: THIRD,
  h: TAP_H,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  color: 0x00000000,
  radius: 0,
  visible: false,
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    if (!calendarVisible) return;
    calendarMonthOffset = 0;
// いったん“今日マーク”を全て消す（前回の表示が残るのを防止）
    calendarTodayCircleArr.forEach(c => c.setProperty(hmUI.prop.VISIBLE, false));
    updateCalendar();
  }
});

calTapRight = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: THIRD * 2,
  y: TAP_Y,
  w: 194 - THIRD * 2,
  h: TAP_H,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  color: 0x00000000,
  radius: 0,
  visible: false,
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    if (!calendarVisible) return;
    calendarMonthOffset += 1;
    updateCalendar();
  }
});

function setCalendarVisible(v) {
  calendarVisible = !!v;
  calendarHeaderText.setProperty(hmUI.prop.VISIBLE, calendarVisible);
  calendarDateTextArr.forEach(w => w.setProperty(hmUI.prop.VISIBLE, calendarVisible));
// ▼ 曜日行（追加）
  calendarWeekTextArr.forEach(w => w.setProperty(hmUI.prop.VISIBLE, calendarVisible));

  calendarTodayCircleArr.forEach(w => w.setProperty(hmUI.prop.VISIBLE, false)); // 初期は消しておく
  calTapLeft.setProperty(hmUI.prop.VISIBLE, calendarVisible);
  calTapCenter.setProperty(hmUI.prop.VISIBLE, calendarVisible);
  calTapRight.setProperty(hmUI.prop.VISIBLE, calendarVisible);
}

// ヘッダー表記：当月は "- YYYY/MM -"、それ以外は " YYYY/MM "
function headerLabel(year, month0based) {
  const y = year;
  const m = (month0based + 1).toString().padStart(2, '0');
  if (calendarMonthOffset === 0) return `- ${y}/${m} -`;
  return ` ${y}/${m} `;
}

// カレンダー描画本体
function updateCalendar() {
  // 基準日（端末の現在日）
  const now = new Date();
  const baseY = now.getFullYear();
  const baseM0 = now.getMonth(); // 0-11
  const baseD = now.getDate();

  // 表示対象（オフセット適用）
  const target = new Date(baseY, baseM0 + calendarMonthOffset, 1);
  const y = target.getFullYear();
  const m0 = target.getMonth();

  // 1日が週の何曜か（0=Sun..6=Sat）
  const firstDow = new Date(y, m0, 1).getDay();
  // 月末（日数）
  const daysInMonth = new Date(y, m0 + 1, 0).getDate();

  // ヘッダー更新（当月は - YYYY/MM -、それ以外は " YYYY/MM "）
  calendarHeaderText.setProperty(hmUI.prop.TEXT, headerLabel(y, m0));

  // ---- ここから “今日マーク” を厳密制御 ----
  // 当月表示なら “今日” のセルのグローバルINDEXを算出。それ以外は -1
  const todayIndex = (calendarMonthOffset === 0)
    ? (firstDow + (baseD - 1))  // 0..41
    : -1;

  for (let i = 0; i < 42; i++) {
    const txt = calendarDateTextArr[i];
    const circle = calendarTodayCircleArr[i];

    const dayNum = i - firstDow + 1; // そのセルが示す当月日
    if (dayNum >= 1 && dayNum <= daysInMonth) {
      // 日付テキスト
      txt.setProperty(hmUI.prop.TEXT, `${dayNum}`);

      // 曜日色（0=日,6=土）
      const col = i % 7;
      if (col === 0) txt.setProperty(hmUI.prop.COLOR, 0xFFFF0000);      // 日=赤
      else if (col === 6) txt.setProperty(hmUI.prop.COLOR, 0xFF00BFFF); // 土=青
      else txt.setProperty(hmUI.prop.COLOR, 0xFFFFFFFF);                // 平日=白
    } else {
      // 当月外は空欄
      txt.setProperty(hmUI.prop.TEXT, '');
    }

    // ○の表示は “そのセルが当月かつ i===todayIndex のときだけ true”
    const circleVisible = (dayNum >= 1 && dayNum <= daysInMonth && i === todayIndex);
    circle.setProperty(hmUI.prop.VISIBLE, circleVisible);
  }
}

// トグルに連動してカレンダー表示を制御
// 既存 temporary_button の click_func の末尾にこの2行を追加してもOK
function syncCalendarWithLikeVisibility() {
  setCalendarVisible(isLikeVisible); // 非表示ならタップも消える
  if (calendarVisible) {
    // 初回は当月を出す
    if (calendarMonthOffset !== 0) calendarMonthOffset = 0;
    updateCalendar();
  }
}

// 初期は非表示
setCalendarVisible(false);

// 日付が変わったら、表示中のカレンダーを更新
if (!timeSensor) {
  timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
}
timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
  if (calendarVisible) {
    updateCalendar();
  }
});

            // end user_script_end.js

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                console.log('resume_call.js');
                // start resume_call.js

// update the today's mark
if (calendarVisible) updateCalendar();
                // end resume_call.js

              }),
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}