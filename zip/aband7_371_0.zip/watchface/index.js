﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright c SashaCX75. All Rights Reserved
    */
    /*
    ** Band7 watch face with perpetual calendar
    ** programmed with using above tool by OnoccoroMM.
    ** Copyright c OnoccoroMM. All Rights Reserved
    */
   
    try {
    (() => {
 
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['(月)', '(火)', '(水)', '(木)', '(金)', '(土)', '(日)'];
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_cal_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let timeSensor = '';



function getHolidayMap(year) {
  const fixedHolidays = {
    "1/1": "元日",
    "2/11": "建国記念の日",
    "2/23": "天皇誕生日",
    "4/29": "昭和の日",
    "5/3": "憲法記念日",
    "5/4": "みどりの日",
    "5/5": "こどもの日",
        "8/11": "山の日",
        "11/3": "文化の日",
    "11/23": "勤労感謝の日"
  };

  // 春分・秋分の日（近似）
  const shunbun = Math.floor(20.8431 + 0.242194 * (year - 1980)) - Math.floor((year - 1980)/4);
  const shubun = Math.floor(23.2488 + 0.242194 * (year - 1980)) - Math.floor((year - 1980)/4);
  fixedHolidays[`3/${shunbun}`] = "春分の日";
  fixedHolidays[`9/${shubun}`] = "秋分の日";

  // 成人の日（1月第2月曜日）
  const janFirst = new Date(year, 0, 1);
  let janMondayCount = 0;
  for (let d = 1; d <= 14; d++) {
    const tmp = new Date(year, 0, d);
    if (tmp.getDay() === 1) {
      janMondayCount++;
      if (janMondayCount === 2) {
        fixedHolidays[`1/${d}`] = "成人の日";
        break;
      }
    }
  }

  // スポーツの日（10月第2月曜日）
  const octFirst = new Date(year, 9, 1);
  let octMondayCount = 0;
  for (let d = 1; d <= 14; d++) {
    const tmp = new Date(year, 9, d);
    if (tmp.getDay() === 1) {
      octMondayCount++;
      if (octMondayCount === 2) {
        fixedHolidays[`10/${d}`] = "スポーツの日";
        break;
      }
    }
  }

  // 振替休日: 5月6日が対象（5月3?5が日曜の場合）
  const mayCheck = [3, 4, 5];
  for (let i = 0; i < mayCheck.length; i++) {
    const checkDate = new Date(year, 4, mayCheck[i]); // May = 4
    if (checkDate.getDay() === 0) {
      fixedHolidays["5/6"] = "振替休日";
      break;
    }
  }

  // 敬老の日（9月第3月曜日）
  const sepFirst = new Date(year, 8, 1); // 9月1日
  let sepMondayCount = 0;
  for (let d = 1; d <= 21; d++) {
    const tmp = new Date(year, 8, d);
    if (tmp.getDay() === 1) {
      sepMondayCount++;
      if (sepMondayCount === 3) {
        fixedHolidays[`9/${d}`] = "敬老の日";
        break;
      }
    }
  }

  // 海の日（7月第3月曜日）
  const julFirst = new Date(year, 6, 1); // 7月1日
  let julMondayCount = 0;
  for (let d = 1; d <= 21; d++) {
    const tmp = new Date(year, 6, d);
    if (tmp.getDay() === 1) {
      julMondayCount++;
      if (julMondayCount === 3) {
        fixedHolidays[`7/${d}`] = "海の日";
        break;
      }
    }
  }

  // 国民の休日（前後が祝日の平日）
  const holidayDates = Object.keys(fixedHolidays).map(key => {
    const [m, d] = key.split("/").map(Number);
    return new Date(year, m - 1, d).getTime();
  });
  holidayDates.sort((a, b) => a - b);

  for (let i = 0; i < holidayDates.length - 1; i++) {
    const prev = new Date(holidayDates[i]);
    const next = new Date(holidayDates[i + 1]);
    const gap = (next.getTime() - prev.getTime()) / (1000 * 60 * 60 * 24);

    if (gap === 2) {
      const mid = new Date(prev.getTime() + 24 * 60 * 60 * 1000);
      const key = `${mid.getMonth() + 1}/${mid.getDate()}`;
      if (!fixedHolidays[key]) {
        fixedHolidays[key] = "国民の休日";
      }
    }
  }

  return fixedHolidays;
}

function isHoliday(year, month, day, dayOfWeek, holidayMap) {
  const key = `${month}/${day}`;
  const isFixed = holidayMap.hasOwnProperty(key);

  // 振替休日（祝日が日曜日の場合、翌月曜日が振替休日）
  if (!isFixed && dayOfWeek === 1) {
    const yesterday = `${month}/${day - 1}`;
    const yesterdayDate = new Date(year, month - 1, day - 1);
    if (holidayMap.hasOwnProperty(yesterday) && yesterdayDate.getDay() === 0) {
      return true;
    }
  }
  return isFixed;
}




// --- カレンダーウィジェットを初期化して使い回す ---
let calendar_dateWidgets = [];
let calendar_headerWidget = null;
let underlineWidget = null;
let calendar_weekdayWidgets = [];
let calendar_currentDate = new Date();
let calendar_lastCheckedDate = new Date();

//  const calendar_baseX = 12;
//  const calendar_baseY = 135;
//  const calendar_cellW = 22;
//  const calendar_cellH = 21;

const calendar_baseX = 18;
const calendar_baseY = 135;
const calendar_cellW = 22;
const calendar_cellH = 21;

function initCalendarWidgets() {

  // 年月表示ウィジェット
  calendar_headerWidget = hmUI.createWidget(hmUI.widget.TEXT, {
    x: calendar_baseX,
    y: calendar_baseY,
    w: 160,
    h: 32,
    text_size: 28,
    align_h: hmUI.align.CENTER_H,
    color: 0xFFFFFF,
    text: "",
    show_level: hmUI.show_level.ONLY_NORMAL,
  });



  // 曜日ウィジェット
  const weekdayColors = [0xFF0000, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0x00BFFF];
  const weekdays = ["月", "火", "水", "木", "金", "土", "日"];
  for (let i = 0; i < 7; i++) {
    const widget = hmUI.createWidget(hmUI.widget.TEXT, {
      x: calendar_baseX + i * calendar_cellW,
      y: calendar_baseY + 40,
      w: calendar_cellW,
      h: calendar_cellH,
      text_size: 14,
      align_h: hmUI.align.CENTER_H,
      color: weekdayColors[i],
      text: weekdays[i],
      show_level: hmUI.show_level.ONLY_NORMAL,
    });
    calendar_weekdayWidgets.push(widget);
  }

  // 日付ウィジェット
  const calendar_dateBaseY = calendar_baseY + 60;
  for (let row = 0; row < 6; row++) {
    for (let col = 0; col < 7; col++) {
      const widget = hmUI.createWidget(hmUI.widget.TEXT, {
        x: calendar_baseX + col * calendar_cellW,
        y: calendar_dateBaseY + row * calendar_cellH,
        w: calendar_cellW,
        h: calendar_cellH,
        text_size: 14,
        align_h: hmUI.align.CENTER_H,
        color: 0xFFFFFF,
        text: "",
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
      calendar_dateWidgets.push(widget);
    }
  }
}

function drawCalendar(date) {

  const weekdayColors = [0xFF0000, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0x00BFFF];

  const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
  const startDay = firstDay.getDay();
  const daysInMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const today = new Date();


  const isCurrentMonth = (today.getFullYear() === date.getFullYear() && today.getMonth() === date.getMonth());

  let yearMonthStr = `${date.getFullYear()}/${String(date.getMonth() + 1).padStart(2, '0')}`;
  if (isCurrentMonth) yearMonthStr = `- ${yearMonthStr} -`;
  calendar_headerWidget.setProperty(hmUI.prop.MORE, { text: yearMonthStr });

  let dateNum = 1;
  let row = 0;

 


  for (let i = 0; i < 42; i++) {
    const col = i % 7;
    const x = calendar_baseX + col * calendar_cellW;
    const y = calendar_baseY + 60 + row * calendar_cellH;

    const isToday = () => {
    const now = new Date();
    return now.getFullYear() === date.getFullYear()
      && now.getMonth() === date.getMonth()
      && now.getDate() === dateNum;
};

    if (i >= startDay && dateNum <= daysInMonth) {
	const highlightToday = isToday();
	const isHolidayToday = isHoliday(date.getFullYear(), date.getMonth() + 1, dateNum, col, getHolidayMap(date.getFullYear()));
const color = highlightToday
  ? 0xFFB6C1
  : isHolidayToday
    ? 0xFF0000
    : weekdayColors[col];

//デバッグ用
//if (highlightToday) {
//  hmUI.showToast({
//    text: `isCurrentMonth: ${isCurrentMonth}, dateNum: ${dateNum}`,
//    duration: 2000  // 表示時間（ミリ秒）
//  });
//}
//

      calendar_dateWidgets[i].setProperty(hmUI.prop.MORE, {
        text: String(dateNum).padStart(2, ' '),
        color: color
      });
      calendar_dateWidgets[i].setProperty(hmUI.prop.VISIBLE, true);
      dateNum++;
    } else {
      calendar_dateWidgets[i].setProperty(hmUI.prop.VISIBLE, false);
    }
    if (col === 6) row++;
  }
}

function checkTodayUpdate() {
  const now = new Date();
  if (now.getDate() !== calendar_lastCheckedDate.getDate() ||
      now.getMonth() !== calendar_lastCheckedDate.getMonth() ||
      now.getFullYear() !== calendar_lastCheckedDate.getFullYear()) {

    calendar_currentDate = new Date(now); // ← 新しい calendar_currentDate を生成
    drawCalendar(calendar_currentDate);   // ← カレンダーを再描画
    calendar_lastCheckedDate = new Date(now); // ← 日付を更新
  }
}

// WATCHFACE_UPDATE_EVENT を追加
// hmApp.registerWatchFaceUpdateEvent(() => {
//   checkTodayUpdate();
//});

///

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 121,
              y: 338,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 337,
              font_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 14,
              y: 337,
              src: 'Steps3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 153,
              y: 338,
              image_array: ["batt_10.png","batt_11.png","batt_12.png","batt_13.png","batt_14.png","batt_15.png","batt_16.png","batt_17.png","batt_18.png","batt_19.png","batt_20.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 6,
              image_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 51,
              y: 3,
              w: 79,
              h: 41,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 132,
              y: 12,
              w: 57,
              h: 43,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: (月), (火), (水), (木), (金), (土), (日),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 64,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 109,
              minute_startY: 64,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'AnaBackground-02.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hours.png',
              hour_centerX: 99,
              hour_centerY: 184,
              hour_posX: 14,
              hour_posY: 114,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minutes.png',
              minute_centerX: 99,
              minute_centerY: 184,
              minute_posX: 16,
              minute_posY: 153,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Seconds.png',
              second_centerX: 99,
              second_centerY: 184,
              second_posX: 12,
              second_posY: 151,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 335,
              w: 194,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 1,
              y: 52,
              w: 86,
              h: 75,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,
              y: 52,
              w: 95,
              h: 76,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 0,
              w: 196,
              h: 44,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

     // カレンダー描画とタップエリア追加
    initCalendarWidgets();
    drawCalendar(calendar_currentDate);


const screenWidth = 194;
const tapAreaHeight = 200;
const tapAreaY = 130;


// 前月ボタン (左1/4)
const prevBtn = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 0,
  y: tapAreaY,
  w: screenWidth * 0.25, // 48px
  h: tapAreaHeight,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    calendar_currentDate.setMonth(calendar_currentDate.getMonth() - 1);
    drawCalendar(calendar_currentDate);
    checkTodayUpdate();
  }
});
prevBtn.setProperty(hmUI.prop.VISIBLE, true);

// 今月に戻るボタン (中央1/2)
const currentBtn = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: screenWidth * 0.25, // 48px
  y: tapAreaY,
  w: screenWidth * 0.5,  // 97px
  h: tapAreaHeight,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    calendar_currentDate = new Date();
    drawCalendar(calendar_currentDate);
    checkTodayUpdate();
  }
});
currentBtn.setProperty(hmUI.prop.VISIBLE, true);

// 次月ボタン (右1/4)
const nextBtn = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: screenWidth * 0.75, // 145px
  y: tapAreaY,
  w: screenWidth * 0.25, // 49px
  h: tapAreaHeight,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    calendar_currentDate.setMonth(calendar_currentDate.getMonth() + 1);
    drawCalendar(calendar_currentDate);
    checkTodayUpdate();
  }
});
nextBtn.setProperty(hmUI.prop.VISIBLE, true);

// 一度実行しておく
checkTodayUpdate();
///
                //dynamic modify end
            },

	    onShow() {
	    	console.log("WatchFace onShow invoked");
	    	calendar_currentDate = new Date();         // 現在日時を取得し直す
	    	drawCalendar(calendar_currentDate);        // カレンダーを再描画
	    },

            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}