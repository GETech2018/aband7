﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: -192,
              year_startY: 60,
              year_sc_array: ["reiwa00.png","reiwa01.png","reiwa02.png","reiwa03.png","reiwa04.png","reiwa05.png","reiwa06.png","reiwa07.png","reiwa08.png","reiwa09.png"],
              year_tc_array: ["reiwa00.png","reiwa01.png","reiwa02.png","reiwa03.png","reiwa04.png","reiwa05.png","reiwa06.png","reiwa07.png","reiwa08.png","reiwa09.png"],
              year_en_array: ["reiwa00.png","reiwa01.png","reiwa02.png","reiwa03.png","reiwa04.png","reiwa05.png","reiwa06.png","reiwa07.png","reiwa08.png","reiwa09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 332,
              font_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 352,
              image_array: ["b_10.png","b_20.png","b_30.png","b_40.png","b_50.png","b_60.png","b_70.png","b_80.png","b_90.png","b_100.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 30,
              month_startY: 100,
              month_sc_array: ["r0.png","r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              month_tc_array: ["r0.png","r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              month_en_array: ["r0.png","r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              month_zero: 1,
              month_space: 4,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 90,
              day_startY: 100,
              day_sc_array: ["r0.png","r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              day_tc_array: ["r0.png","r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              day_en_array: ["r0.png","r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 150,
              y: 100,
              week_en: ["ws01.png","ws02.png","ws03.png","ws04.png","ws05.png","ws06.png","ws07.png"],
              week_tc: ["ws01.png","ws02.png","ws03.png","ws04.png","ws05.png","ws06.png","ws07.png"],
              week_sc: ["ws01.png","ws02.png","ws03.png","ws04.png","ws05.png","ws06.png","ws07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 23,
              font_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'battery_percent.png',
              unit_tc: 'battery_percent.png',
              unit_en: 'battery_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 7,
              image_array: ["b_10.png","b_20.png","b_30.png","b_40.png","b_50.png","b_60.png","b_70.png","b_80.png","b_90.png","b_100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 2,
              hour_startY: 150,
              hour_array: ["bg00.png","bg01.png","bg02.png","bg03.png","bg04.png","bg05.png","bg06.png","bg07.png","bg08.png","bg09.png"],
              hour_zero: 0,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 105,
              minute_startY: 150,
              minute_array: ["bg00.png","bg01.png","bg02.png","bg03.png","bg04.png","bg05.png","bg06.png","bg07.png","bg08.png","bg09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 2,
              hour_startY: 170,
              hour_array: ["ts_0.png","ts_1.png","ts_2.png","ts_3.png","ts_4.png","ts_5.png","ts_6.png","ts_7.png","ts_8.png","ts_9.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 105,
              minute_startY: 170,
              minute_array: ["ts_0.png","ts_1.png","ts_2.png","ts_3.png","ts_4.png","ts_5.png","ts_6.png","ts_7.png","ts_8.png","ts_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}