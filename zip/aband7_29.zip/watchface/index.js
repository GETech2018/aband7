﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'main1.png',
              show_level: hmUI.show_level.ALL,
            });


////////////////////////////////////////////////////////////////////
            // required variables
            const valueStepImg = new Array(5);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY[i] = "number_" + i + ".png";  // set of images with numbers
            }
            let units_step_img = ''
            // *******************************************************************
            // initial variables, affect the position and display of data
            // *******************************************************************
            const X_step = 12;                // X coordinate of the top right corner of the inscription
            const Y_step = 136;                // X coordinate of the top right corner of the inscription
            const Angle_step = -90;               // The angle of the inscription, 0 degrees corresponds to the horizontal position of the inscription
            const CharSpace_step = 1;            // Space between characters
            const ImageWidht_step = 28;          // Width of character image
            const ImageHeight_step = 36;         // Height of character image
            const UnitsWidht_step = 1;          // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
            const Aligment_step = 0;            // -1=Left aligment; 0=Centr aligment; 1=Right aligment.
             // *******************************************************************
            // auxiliary variables, for calculating the position of characters
            // *******************************************************************
            const Diagonal_step = Math.hypot(ImageWidht_step, ImageHeight_step);
            const DiagonalUnits_step = Math.hypot(UnitsWidht_step, ImageHeight_step);
            let WI_size_step = Diagonal_step * 2;                    // Widget hight and widht
            let WI_units_size_step = DiagonalUnits_step * 2;         // Widget units hight and widht
            // *******************************************************************
            let char_delta_x_step = Math.cos(toRadian(Angle_step)) * ( ImageWidht_step + CharSpace_step );
		        let char_delta_y_step = Math.sin(toRadian(Angle_step)) * ( ImageWidht_step + CharSpace_step );
            let StartPosX_step = X_step;
            let StartPosY_step = Y_step;
            // *******************************************************************
            // Auxiliary functions
            function toRadian(degree) {
                return degree * (Math.PI / 180);
            };
            // *******************************************************************

            for ( let i = 0; i < 5; i++ ){
              valueStepImg[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            
            units_step_img = hmUI.createWidget(hmUI.widget.IMG, { });
            // *******************************************************************
            // *******************************************************************



             // required variables
             const valueCalorieImg = new Array(5);  // maximum display data length 5 characters (99999)
             for (let i = 0; i < 10; i++) {
               ASCIIARRAY[i] = "number_" + i + ".png";  // set of images with numbers
             }
             let units_calorie_img = ''
             // *******************************************************************
             // initial variables, affect the position and display of data
             // *******************************************************************
             const X_calorie = 144;                // X coordinate of the top left corner of the inscription
             const Y_calorie = 136;                // X coordinate of the top left corner of the inscription
             const Angle_calorie = -90;               // The angle of the inscription, 0 degrees corresponds to the horizontal position of the inscription
             const CharSpace_calorie = 1;            // Space between characters
             const ImageWidht_calorie = 28;          // Width of character image
             const ImageHeight_calorie = 36;         // Height of character image
             const UnitsWidht_calorie = 1;          // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
             const Aligment_calorie = 0;            // -1=Left aligment; 0=Centr aligment; 1=Right aligment.
             // *******************************************************************
             // auxiliary variables, for calculating the position of characters
             // *******************************************************************
             const Diagonal_calorie = Math.hypot(ImageWidht_calorie, ImageHeight_calorie);
             const DiagonalUnits_calorie = Math.hypot(UnitsWidht_calorie, ImageHeight_calorie);
             let WI_size_calorie = Diagonal_calorie * 2;                    // Widget hight and widht
             let WI_units_size_calorie = DiagonalUnits_calorie * 2;         // Widget units hight and widht
             // *******************************************************************
             let char_delta_x_calorie = Math.cos(toRadian(Angle_calorie)) * ( ImageWidht_calorie + CharSpace_calorie );
             let char_delta_y_calorie = Math.sin(toRadian(Angle_calorie)) * ( ImageWidht_calorie + CharSpace_calorie );
             let StartPosX_calorie = X_calorie;
             let StartPosY_calorie = Y_calorie;
             
             // *******************************************************************
 
             for ( let i = 0; i < 5; i++ ){
               valueCalorieImg[i] = hmUI.createWidget(hmUI.widget.IMG, { });
             }
             
             units_calorie_img = hmUI.createWidget(hmUI.widget.IMG, { });
             // *******************************************************************
             // *******************************************************************
            
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() { text_step_rotate() });  // Should update the text on the AOD screen if the data has changed
            
            
            function text_step_rotate() {  //  Get the parameter value and display it

              console.log('update STEP');
              
              let stepCurrent=step.current;
              let stepString = String(stepCurrent);
              let index = 0;
              valueStepImg[0].setProperty(hmUI.prop.SRC, "0_Empty.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueStepImg[i].setProperty(hmUI.prop.SRC, '0_Empty.png');
              }             
              if (isFinite(stepCurrent) && stepString.length>0 && stepString.length<6) {
                switch(Aligment_step)
                {
                  case -1:
                    console.log('Left aligment');
                    StartPosX_step = X_step;
                    StartPosY_step = Y_step;
                    break;
                  case 0:
                    console.log('Centr aligment');
                    StartPosX_step = X_step - Math.cos(toRadian(Angle_step)) * ( ImageWidht_step*stepString.length/2 + CharSpace_step*(stepString.length-1)/2 );
                    StartPosY_step = Y_step - Math.sin(toRadian(Angle_step)) * ( ImageWidht_step*stepString.length/2 + CharSpace_step*(stepString.length-1)/2 );
                    break;
                  case 1:
                    console.log('Right aligment');
                    StartPosX_step = X_step - Math.cos(toRadian(Angle_step)) * ( ImageWidht_step*stepString.length + CharSpace_step*(stepString.length-1) );
                    StartPosY_step = Y_step - Math.sin(toRadian(Angle_step)) * ( ImageWidht_step*stepString.length + CharSpace_step*(stepString.length-1) );
                    break;
                }

                for (let char of stepString) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  // if(charCode >= 0 && charCode < 10) valueImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
                  if(charCode >= 0 && charCode < 10) valueStepImg[index].setProperty(hmUI.prop.MORE, {  
                    x: StartPosX_step - Diagonal_step + char_delta_x_step * index,
                    y: StartPosY_step - Diagonal_step + char_delta_y_step * index,
                    w: WI_size_step,
                    h: WI_size_step,
                    pos_x: Diagonal_step,
                    pos_y: Diagonal_step,
                    center_x: Diagonal_step,
                    center_y:  Diagonal_step,
                    angle: Angle_step,
                    src: ASCIIARRAY[charCode],
                    show_level: hmUI.show_level.ALL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  
                  units_step_img.setProperty(hmUI.prop.VISIBLE, true);
                  units_step_img.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: StartPosX_step - DiagonalUnits_step + char_delta_x_step * stepString.length,
                    y: StartPosY_step - DiagonalUnits_step + char_delta_y_step * stepString.length,
                    w: WI_units_size_step,
                    h: WI_units_size_step,
                    pos_x: DiagonalUnits_step,
                    pos_y: DiagonalUnits_step,
                    center_x: DiagonalUnits_step,
                    center_y:  DiagonalUnits_step,
                    angle: Angle_step,
                    //angle: unit_angl,
                    src: "0_Empty.png",  // unit image
                    show_level: hmUI.show_level.ALL,
                  });
                }
                else units_step_img.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                switch(Aligment_step)
                {
                  case -1:
                    StartPosX_step = X_step;
                    StartPosY_step = Y_step;
                    break;
                  case 0:
                    StartPosX_step = X_step - Math.cos(toRadian(Angle_step)) * ( ImageWidht_step*0.5 );
                    StartPosY_step = Y_step - Math.sin(toRadian(Angle_step)) * ( ImageWidht_step*0.5 );
                    break;
                  case 1:
                    StartPosX_step = X_step - Math.cos(toRadian(Angle_step)) * ( ImageWidht_step );
                    StartPosY_step = Y_step - Math.sin(toRadian(Angle_step)) * ( ImageWidht_step );
                    break;
                }
                valueStepImg[0].setProperty(hmUI.prop.MORE, {  
                  x: StartPosX_step - Diagonal_step + char_delta_x_step * index,
                  y: StartPosY_step - Diagonal_step + char_delta_y_step * index,
                  w: WI_size_step,
                  h: WI_size_step,
                  pos_x: Diagonal_step,
                  pos_y: Diagonal_step,
                  center_x: Diagonal_step,
                  center_y:  Diagonal_step,
                  angle: Angle_step,
                  src: "0_Empty.png",
                  show_level: hmUI.show_level.ALL,
                });
                units_step_img.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };

            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() { text_calorie_rotate() });  // Should update the text on the AOD screen if the data has changed
            
            
            function text_calorie_rotate() {  //  Get the parameter value and display it

              console.log('update CALORIE');
              
              let calorieCurrent=calorie.current;
              let calorieString = String(calorieCurrent);
              let index = 0;
              valueCalorieImg[0].setProperty(hmUI.prop.SRC, "0_Empty.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueCalorieImg[i].setProperty(hmUI.prop.SRC, '0_Empty.png');
              }             
              if (isFinite(calorieCurrent) && calorieString.length>0 && calorieString.length<6) {
                switch(Aligment_calorie)
                {
                  case -1:
                    console.log('Left aligment');
                    StartPosX_calorie = X_calorie;
                    StartPosY_calorie = Y_calorie;
                    break;
                  case 0:
                    console.log('Centr aligment');
                    StartPosX_calorie = X_calorie - Math.cos(toRadian(Angle_calorie)) * ( ImageWidht_calorie*calorieString.length/2 + CharSpace_calorie*(calorieString.length-1)/2 );
                    StartPosY_calorie = Y_calorie - Math.sin(toRadian(Angle_calorie)) * ( ImageWidht_calorie*calorieString.length/2 + CharSpace_calorie*(calorieString.length-1)/2 );
                    break;
                  case 1:
                    console.log('Right aligment');
                    StartPosX_calorie = X_calorie - Math.cos(toRadian(Angle_calorie)) * ( ImageWidht_calorie*calorieString.length + CharSpace_calorie*(calorieString.length-1) );
                    StartPosY_calorie = Y_calorie - Math.sin(toRadian(Angle_calorie)) * ( ImageWidht_calorie*calorieString.length + CharSpace_calorie*(calorieString.length-1) );
                    break;
                }

                for (let char of calorieString) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  // if(charCode >= 0 && charCode < 10) valueImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
                  if(charCode >= 0 && charCode < 10) valueCalorieImg[index].setProperty(hmUI.prop.MORE, {  
                    x: StartPosX_calorie - Diagonal_calorie + char_delta_x_calorie * index,
                    y: StartPosY_calorie - Diagonal_calorie + char_delta_y_calorie * index,
                    w: WI_size_calorie,
                    h: WI_size_calorie,
                    pos_x: Diagonal_calorie,
                    pos_y: Diagonal_calorie,
                    center_x: Diagonal_calorie,
                    center_y:  Diagonal_calorie,
                    angle: Angle_calorie,
                    src: ASCIIARRAY[charCode],
                    show_level: hmUI.show_level.ALL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  
                  units_calorie_img.setProperty(hmUI.prop.VISIBLE, true);
                  units_calorie_img.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: StartPosX_calorie - DiagonalUnits_calorie + char_delta_x_calorie * calorieString.length,
                    y: StartPosY_calorie - DiagonalUnits_calorie + char_delta_y_calorie * calorieString.length,
                    w: WI_units_size_calorie,
                    h: WI_units_size_calorie,
                    pos_x: DiagonalUnits_calorie,
                    pos_y: DiagonalUnits_calorie,
                    center_x: DiagonalUnits_calorie,
                    center_y:  DiagonalUnits_calorie,
                    angle: Angle_calorie,
                    //angle: unit_angl,
                    src: "0_Empty.png",  // unit image
                    show_level: hmUI.show_level.ALL,
                  });
                }
                else units_calorie_img.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                switch(Aligment_calorie)
                {
                  case -1:
                    StartPosX_calorie = X_calorie;
                    StartPosY_calorie = Y_calorie;
                    break;
                  case 0:
                    StartPosX_calorie = X_calorie - Math.cos(toRadian(Angle_calorie)) * ( ImageWidht_calorie*0.5 );
                    StartPosY_calorie = Y_calorie - Math.sin(toRadian(Angle_calorie)) * ( ImageWidht_calorie*0.5 );
                    break;
                  case 1:
                    StartPosX_calorie = X_calorie - Math.cos(toRadian(Angle_calorie)) * ( ImageWidht_calorie );
                    StartPosY_calorie = Y_calorie - Math.sin(toRadian(Angle_calorie)) * ( ImageWidht_calorie );
                    break;
                }
                valueCalorieImg[0].setProperty(hmUI.prop.MORE, {  
                  x: StartPosX_calorie - Diagonal_calorie + char_delta_x_calorie * index,
                  y: StartPosY_calorie - Diagonal_calorie + char_delta_y_calorie * index,
                  w: WI_calorie_size,
                  h: WI_calorie_size,
                  pos_x: Diagonal_calorie,
                  pos_y: Diagonal_calorie,
                  center_x: Diagonal_calorie,
                  center_y:  Diagonal_calorie,
                  angle: Angle_calorie,
                  src: "0_Empty.png",
                  show_level: hmUI.show_level.ALL,
                });
                units_calorie_img.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_step_rotate();  // update text when screen turns on
                text_calorie_rotate();
              }),
            });


/////////////////////////////////////////////////////////////

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 123,
              y: 351,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ALL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 344,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ALL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 88,
              y: 350,
              src: 'System_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ALL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 313,
              font_array: ["ACT_small_Font_01.png","ACT_small_Font_02.png","ACT_small_Font_03.png","ACT_small_Font_04.png","ACT_small_Font_05.png","ACT_small_Font_06.png","ACT_small_Font_07.png","ACT_small_Font_08.png","ACT_small_Font_09.png","ACT_small_Font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Act_Small_font_KM.png',
              unit_tc: 'Act_Small_font_KM.png',
              unit_en: 'Act_Small_font_KM.png',
              imperial_unit_sc: 'Act_Small_font_MI.png',
              imperial_unit_tc: 'Act_Small_font_MI.png',
              imperial_unit_en: 'Act_Small_font_MI.png',
              dot_image: 'Act_Small_font_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ALL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 162,
              y: 325,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ALL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 142,
              y: 295,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Act_font_weather_symbo_02.png',
              unit_tc: 'Act_font_weather_symbo_02.png',
              unit_en: 'Act_font_weather_symbo_02.png',
              negative_image: 'Act_font_weather_symbo_01.png',
              invalid_image: 'Act_font_weather_symbo_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 157,
              y: 265,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 4,
              y: 303,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_Font_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ALL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 65,
              y: 255,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ALL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 67,
              day_startY: 215,
              day_sc_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              day_tc_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              day_en_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ALL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 65,
              month_startY: 192,
              month_sc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_tc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_en_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ALL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 59,
              am_y: 166,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 59,
              pm_y: 166,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 59,
              hour_startY: 31,
              hour_array: ["Font_01.png","Font_02.png","Font_03.png","Font_04.png","Font_05.png","Font_06.png","Font_07.png","Font_08.png","Font_09.png","Font_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 59,
              minute_startY: 112,
              minute_array: ["Font_01.png","Font_02.png","Font_03.png","Font_04.png","Font_05.png","Font_06.png","Font_07.png","Font_08.png","Font_09.png","Font_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 80,
              second_startY: 86,
              second_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ALL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 61,
              y: 95,
              w: 72,
              h: 46,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ALL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 63,
              y: 31,
              w: 71,
              h: 54,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ALL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 79,
              y: 342,
              w: 33,
              h: 23,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ALL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 153,
              y: 319,
              w: 37,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 153,
              y: 269,
              w: 38,
              h: 40,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 3,
              y: 263,
              w: 48,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ALL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 2,
              y: 300,
              w: 51,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ALL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 10,
              w: 46,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ALL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  