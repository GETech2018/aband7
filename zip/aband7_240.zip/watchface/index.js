﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'Watchface_fondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 110,
              month_startY: 331,
              month_sc_array: ["dia_mes_01.png","dia_mes_02.png","dia_mes_03.png","dia_mes_04.png","dia_mes_05.png","dia_mes_06.png","dia_mes_07.png","dia_mes_08.png","dia_mes_09.png","dia_mes_10.png","dia_mes_11.png","dia_mes_12.png"],
              month_tc_array: ["dia_mes_01.png","dia_mes_02.png","dia_mes_03.png","dia_mes_04.png","dia_mes_05.png","dia_mes_06.png","dia_mes_07.png","dia_mes_08.png","dia_mes_09.png","dia_mes_10.png","dia_mes_11.png","dia_mes_12.png"],
              month_en_array: ["dia_mes_01.png","dia_mes_02.png","dia_mes_03.png","dia_mes_04.png","dia_mes_05.png","dia_mes_06.png","dia_mes_07.png","dia_mes_08.png","dia_mes_09.png","dia_mes_10.png","dia_mes_11.png","dia_mes_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 28,
              y: 331,
              week_en: ["dia_nombre_01.png","dia_nombre_02.png","dia_nombre_03.png","dia_nombre_04.png","dia_nombre_05.png","dia_nombre_06.png","dia_nombre_07.png"],
              week_tc: ["dia_nombre_01.png","dia_nombre_02.png","dia_nombre_03.png","dia_nombre_04.png","dia_nombre_05.png","dia_nombre_06.png","dia_nombre_07.png"],
              week_sc: ["dia_nombre_01.png","dia_nombre_02.png","dia_nombre_03.png","dia_nombre_04.png","dia_nombre_05.png","dia_nombre_06.png","dia_nombre_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 83,
              day_startY: 331,
              day_sc_array: ["dia_nro_00.png","dia_nro_01.png","dia_nro_02.png","dia_nro_03.png","dia_nro_04.png","dia_nro_05.png","dia_nro_06.png","dia_nro_07.png","dia_nro_08.png","dia_nro_09.png"],
              day_tc_array: ["dia_nro_00.png","dia_nro_01.png","dia_nro_02.png","dia_nro_03.png","dia_nro_04.png","dia_nro_05.png","dia_nro_06.png","dia_nro_07.png","dia_nro_08.png","dia_nro_09.png"],
              day_en_array: ["dia_nro_00.png","dia_nro_01.png","dia_nro_02.png","dia_nro_03.png","dia_nro_04.png","dia_nro_05.png","dia_nro_06.png","dia_nro_07.png","dia_nro_08.png","dia_nro_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 110,
              font_array: ["widget_nro_00.png","widget_nro_01.png","widget_nro_02.png","widget_nro_03.png","widget_nro_04.png","widget_nro_05.png","widget_nro_06.png","widget_nro_07.png","widget_nro_08.png","widget_nro_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 22,
              y: 80,
              image_array: ["calorias_01.png","calorias_02.png","calorias_03.png","calorias_04.png","calorias_05.png","calorias_06.png","calorias_07.png","calorias_08.png","calorias_09.png","calorias_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 33,
              y: 101,
              image_array: ["ritmo_01.png","ritmo_02.png","ritmo_03.png","ritmo_04.png","ritmo_05.png","ritmo_06.png"],
              image_length: 6,
              shortcut: true,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 23,
              y: 204,
              font_array: ["widget_nro_00.png","widget_nro_01.png","widget_nro_02.png","widget_nro_03.png","widget_nro_04.png","widget_nro_05.png","widget_nro_06.png","widget_nro_07.png","widget_nro_08.png","widget_nro_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 12,
              y: 80,
              image_array: ["Pasos_prog_10.png","Pasos_prog_20.png","Pasos_prog_30.png","Pasos_prog_40.png","Pasos_prog_50.png","Pasos_prog_60.png","Pasos_prog_70.png","Pasos_prog_80.png","Pasos_prog_90.png","Pasos_prog_100.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 104,
              y: 173,
              image_array: ["Clima-ico-01.png","Clima-ico-02.png","Clima-ico-03.png","Clima-ico-04.png","Clima-ico-05.png","Clima-ico-06.png","Clima-ico-07.png","Clima-ico-08.png","Clima-ico-09.png","Clima-ico-10.png","Clima-ico-11.png","Clima-ico-12.png","Clima-ico-13.png","Clima-ico-14.png","Clima-ico-15.png","Clima-ico-16.png","Clima-ico-17.png","Clima-ico-18.png","Clima-ico-19.png","Clima-ico-20.png","Clima-ico-21.png","Clima-ico-22.png","Clima-ico-23.png","Clima-ico-24.png","Clima-ico-25.png","Clima-ico-26.png","Clima-ico-27.png","Clima-ico-28.png","Clima-ico-29.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 51,
              font_array: ["bateria-nro-00.png","bateria-nro-01.png","bateria-nro-02.png","bateria-nro-03.png","bateria-nro-04.png","bateria-nro-05.png","bateria-nro-06.png","bateria-nro-07.png","bateria-nro-08.png","bateria-nro-09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'bateria-nro-10.png',
              unit_tc: 'bateria-nro-10.png',
              unit_en: 'bateria-nro-10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 20,
              y: 19,
              image_array: ["Bateria-10.png","Bateria-20.png","Bateria-30.png","Bateria-40.png","Bateria-50.png","Bateria-60.png","Bateria-70.png","Bateria-80.png","Bateria-90.png","Bateria-100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 18,
              hour_startY: 277,
              hour_array: ["Hora-NRO-00.png","Hora-NRO-01.png","Hora-NRO-02.png","Hora-NRO-03.png","Hora-NRO-04.png","Hora-NRO-05.png","Hora-NRO-06.png","Hora-NRO-07.png","Hora-NRO-08.png","Hora-NRO-09.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 109,
              minute_startY: 277,
              minute_array: ["Hora-NRO-00.png","Hora-NRO-01.png","Hora-NRO-02.png","Hora-NRO-03.png","Hora-NRO-04.png","Hora-NRO-05.png","Hora-NRO-06.png","Hora-NRO-07.png","Hora-NRO-08.png","Hora-NRO-09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'AOD-fondo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 18,
              hour_startY: 277,
              hour_array: ["AOD-Hora-NRO-00.png","AOD-Hora-NRO-01.png","AOD-Hora-NRO-02.png","AOD-Hora-NRO-03.png","AOD-Hora-NRO-04.png","AOD-Hora-NRO-05.png","AOD-Hora-NRO-06.png","AOD-Hora-NRO-07.png","AOD-Hora-NRO-08.png","AOD-Hora-NRO-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 109,
              minute_startY: 277,
              minute_array: ["AOD-Hora-NRO-00.png","AOD-Hora-NRO-01.png","AOD-Hora-NRO-02.png","AOD-Hora-NRO-03.png","AOD-Hora-NRO-04.png","AOD-Hora-NRO-05.png","AOD-Hora-NRO-06.png","AOD-Hora-NRO-07.png","AOD-Hora-NRO-08.png","AOD-Hora-NRO-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 18,
              y: 277,
              w: 159,
              h: 49,
              src: 'btn_transparente.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 173,
              w: 78,
              h: 80,
              src: 'btn_transparente.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 79,
              w: 79,
              h: 81,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 13,
              y: 79,
              w: 78,
              h: 81,
              src: 'btn_transparente.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 11,
              y: 173,
              w: 81,
              h: 75,
              src: 'btn_transparente.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}