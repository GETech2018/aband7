﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'bck-00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 129,
              year_startY: 38,
              year_sc_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              year_tc_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              year_en_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 88,
              month_startY: 38,
              month_sc_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              month_tc_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              month_en_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 38,
              src: 'tratto.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 47,
              day_startY: 38,
              day_sc_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              day_tc_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              day_en_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 83,
              y: 38,
              src: 'tratto.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 48,
              hour_startY: 270,
              hour_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 104,
              minute_startY: 270,
              minute_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 94,
              y: 270,
              src: 'duepunti.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'ore-00.png',
              hour_centerX: 97,
              hour_centerY: 184,
              hour_posX: 13,
              hour_posY: 96,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min-00.png',
              minute_centerX: 97,
              minute_centerY: 184,
              minute_posX: 13,
              minute_posY: 96,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec-00.png',
              second_centerX: 97,
              second_centerY: 184,
              second_posX: 13,
              second_posY: 96,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'bck-00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 129,
              year_startY: 38,
              year_sc_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              year_tc_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              year_en_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 88,
              month_startY: 38,
              month_sc_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              month_tc_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              month_en_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 38,
              src: 'tratto.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 47,
              day_startY: 38,
              day_sc_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              day_tc_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              day_en_array: ["nu-00.png","nu-01.png","nu-02.png","nu-03.png","nu-04.png","nu-05.png","nu-06.png","nu-07.png","nu-08.png","nu-09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 83,
              y: 38,
              src: 'tratto.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 48,
              hour_startY: 270,
              hour_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 104,
              minute_startY: 270,
              minute_array: ["num-00.png","num-01.png","num-02.png","num-03.png","num-04.png","num-05.png","num-06.png","num-07.png","num-08.png","num-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 94,
              y: 270,
              src: 'duepunti.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'ore-00.png',
              hour_centerX: 97,
              hour_centerY: 184,
              hour_posX: 13,
              hour_posY: 96,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min-00.png',
              minute_centerX: 97,
              minute_centerY: 184,
              minute_posX: 13,
              minute_posY: 96,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
