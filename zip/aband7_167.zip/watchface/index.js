﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'scale1-grey.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 69,
              y: 5,
              src: 'Off_-_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 11,
              y: 5,
              src: 'white_bell_1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 3,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 2,
              src: 'Rr5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 113,
              month_startY: 322,
              month_sc_array: ["SY-0.png","SY-1.png","SY-2.png","SY-3.png","SY-4.png","SY-5.png","SY-6.png","SY-7.png","SY-8.png","SY-9.png"],
              month_tc_array: ["SY-0.png","SY-1.png","SY-2.png","SY-3.png","SY-4.png","SY-5.png","SY-6.png","SY-7.png","SY-8.png","SY-9.png"],
              month_en_array: ["SY-0.png","SY-1.png","SY-2.png","SY-3.png","SY-4.png","SY-5.png","SY-6.png","SY-7.png","SY-8.png","SY-9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 36,
              day_startY: 322,
              day_sc_array: ["SY-0.png","SY-1.png","SY-2.png","SY-3.png","SY-4.png","SY-5.png","SY-6.png","SY-7.png","SY-8.png","SY-9.png"],
              day_tc_array: ["SY-0.png","SY-1.png","SY-2.png","SY-3.png","SY-4.png","SY-5.png","SY-6.png","SY-7.png","SY-8.png","SY-9.png"],
              day_en_array: ["SY-0.png","SY-1.png","SY-2.png","SY-3.png","SY-4.png","SY-5.png","SY-6.png","SY-7.png","SY-8.png","SY-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 322,
              src: 'SY-slach.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 11,
              y: 290,
              week_en: ["DN-1.png","DN-2.png","DN-3.png","DN-4.png","DN-5.png","DN-6.png","DN-7.png"],
              week_tc: ["DN-1.png","DN-2.png","DN-3.png","DN-4.png","DN-5.png","DN-6.png","DN-7.png"],
              week_sc: ["DN-1.png","DN-2.png","DN-3.png","DN-4.png","DN-5.png","DN-6.png","DN-7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 12,
              hour_startY: 233,
              hour_array: ["CGG-Gr-0.png","CGG-Gr-1.png","CGG-Gr-2.png","CGG-Gr-3.png","CGG-Gr-4.png","CGG-Gr-5.png","CGG-Gr-6.png","CGG-Gr-7.png","CGG-Gr-8.png","CGG-Gr-9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 110,
              minute_startY: 233,
              minute_array: ["CGG-Gr-0.png","CGG-Gr-1.png","CGG-Gr-2.png","CGG-Gr-3.png","CGG-Gr-4.png","CGG-Gr-5.png","CGG-Gr-6.png","CGG-Gr-7.png","CGG-Gr-8.png","CGG-Gr-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 92,
              y: 240,
              src: 'TWO_DOTS_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour1-shadow_MS_1.png',
              hour_centerX: 96,
              hour_centerY: 120,
              hour_posX: 13,
              hour_posY: 94,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute1-shadow_MS_3.png',
              minute_centerX: 96,
              minute_centerY: 120,
              minute_posX: 13,
              minute_posY: 94,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second1-shadow_MS_2.png',
              second_centerX: 96,
              second_centerY: 120,
              second_posX: 13,
              second_posY: 94,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'scale1-grey.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 12,
              hour_startY: 233,
              hour_array: ["CGG-Gr-0.png","CGG-Gr-1.png","CGG-Gr-2.png","CGG-Gr-3.png","CGG-Gr-4.png","CGG-Gr-5.png","CGG-Gr-6.png","CGG-Gr-7.png","CGG-Gr-8.png","CGG-Gr-9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 110,
              minute_startY: 233,
              minute_array: ["CGG-Gr-0.png","CGG-Gr-1.png","CGG-Gr-2.png","CGG-Gr-3.png","CGG-Gr-4.png","CGG-Gr-5.png","CGG-Gr-6.png","CGG-Gr-7.png","CGG-Gr-8.png","CGG-Gr-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 92,
              y: 240,
              src: 'TWO_DOTS_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour1-shadow_MS_1.png',
              hour_centerX: 96,
              hour_centerY: 120,
              hour_posX: 13,
              hour_posY: 94,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute1-shadow_MS_3.png',
              minute_centerX: 96,
              minute_centerY: 120,
              minute_posX: 13,
              minute_posY: 94,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}