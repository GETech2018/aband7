﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'タマモクロス5_Dark2-3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 0,
              y: 85,
              font_array: ["temp(0).png","temp(1).png","temp(2).png","temp(3).png","temp(4).png","temp(5).png","temp(6).png","temp(7).png","temp(8).png","temp(9).png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit.png',
              unit_tc: 'unit.png',
              unit_en: 'unit.png',
              negative_image: 'Negative.png',
              invalid_image: 'no_data.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 20,
              y: 30,
              image_array: ["wea(10).png","wea(11).png","wea(12).png","wea(13).png","wea(14).png","wea(15).png","wea(16).png","wea(17).png","wea(18).png","wea(19).png","wea(20).png","wea(21).png","wea(22).png","wea(23).png","wea(24).png","wea(25).png","wea(26).png","wea(27).png","wea(28).png","wea(29).png","wea(30).png","wea(31).png","wea(32).png","wea(33).png","wea(34).png","wea(35).png","wea(36).png","wea(37).png","wea(38).png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 11,
              y: 1,
              src: 'batt_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 4,
              font_array: ["batt_num(0).png","batt_num(1).png","batt_num(2).png","batt_num(3).png","batt_num(4).png","batt_num(5).png","batt_num(6).png","batt_num(7).png","batt_num(8).png","batt_num(9).png"],
              padding: false,
              h_space: -1,
              unit_sc: 'batt_percent.png',
              unit_tc: 'batt_percent.png',
              unit_en: 'batt_percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 12,
              y: 273,
              src: 'step_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 276,
              font_array: ["step(0).png","step(1).png","step(2).png","step(3).png","step(4).png","step(5).png","step(6).png","step(7).png","step(8).png","step(9).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 134,
              y: 312,
              week_en: ["wj(1).png","wj(2).png","wj(3).png","wj(4).png","wj(5).png","wj(6).png","wj(7).png"],
              week_tc: ["wj(1).png","wj(2).png","wj(3).png","wj(4).png","wj(5).png","wj(6).png","wj(7).png"],
              week_sc: ["wj(1).png","wj(2).png","wj(3).png","wj(4).png","wj(5).png","wj(6).png","wj(7).png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 4,
              month_startY: 318,
              month_sc_array: ["d(0).png","d(1).png","d(2).png","d(3).png","d(4).png","d(5).png","d(6).png","d(7).png","d(8).png","d(9).png"],
              month_tc_array: ["d(0).png","d(1).png","d(2).png","d(3).png","d(4).png","d(5).png","d(6).png","d(7).png","d(8).png","d(9).png"],
              month_en_array: ["d(0).png","d(1).png","d(2).png","d(3).png","d(4).png","d(5).png","d(6).png","d(7).png","d(8).png","d(9).png"],
              month_zero: 0,
              month_space: 0,
              month_unit_sc: 'unit_d.png',
              month_unit_tc: 'unit_d.png',
              month_unit_en: 'unit_d.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 74,
              day_startY: 318,
              day_sc_array: ["d(0).png","d(1).png","d(2).png","d(3).png","d(4).png","d(5).png","d(6).png","d(7).png","d(8).png","d(9).png"],
              day_tc_array: ["d(0).png","d(1).png","d(2).png","d(3).png","d(4).png","d(5).png","d(6).png","d(7).png","d(8).png","d(9).png"],
              day_en_array: ["d(0).png","d(1).png","d(2).png","d(3).png","d(4).png","d(5).png","d(6).png","d(7).png","d(8).png","d(9).png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 224,
              hour_array: ["DigLLW_00.png","DigLLW_01.png","DigLLW_02.png","DigLLW_03.png","DigLLW_04.png","DigLLW_05.png","DigLLW_06.png","DigLLW_07.png","DigLLW_08.png","DigLLW_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'DigLLW_unitpng.png',
              hour_unit_tc: 'DigLLW_unitpng.png',
              hour_unit_en: 'DigLLW_unitpng.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 62,
              minute_startY: 235,
              minute_array: ["DigLLW_00.png","DigLLW_01.png","DigLLW_02.png","DigLLW_03.png","DigLLW_04.png","DigLLW_05.png","DigLLW_06.png","DigLLW_07.png","DigLLW_08.png","DigLLW_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 10,
              y: 5,
              src: 'batt_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 8,
              font_array: ["batt_num(0).png","batt_num(1).png","batt_num(2).png","batt_num(3).png","batt_num(4).png","batt_num(5).png","batt_num(6).png","batt_num(7).png","batt_num(8).png","batt_num(9).png"],
              padding: false,
              h_space: 0,
              unit_sc: 'batt_percent.png',
              unit_tc: 'batt_percent.png',
              unit_en: 'batt_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 150,
              hour_array: ["DigLLW_00.png","DigLLW_01.png","DigLLW_02.png","DigLLW_03.png","DigLLW_04.png","DigLLW_05.png","DigLLW_06.png","DigLLW_07.png","DigLLW_08.png","DigLLW_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'DigLLW_unitpng.png',
              hour_unit_tc: 'DigLLW_unitpng.png',
              hour_unit_en: 'DigLLW_unitpng.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["DigLLW_00.png","DigLLW_01.png","DigLLW_02.png","DigLLW_03.png","DigLLW_04.png","DigLLW_05.png","DigLLW_06.png","DigLLW_07.png","DigLLW_08.png","DigLLW_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}