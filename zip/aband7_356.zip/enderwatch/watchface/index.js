﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    **  Brightness buttons added from faces by shockwave55
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        let btnbrightnessdown = ''
        let btnbrightnessup = ''

        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 128;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 128;
        let normal_image_img = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 15;
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 15;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 15;
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 15;
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 128;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 128;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'fondo_abajo_V3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 106,
              y: -9,
              image_array: ["Clima_01.png","Clima_02.png","Clima_03.png","Clima_04.png","Clima_05.png","Clima_06.png","Clima_07.png","Clima_08.png","Clima_09.png","Clima_10.png","Clima_11.png","Clima_12.png","Clima_13.png","Clima_14.png","Clima_15.png","Clima_16.png","Clima_17.png","Clima_18.png","Clima_19.png","Clima_20.png","Clima_21.png","Clima_22.png","Clima_23.png","Clima_24.png","Clima_25.png","Clima_26.png","Clima_27.png","Clima_28.png","Clima_29.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 20,
              font_array: ["pasos_00.png","pasos_01.png","pasos_02.png","pasos_03.png","pasos_04.png","pasos_05.png","pasos_06.png","pasos_07.png","pasos_08.png","pasos_09.png"],
              padding: false,
              h_space: -2,
              angle: -7,
              unit_sc: 'pasos_10.png',
              unit_tc: 'pasos_10.png',
              unit_en: 'pasos_10.png',
              negative_image: 'pasos_11.png',
              invalid_image: 'pasos_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -26,
              // y: 92,
              // font_array: ["Hora_00.png","Hora_01.png","Hora_02.png","Hora_03.png","Hora_04.png","Hora_05.png","Hora_06.png","Hora_07.png","Hora_08.png","Hora_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -46,
              // angle: -17,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'Hora_00.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'Hora_01.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'Hora_02.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'Hora_03.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'Hora_04.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'Hora_05.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'Hora_06.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'Hora_07.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'Hora_08.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'Hora_09.png';  // set of images with numbers
            btnbrightnessdown = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 97,
              h: 43,
              text: '',
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                
                const currentBrightness = hmSetting.getBrightness();
                if (currentBrightness >= 10){
                  hmSetting.setBrightness(currentBrightness - 10);
                }

              },
              show_level: hmUI.show_level.ONLY_NORMAL
            });

            btnbrightnessdown.setProperty(hmUI.prop.VISIBLE, true);

            btnbrightnessup = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 97,
              y: 0,
              w: 97,
              h: 43,
              text: '',
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                
                const currentBrightness = hmSetting.getBrightness();
                if (currentBrightness <= 90){
                  hmSetting.setBrightness(currentBrightness + 10);
                }

              },
              show_level: hmUI.show_level.ONLY_NORMAL
            });

            btnbrightnessup.setProperty(hmUI.prop.VISIBLE, true);

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: -26,
                center_y: 92,
                pos_x: -26,
                pos_y: 92,
                angle: -17,
                src: 'Hora_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -26,
              // y: 194,
              // font_array: ["Hora_00.png","Hora_01.png","Hora_02.png","Hora_03.png","Hora_04.png","Hora_05.png","Hora_06.png","Hora_07.png","Hora_08.png","Hora_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -46,
              // angle: -17,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'Hora_00.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'Hora_01.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'Hora_02.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'Hora_03.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'Hora_04.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'Hora_05.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'Hora_06.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'Hora_07.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'Hora_08.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'Hora_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: -26,
                center_y: 194,
                pos_x: -26,
                pos_y: 194,
                angle: -17,
                src: 'Hora_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'fondo_superior_V3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 36,
              // y: 55,
              // font_array: ["dia_fecha_00.png","dia_fecha_01.png","dia_fecha_02.png","dia_fecha_03.png","dia_fecha_04.png","dia_fecha_05.png","dia_fecha_06.png","dia_fecha_07.png","dia_fecha_08.png","dia_fecha_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: -7,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'dia_fecha_00.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'dia_fecha_01.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'dia_fecha_02.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'dia_fecha_03.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'dia_fecha_04.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'dia_fecha_05.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'dia_fecha_06.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'dia_fecha_07.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'dia_fecha_08.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'dia_fecha_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 36,
                center_y: 55,
                pos_x: 36,
                pos_y: 55,
                angle: -7,
                src: 'dia_fecha_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 168,
              // y: 303,
              // font_array: ["bateria_00.png","bateria_01.png","bateria_02.png","bateria_03.png","bateria_04.png","bateria_05.png","bateria_06.png","bateria_07.png","bateria_08.png","bateria_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: -7,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'bateria_00.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'bateria_01.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'bateria_02.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'bateria_03.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'bateria_04.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'bateria_05.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'bateria_06.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'bateria_07.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'bateria_08.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'bateria_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 168,
                center_y: 303,
                pos_x: 168,
                pos_y: 303,
                angle: -7,
                src: 'bateria_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 99,
              // y: 311,
              // font_array: ["pasos_00.png","pasos_01.png","pasos_02.png","pasos_03.png","pasos_04.png","pasos_05.png","pasos_06.png","pasos_07.png","pasos_08.png","pasos_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: -7,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'pasos_00.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'pasos_01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'pasos_02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'pasos_03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'pasos_04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'pasos_05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'pasos_06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'pasos_07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'pasos_08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'pasos_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 99,
                center_y: 311,
                pos_x: 99,
                pos_y: 311,
                angle: -7,
                src: 'pasos_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 30,
              // y: 320,
              // font_array: ["dia_fecha_00.png","dia_fecha_01.png","dia_fecha_02.png","dia_fecha_03.png","dia_fecha_04.png","dia_fecha_05.png","dia_fecha_06.png","dia_fecha_07.png","dia_fecha_08.png","dia_fecha_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: -7,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'dia_fecha_00.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'dia_fecha_01.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'dia_fecha_02.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'dia_fecha_03.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'dia_fecha_04.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'dia_fecha_05.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'dia_fecha_06.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'dia_fecha_07.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'dia_fecha_08.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'dia_fecha_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 30,
                center_y: 320,
                pos_x: 30,
                pos_y: 320,
                angle: -7,
                src: 'dia_fecha_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 39,
              month_startY: 42,
              month_sc_array: ["01-mes_ES_00.png","01-mes_ES_01.png","01-mes_ES_02.png","01-mes_ES_03.png","01-mes_ES_04.png","01-mes_ES_05.png","01-mes_ES_06.png","01-mes_ES_07.png","01-mes_ES_08.png","01-mes_ES_09.png","01-mes_ES_10.png","01-mes_ES_11.png"],
              month_tc_array: ["01-mes_ES_00.png","01-mes_ES_01.png","01-mes_ES_02.png","01-mes_ES_03.png","01-mes_ES_04.png","01-mes_ES_05.png","01-mes_ES_06.png","01-mes_ES_07.png","01-mes_ES_08.png","01-mes_ES_09.png","01-mes_ES_10.png","01-mes_ES_11.png"],
              month_en_array: ["01-mes_ES_00.png","01-mes_ES_01.png","01-mes_ES_02.png","01-mes_ES_03.png","01-mes_ES_04.png","01-mes_ES_05.png","01-mes_ES_06.png","01-mes_ES_07.png","01-mes_ES_08.png","01-mes_ES_09.png","01-mes_ES_10.png","01-mes_ES_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 1,
              y: -1,
              week_en: ["01_nombre_dia_ES_00.png","01_nombre_dia_ES_01.png","01_nombre_dia_ES_02.png","01_nombre_dia_ES_03.png","01_nombre_dia_ES_04.png","01_nombre_dia_ES_05.png","01_nombre_dia_ES_06.png"],
              week_tc: ["01_nombre_dia_ES_00.png","01_nombre_dia_ES_01.png","01_nombre_dia_ES_02.png","01_nombre_dia_ES_03.png","01_nombre_dia_ES_04.png","01_nombre_dia_ES_05.png","01_nombre_dia_ES_06.png"],
              week_sc: ["01_nombre_dia_ES_00.png","01_nombre_dia_ES_01.png","01_nombre_dia_ES_02.png","01_nombre_dia_ES_03.png","01_nombre_dia_ES_04.png","01_nombre_dia_ES_05.png","01_nombre_dia_ES_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -26,
              // y: 92,
              // font_array: ["AOD_hora_01.png","AOD_hora_02.png","AOD_hora_03.png","AOD_hora_04.png","AOD_hora_05.png","AOD_hora_06.png","AOD_hora_07.png","AOD_hora_08.png","AOD_hora_09.png","AOD_hora_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -46,
              // angle: -17,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'AOD_hora_01.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'AOD_hora_02.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'AOD_hora_03.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'AOD_hora_04.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'AOD_hora_05.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'AOD_hora_06.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'AOD_hora_07.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'AOD_hora_08.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'AOD_hora_09.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'AOD_hora_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: -26,
                center_y: 92,
                pos_x: -26,
                pos_y: 92,
                angle: -17,
                src: 'AOD_hora_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -26,
              // y: 194,
              // font_array: ["AOD_hora_01.png","AOD_hora_02.png","AOD_hora_03.png","AOD_hora_04.png","AOD_hora_05.png","AOD_hora_06.png","AOD_hora_07.png","AOD_hora_08.png","AOD_hora_09.png","AOD_hora_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -46,
              // angle: -17,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'AOD_hora_01.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'AOD_hora_02.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'AOD_hora_03.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'AOD_hora_04.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'AOD_hora_05.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'AOD_hora_06.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'AOD_hora_07.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'AOD_hora_08.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'AOD_hora_09.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'AOD_hora_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: -26,
                center_y: 194,
                pos_x: -26,
                pos_y: 194,
                angle: -17,
                src: 'AOD_hora_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -26 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + -46;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, -26 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + -46;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  normal_day_TextRotate_posOffset = normal_day_TextRotate_posOffset + -2 * (normal_day_rotate_string.length - 1);
                  img_offset -= normal_day_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 36 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + -2 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 168 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + -2 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 99 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + -2 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 30 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -26 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + -46;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, -26 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + -46;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}