﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_stand_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 113;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 113;
        let normal_date_img_date_week_img = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 112;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 112;
        let idle_date_img_date_week_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 37,
              y: 36,
              image_array: ["Progreso_objetivo_00.png","Progreso_objetivo_01.png","Progreso_objetivo_02.png","Progreso_objetivo_03.png","Progreso_objetivo_04.png","Progreso_objetivo_05.png","Progreso_objetivo_06.png","Progreso_objetivo_07.png","Progreso_objetivo_08.png","Progreso_objetivo_09.png","Progreso_objetivo_10.png"],
              image_length: 11,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 156,
              month_startY: 27,
              month_sc_array: ["nros_00.png","nros_01.png","nros_02.png","nros_03.png","nros_04.png","nros_05.png","nros_06.png","nros_07.png","nros_08.png","nros_09.png"],
              month_tc_array: ["nros_00.png","nros_01.png","nros_02.png","nros_03.png","nros_04.png","nros_05.png","nros_06.png","nros_07.png","nros_08.png","nros_09.png"],
              month_en_array: ["nros_00.png","nros_01.png","nros_02.png","nros_03.png","nros_04.png","nros_05.png","nros_06.png","nros_07.png","nros_08.png","nros_09.png"],
              month_zero: 0,
              month_space: -2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 126,
              day_startY: 27,
              day_sc_array: ["nros_00.png","nros_01.png","nros_02.png","nros_03.png","nros_04.png","nros_05.png","nros_06.png","nros_07.png","nros_08.png","nros_09.png"],
              day_tc_array: ["nros_00.png","nros_01.png","nros_02.png","nros_03.png","nros_04.png","nros_05.png","nros_06.png","nros_07.png","nros_08.png","nros_09.png"],
              day_en_array: ["nros_00.png","nros_01.png","nros_02.png","nros_03.png","nros_04.png","nros_05.png","nros_06.png","nros_07.png","nros_08.png","nros_09.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 149,
              y: 27,
              src: 'nros_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 149,
              y: 298,
              font_array: ["bateria_nro_00.png","bateria_nro_01.png","bateria_nro_02.png","bateria_nro_03.png","bateria_nro_04.png","bateria_nro_05.png","bateria_nro_06.png","bateria_nro_07.png","bateria_nro_08.png","bateria_nro_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bateria_nro_10.png',
              unit_tc: 'bateria_nro_10.png',
              unit_en: 'bateria_nro_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 138,
              y: 276,
              image_array: ["bateria_progreso_00.png","bateria_progreso_01.png","bateria_progreso_02.png","bateria_progreso_03.png","bateria_progreso_04.png","bateria_progreso_05.png","bateria_progreso_06.png","bateria_progreso_07.png","bateria_progreso_08.png","bateria_progreso_09.png","bateria_progreso_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 349,
              font_array: ["nros_00.png","nros_01.png","nros_02.png","nros_03.png","nros_04.png","nros_05.png","nros_06.png","nros_07.png","nros_08.png","nros_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 23,
              y: 331,
              src: 'ico_calorias_ES.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 28,
              image_array: ["progreso_calorias_00.png","progreso_calorias_01.png","progreso_calorias_02.png","progreso_calorias_03.png","progreso_calorias_04.png","progreso_calorias_05.png","progreso_calorias_06.png","progreso_calorias_07.png","progreso_calorias_08.png","progreso_calorias_09.png","progreso_calorias_10.png"],
              image_length: 11,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 349,
              font_array: ["nros_00.png","nros_01.png","nros_02.png","nros_03.png","nros_04.png","nros_05.png","nros_06.png","nros_07.png","nros_08.png","nros_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120,
              y: 331,
              src: 'ico_pasos_ES.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 20,
              image_array: ["Progreso_pasos_00.png","Progreso_pasos_01.png","Progreso_pasos_02.png","Progreso_pasos_03.png","Progreso_pasos_04.png","Progreso_pasos_05.png","Progreso_pasos_06.png","Progreso_pasos_07.png","Progreso_pasos_08.png","Progreso_pasos_09.png","Progreso_pasos_10.png"],
              image_length: 11,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -37,
              // y: 132,
              // font_array: ["hora_S_00.png","hora_S_01.png","hora_S_02.png","hora_S_03.png","hora_S_04.png","hora_S_05.png","hora_S_06.png","hora_S_07.png","hora_S_08.png","hora_S_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -34,
              // angle: -30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'hora_S_00.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'hora_S_01.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'hora_S_02.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'hora_S_03.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'hora_S_04.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'hora_S_05.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'hora_S_06.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'hora_S_07.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'hora_S_08.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'hora_S_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: -37,
                center_y: 132,
                pos_x: -37,
                pos_y: 132,
                angle: -30,
                src: 'hora_S_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();
            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 2,
              // y: 227,
              // font_array: ["Hora_I_00.png","Hora_I_01.png","Hora_I_02.png","Hora_I_03.png","Hora_I_04.png","Hora_I_05.png","Hora_I_06.png","Hora_I_07.png","Hora_I_08.png","Hora_I_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -21,
              // angle: -31,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'Hora_I_00.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'Hora_I_01.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'Hora_I_02.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'Hora_I_03.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'Hora_I_04.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'Hora_I_05.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'Hora_I_06.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'Hora_I_07.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'Hora_I_08.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'Hora_I_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 2,
                center_y: 227,
                pos_x: 2,
                pos_y: 227,
                angle: -31,
                src: 'Hora_I_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 80,
              y: 102,
              week_en: ["nombre_dia_ES_00.png","nombre_dia_ES_01.png","nombre_dia_ES_02.png","nombre_dia_ES_03.png","nombre_dia_ES_04.png","nombre_dia_ES_05.png","nombre_dia_ES_06.png"],
              week_tc: ["nombre_dia_ES_00.png","nombre_dia_ES_01.png","nombre_dia_ES_02.png","nombre_dia_ES_03.png","nombre_dia_ES_04.png","nombre_dia_ES_05.png","nombre_dia_ES_06.png"],
              week_sc: ["nombre_dia_ES_00.png","nombre_dia_ES_01.png","nombre_dia_ES_02.png","nombre_dia_ES_03.png","nombre_dia_ES_04.png","nombre_dia_ES_05.png","nombre_dia_ES_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -37,
              // y: 132,
              // font_array: ["AOD_Hora_S_00.png","AOD_Hora_S_01.png","AOD_Hora_S_02.png","AOD_Hora_S_03.png","AOD_Hora_S_04.png","AOD_Hora_S_05.png","AOD_Hora_S_06.png","AOD_Hora_S_07.png","AOD_Hora_S_08.png","AOD_Hora_S_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -34,
              // angle: -30,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'AOD_Hora_S_00.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'AOD_Hora_S_01.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'AOD_Hora_S_02.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'AOD_Hora_S_03.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'AOD_Hora_S_04.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'AOD_Hora_S_05.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'AOD_Hora_S_06.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'AOD_Hora_S_07.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'AOD_Hora_S_08.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'AOD_Hora_S_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: -37,
                center_y: 132,
                pos_x: -37,
                pos_y: 132,
                angle: -30,
                src: 'AOD_Hora_S_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 2,
              // y: 227,
              // font_array: ["AOD_Hora_S_00.png","AOD_Hora_S_01.png","AOD_Hora_S_02.png","AOD_Hora_S_03.png","AOD_Hora_S_04.png","AOD_Hora_S_05.png","AOD_Hora_S_06.png","AOD_Hora_S_07.png","AOD_Hora_S_08.png","AOD_Hora_S_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -21,
              // angle: -31,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'AOD_Hora_S_00.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'AOD_Hora_S_01.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'AOD_Hora_S_02.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'AOD_Hora_S_03.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'AOD_Hora_S_04.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'AOD_Hora_S_05.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'AOD_Hora_S_06.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'AOD_Hora_S_07.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'AOD_Hora_S_08.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'AOD_Hora_S_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 194,
                h: 368,
                center_x: 2,
                center_y: 227,
                pos_x: 2,
                pos_y: 227,
                angle: -31,
                src: 'AOD_Hora_S_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 80,
              y: 102,
              week_en: ["AOD_dia_ES_00.png","AOD_dia_ES_01.png","AOD_dia_ES_02.png","AOD_dia_ES_03.png","AOD_dia_ES_04.png","AOD_dia_ES_05.png","AOD_dia_ES_06.png"],
              week_tc: ["AOD_dia_ES_00.png","AOD_dia_ES_01.png","AOD_dia_ES_02.png","AOD_dia_ES_03.png","AOD_dia_ES_04.png","AOD_dia_ES_05.png","AOD_dia_ES_06.png"],
              week_sc: ["AOD_dia_ES_00.png","AOD_dia_ES_01.png","AOD_dia_ES_02.png","AOD_dia_ES_03.png","AOD_dia_ES_04.png","AOD_dia_ES_05.png","AOD_dia_ES_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -37 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + -34;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 2 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + -21;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -37 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + -34;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 2 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + -21;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}