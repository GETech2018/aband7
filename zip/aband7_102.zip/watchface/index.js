try {
  (() => {
    const init_view = () => {
      let screenType = hmSetting.getScreenType()
      let wfScreen = hmSetting.screen_type.WATCHFACE
      let aodScreen = hmSetting.screen_type.AOD
      let editScreen = hmSetting.screen_type.SETTINGS

      let langIndex = hmSetting.getLanguage()
      let lang = langIndex == 4 ? 0 : 1

      const deviceInfo = hmSetting.getDeviceInfo()
      const screenWidth = deviceInfo.width
      const screenHeight = deviceInfo.height

      const LangArray = [['Тип: ', 'шаги', 'пульс', 'калории', 'батарея', 'выкл', ', только на основном экране'],
                         ['Type: ', 'steps', 'pulse', 'calories', 'battery', 'off', ', only main screen']]

      const LangArray2 = [['Цвет: ', 'золото', 'небо', 'мята', 'океан', 'закат', 'зима'],
                         ['Color: ', 'gold', 'sky', 'mint', 'ocean', 'sunset', 'winter']]

      const LangArray3 = [['Ночной режим: ', 'как в система'],
                         ['Night Mode: ', 'as in the system']]

      const ColorsArray = [0xff6900, 0x009bff, 0x00ff48, 0x004daf, 0xff6c2c, 0x94c2ff]
      const ColorsBGArray = [0x331500, 0x001f33, 0x00330e, 0x00f23, 0x331508, 0x1d2633]

      const editW1ParamXB7 = {
        y: 0,
        w: screenWidth,
        h: screenHeight * 0.3,
        tips_x: 50,
        tips_y: 100
      }

      const editW1ParamAB7 = {
        y: screenHeight / 2,
        w: screenWidth / 2,
        h: screenHeight / 2,
        tips_x: screenWidth / 4 - 46,
        tips_y: screenHeight / 4 + 25
      }

      const editW1Param = screenHeight == 368 ? editW1ParamAB7 : editW1ParamXB7

      const editFirstWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: 101,
        x: 0,
        ... editW1Param,
        select_image: 'images/zero.png',
        un_select_image: 'images/zero.png',
        default_type: 2,
        optional_types: [
          { type: 0, preview: 'images/preview/steps.png', title_en: LangArray[lang][0] + LangArray[lang][1] },
          { type: 1, preview: 'images/preview/steps2.png', title_en: LangArray[lang][0] + LangArray[lang][1] + LangArray[lang][6] },
          { type: 2, preview: 'images/preview/pulse.png', title_en: LangArray[lang][0] + LangArray[lang][2] },
          { type: 3, preview: 'images/preview/pulse2.png', title_en: LangArray[lang][0] + LangArray[lang][2] + LangArray[lang][6] },
          { type: 4, preview: 'images/preview/calories.png', title_en: LangArray[lang][0] + LangArray[lang][3] },
          { type: 5, preview: 'images/preview/calories2.png', title_en: LangArray[lang][0] + LangArray[lang][3] + LangArray[lang][6] },
          { type: 6, preview: 'images/preview/battery.png', title_en: LangArray[lang][0] + LangArray[lang][4] },
          { type: 7, preview: 'images/preview/battery2.png', title_en: LangArray[lang][0] + LangArray[lang][4] + LangArray[lang][6] },
          { type: 8, preview: 'images/preview/off.png', title_en: LangArray[lang][0] + LangArray[lang][5] }
        ],
        count: 9,
        tips_width: 92,
        tips_margin: 5,
        tips_BG: 'images/tips_bg.png'
      })

      let firstWidType = screenType == editScreen ? 0 : editFirstWidget.getProperty(hmUI.prop.CURRENT_TYPE)

      const yW2 = screenHeight == 368 ? 0 : screenHeight * 0.3
      const hW2 = screenHeight == 368 ? screenHeight / 2 : screenHeight * 0.4

      const editColor = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: 102,
        x: 0,
        y: yW2,
        w: screenWidth / 2,
        h: hW2,
        select_image: 'images/zero.png',
        un_select_image: 'images/zero.png',
        default_type: 0,
        optional_types: [
          { type: 0, preview: 'images/preview/color_0.png', title_en: LangArray2[lang][0] + LangArray2[lang][1] },
          { type: 1, preview: 'images/preview/color_1.png', title_en: LangArray2[lang][0] + LangArray2[lang][2] },
          { type: 2, preview: 'images/preview/color_2.png', title_en: LangArray2[lang][0] + LangArray2[lang][3] },
          { type: 3, preview: 'images/preview/color_3.png', title_en: LangArray2[lang][0] + LangArray2[lang][4] },
          { type: 4, preview: 'images/preview/color_4.png', title_en: LangArray2[lang][0] + LangArray2[lang][5] },
          { type: 5, preview: 'images/preview/color_5.png', title_en: LangArray2[lang][0] + LangArray2[lang][6] }
        ],
        count: 6,
        tips_x: screenWidth / 4 - 46,
        tips_y: hW2 / 2 + 40,
        tips_width: 92,
        tips_margin: 5,
        tips_BG: 'images/tips_bg.png'
      })

      let wfColor = screenType == editScreen ? 0 : editColor.getProperty(hmUI.prop.CURRENT_TYPE)

      const editBrightness = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: 103,
        x: screenWidth / 2,
        y: yW2,
        w: screenWidth / 2,
        h: hW2,
        select_image: 'images/zero.png',
        un_select_image: 'images/zero.png',
        default_type: 0,
        optional_types: [
          { type: 0, preview: 'images/preview/edit_0.png', title_en: LangArray3[lang][0] + LangArray3[lang][1] },
          { type: 1, preview: 'images/preview/edit_1.png', title_en: LangArray3[lang][0] + '20%' },
          { type: 2, preview: 'images/preview/edit_2.png', title_en: LangArray3[lang][0] + '50%' },
          { type: 3, preview: 'images/preview/edit_3.png', title_en: LangArray3[lang][0] + '80%' }
        ],
        count: 4,
        tips_x: screenWidth / 4 - 46,
        tips_y: hW2 / 2 + 40,
        tips_width: 92,
        tips_margin: 5,
        tips_BG: 'images/tips_bg.png'
      })

      let brightness = screenType == editScreen ? 0 : editBrightness.getProperty(hmUI.prop.CURRENT_TYPE)

      const editW4ParamXB7 = {
        x: 0,
        y: screenHeight * 0.7,
        w: screenWidth,
        h: screenHeight * 0.3,
        tips_x: screenWidth / 2 - 46,
        tips_y: 100
      }

      const editW4ParamAB7 = {
        x: screenWidth / 2,
        y: screenHeight / 2,
        w: screenWidth / 2,
        h: screenHeight / 2,
        tips_x: screenWidth / 4 - 46,
        tips_y: screenHeight / 4 + 25
      }

      const editW4Param = screenHeight == 368 ? editW4ParamAB7 : editW4ParamXB7
      
      const editSecondWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: 104,
        ... editW4Param,
        select_image: 'images/zero.png',
        un_select_image: 'images/zero.png',
        default_type: 0,
        optional_types: [
          { type: 0, preview: 'images/preview/steps.png', title_en: LangArray[lang][0] + LangArray[lang][1] },
          { type: 1, preview: 'images/preview/steps2.png', title_en: LangArray[lang][0] + LangArray[lang][1] + LangArray[lang][6] },
          { type: 2, preview: 'images/preview/pulse.png', title_en: LangArray[lang][0] + LangArray[lang][2] },
          { type: 3, preview: 'images/preview/pulse2.png', title_en: LangArray[lang][0] + LangArray[lang][2] + LangArray[lang][6] },
          { type: 4, preview: 'images/preview/calories.png', title_en: LangArray[lang][0] + LangArray[lang][3] },
          { type: 5, preview: 'images/preview/calories2.png', title_en: LangArray[lang][0] + LangArray[lang][3] + LangArray[lang][6] },
          { type: 6, preview: 'images/preview/battery.png', title_en: LangArray[lang][0] + LangArray[lang][4] },
          { type: 7, preview: 'images/preview/battery2.png', title_en: LangArray[lang][0] + LangArray[lang][4] + LangArray[lang][6] },
          { type: 8, preview: 'images/preview/off.png', title_en: LangArray[lang][0] + LangArray[lang][5] }
        ],
        count: 9,
        tips_width: 92,
        tips_margin: 5,
        tips_BG: 'images/tips_bg.png'
      })

      let secondWidType = screenType == editScreen ? 0 : editSecondWidget.getProperty(hmUI.prop.CURRENT_TYPE)

      const time = hmSensor.createSensor(hmSensor.id.TIME)
      const weather = hmSensor.createSensor(hmSensor.id.WEATHER)
      
      const steps = hmSensor.createSensor(hmSensor.id.STEP)
      const calories = hmSensor.createSensor(hmSensor.id.CALORIE)
      const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
      const pulse = hmSensor.createSensor(hmSensor.id.HEART)

      const age = hmSetting.getUserData().age

      const WidgetBG = []
      const ArcWidget = []
      let currentValue

      function SetWidgetAngles(a, b) {// a - widget number, b = data_type 
        switch(b) {
          case 0:
          case 1:
            currentValue = steps.current / steps.target
            break
          case 2:
          case 3:
            currentValue = pulse.last > 60 ? (pulse.last - 60) / (160 - age) : 0
            break
          case 4:
          case 5:
            currentValue = calories.current / calories.target
            break
          case 6:
          case 7:
            currentValue = battery.current / 100
            break
        }
        if (ArcWidget[a] != undefined) {
          if (currentValue == 0) ArcWidget[a].setProperty(hmUI.prop.VISIBLE, false)
          else {
            ArcWidget[a].setProperty(hmUI.prop.VISIBLE, true)
            if (currentValue >= 1) ArcWidget[a].setProperty(hmUI.prop.END_ANGLE, 270)
            else ArcWidget[a].setProperty(hmUI.prop.END_ANGLE, currentValue * 360 - 90)
          }
        } else return
      }

      function CreateWidget(a, b, c, d) { // a = y, b = data_type, c - widget number, d = x
        if (d == undefined) d = screenWidth / 2
        WidgetBG[c] = hmUI.createWidget(hmUI.widget.ARC, {
          x: d - 37,
          y: a,
          w: 74,
          h: 74,
          start_angle: 0,
          end_angle: 360,
          color: ColorsBGArray[wfColor],
          line_width: 4,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
        })    

        ArcWidget[c] = hmUI.createWidget(hmUI.widget.ARC, {
          x: d - 37,
          y: a,
          w: 74,
          h: 74,
          start_angle: -90,
          color: ColorsArray[wfColor],
          line_width: 4,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
        })
        SetWidgetAngles(c, b)
        switch(b) {
          case 0:
          case 1:
            steps.addEventListener(hmSensor.event.CHANGE, function () { SetWidgetAngles(c, b) })
            break
          case 2:
          case 3:
            pulse.addEventListener(hmSensor.event.CHANGE, function () { SetWidgetAngles(c, b) })
            break
          case 4:
          case 5:
            calories.addEventListener(hmSensor.event.CHANGE, function () { SetWidgetAngles(c, b) })
            break
          case 6:
          case 7:
            battery.addEventListener(hmSensor.event.CHANGE, function () { SetWidgetAngles(c, b) })
            break
        }

        hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: d - 10,
          y: a + 27,
          w: 20,
          h: 20,
          color: ColorsArray[wfColor],
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
        }) 

        if (b % 2 == 1) b -= 1
        hmUI.createWidget(hmUI.widget.IMG, {
          x: d - 10,
          y: a + 27,
          src: 'images/icons/' + b + '.png',
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
        })
      }

      function WidgetsUpdate() {
        if (firstWidType == 8 & secondWidType != 8) SetWidgetAngles(2, secondWidType)
        else if (firstWidType != 8 & secondWidType == 8)SetWidgetAngles(1, firstWidType)
        else if (firstWidType != 8 & secondWidType != 8) {
          SetWidgetAngles(1, firstWidType)
          SetWidgetAngles(2, secondWidType)
        }
      }

      let yPos = screenHeight / 2 - 135
      if (firstWidType == 8 & secondWidType != 8) {
        if (screenType == aodScreen & secondWidType % 2 != 1 | screenType == wfScreen) {
          yPos = screenHeight / 2 - 170
          CreateWidget(yPos + 275, secondWidType, 2)
        }
      } else if (firstWidType != 8 & secondWidType == 8) {
        if (screenType == aodScreen & firstWidType % 2 != 1 | screenType == wfScreen) {
          yPos = screenHeight == 368 ? screenHeight / 2 - 170 : screenHeight / 2 - 90
          screenHeight == 368 ? CreateWidget(yPos + 275, firstWidType, 1) : CreateWidget(yPos - 85, firstWidType, 1)
        }
      } else if (firstWidType != 8 & secondWidType != 8) {
        if (screenType == aodScreen & firstWidType % 2 == 1 & secondWidType % 2 != 1) yPos = screenHeight / 2 - 170
        if (screenType == aodScreen & secondWidType % 2 == 1 & firstWidType % 2 != 1) screenHeight / 2 - 90
        if (screenHeight == 368) {
          if (screenType == aodScreen & firstWidType %2 == 1 & secondWidType %2 == 1) yPos = screenHeight / 2 - 135
          else yPos = screenHeight / 2 - 170
        }
        if (screenType == aodScreen & firstWidType % 2 != 1 | screenType == wfScreen) {
          screenHeight == 368 ? (screenType == aodScreen & secondWidType %2 == 1) ? CreateWidget(yPos + 275, firstWidType, 1, screenWidth / 2)
                                                                                  : CreateWidget(yPos + 275, firstWidType, 1, screenWidth / 4)
                              : CreateWidget(yPos - 85, firstWidType, 1)
        }
        if (screenType == aodScreen & secondWidType % 2 != 1 | screenType == wfScreen) {
          screenHeight == 368 ? (screenType == aodScreen & firstWidType %2 == 1) ? CreateWidget(yPos + 275, secondWidType, 2, screenWidth / 2)
                                                                                  : CreateWidget(yPos + 275, secondWidType, 2, screenWidth * 0.75)
                              : CreateWidget(yPos + 275, secondWidType, 2)
        }
      }

      const MinuteBG = hmUI.createWidget(hmUI.widget.FILL_RECT, {
        x: screenWidth / 2 - 80,
        y: yPos + 106,
        w: 160,
        h: 120,
        color: ColorsArray[wfColor],
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      let shadowSRC = wfColor == 4 ? 'red' : 'black'

      const MinuteShadow = hmUI.createWidget(hmUI.widget.IMG, {
        x: screenWidth / 2 - 80,
        y: yPos + 106,
        src: 'images/shadow/' + shadowSRC + '.png',
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      const Minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
        minute_zero: 1,
        minute_align: hmUI.align.CENTER_H,
        minute_array: Array.from(Array(10), (v, k) => 'images/time/mask_' + k + '.png'),
        minute_startX: screenWidth / 2 - 80,
        minute_startY: yPos + 105,
        minute_space: 0,
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      const Hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
        hour_zero: 1,
        hour_align: hmUI.align.CENTER_H,
        hour_array: Array.from(Array(10), (v, k) => 'images/time/' + wfColor + '_' + k + '.png'),
        hour_startX: screenWidth / 2 - 80,
        hour_startY: yPos,
        hour_space: 0,
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      const DateBG = hmUI.createWidget(hmUI.widget.FILL_RECT, {
        x: screenWidth / 2 - 60,
        y: yPos + 235,
        w: 120,
        h: 24,
        color: ColorsArray[wfColor],
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      const Week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
        x: screenWidth / 2 - 60,
        y: yPos + 235,
        week_en: Array.from(Array(7), (v, k) => 'images/text/w_' + k + '.png'),
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      const Date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
        day_startX: screenWidth / 2 - 14,
        day_startY: yPos + 235,
        day_unit_en: 'images/text/dot.png',
        day_align: hmUI.align.RIGHT,
        day_space: 0,
        day_zero: 1,
        day_en_array: Array.from(Array(10), (v, k) => 'images/text/' + k + '.png'),
        day_is_character: false,
        month_startX: screenWidth / 2 + 26,
        month_startY: yPos + 235,
        month_align: hmUI.align.LEFT,
        month_space: 0,
        month_zero: 1,
        month_en_array: Array.from(Array(10), (v, k) => 'images/text/' + k + '.png'),
        month_is_character: false,
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      hmUI.createWidget(hmUI.widget.IMG, {
        x: screenWidth / 2 - 85,
        y: yPos - 5,
        src: 'images/shadow/aod.png',
        show_level: hmUI.show_level.ONLY_AOD
      })

      const brightnessDown = hmUI.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        src: 'images/brightness.png',
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      function BrightnessUpdate() {
        let hours = time.hour
        let minutes = time.minute
        let TodayTideData = weather.getForecastWeather().tideData.data[0]
        let sunrise_hour = TodayTideData.sunrise.hour
        let sunset_hour = TodayTideData.sunset.hour
        let sunrise_minute = TodayTideData.sunrise.minute
        let sunset_minute = TodayTideData.sunset.minute
        if (brightness != 0) {
          const AlphaArray = [51, 127, 178]
          if (hours == sunrise_hour & minutes > sunrise_minute |
              hours > sunrise_hour & hours < sunset_hour |
              hours == sunset_hour & minutes <= sunset_minute) brightnessDown.setProperty(hmUI.prop.VISIBLE, false)
          else {
            brightnessDown.setProperty(hmUI.prop.VISIBLE, true)
            brightnessDown.setProperty(hmUI.prop.MORE, {alpha: AlphaArray[brightness - 1]})
          }
        } else brightnessDown.setProperty(hmUI.prop.VISIBLE, false)
      }

      BrightnessUpdate()

      hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: function () {
          BrightnessUpdate()
          WidgetsUpdate()
        },
        pause_call: function () { console.log("ui pause") }
      })
    }

    __$$hmAppManager$$__.currentApp.current.module = DeviceRuntimeCore.WatchFace({
      onInit() {},
      build() {
        init_view()
      },
      onDestory() {}
    })
  })()
} catch (error) {
  console.log(error)
}