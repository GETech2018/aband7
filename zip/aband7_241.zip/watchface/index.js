﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_image_progress_img_level = ''
        let normal_stress_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'fondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 157,
              y: 115,
              image_array: ["progreso_pai_00.png","progreso_pai_01.png","progreso_pai_02.png","progreso_pai_03.png","progreso_pai_04.png","progreso_pai_05.png","progreso_pai_06.png","progreso_pai_07.png","progreso_pai_08.png","progreso_pai_09.png"],
              image_length: 10,
              shortcut: true,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 119,
              y: 119,
              image_array: ["progreso_calorias_00.png","progreso_calorias_01.png","progreso_calorias_02.png","progreso_calorias_03.png","progreso_calorias_04.png","progreso_calorias_05.png","progreso_calorias_06.png","progreso_calorias_07.png","progreso_calorias_08.png","progreso_calorias_09.png"],
              image_length: 10,
              shortcut: true,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 83,
              y: 125,
              image_array: ["progreso_cora_00.png","progreso_cora_01.png","progreso_cora_02.png","progreso_cora_03.png","progreso_cora_04.png","progreso_cora_05.png"],
              image_length: 6,
              shortcut: true,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 23,
              y: 127,
              image_array: ["barra_pasos_00.png","barra_pasos_01.png","barra_pasos_02.png","barra_pasos_03.png","barra_pasos_04.png","barra_pasos_05.png","barra_pasos_06.png","barra_pasos_07.png","barra_pasos_08.png","barra_pasos_09.png"],
              image_length: 10,
              shortcut: true,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 4,
              y: 159,
              image_array: ["barra_estres_00.png","barra_estres_01.png","barra_estres_02.png","barra_estres_03.png","barra_estres_04.png","barra_estres_05.png","barra_estres_06.png","barra_estres_07.png","barra_estres_08.png","barra_estres_09.png"],
              image_length: 10,
              shortcut: true,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 346,
              font_array: ["bateria_nro_00.png","bateria_nro_01.png","bateria_nro_02.png","bateria_nro_03.png","bateria_nro_04.png","bateria_nro_05.png","bateria_nro_06.png","bateria_nro_07.png","bateria_nro_08.png","bateria_nro_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 169,
              image_array: ["bateria_progreso_00.png","bateria_progreso_01.png","bateria_progreso_02.png","bateria_progreso_03.png","bateria_progreso_04.png","bateria_progreso_05.png","bateria_progreso_06.png","bateria_progreso_07.png","bateria_progreso_08.png","bateria_progreso_09.png","bateria_progreso_10.png","bateria_progreso_11.png","bateria_progreso_12.png","bateria_progreso_13.png","bateria_progreso_14.png","bateria_progreso_15.png","bateria_progreso_16.png","bateria_progreso_17.png","bateria_progreso_18.png","bateria_progreso_19.png","bateria_progreso_20.png","bateria_progreso_21.png","bateria_progreso_22.png","bateria_progreso_23.png","bateria_progreso_24.png","bateria_progreso_25.png","bateria_progreso_26.png","bateria_progreso_27.png","bateria_progreso_28.png"],
              image_length: 29,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 129,
              month_startY: 8,
              month_sc_array: ["dia_mes_01.png","dia_mes_02.png","dia_mes_03.png","dia_mes_04.png","dia_mes_05.png","dia_mes_06.png","dia_mes_07.png","dia_mes_08.png","dia_mes_09.png","dia_mes_10.png","dia_mes_11.png","dia_mes_12.png"],
              month_tc_array: ["dia_mes_01.png","dia_mes_02.png","dia_mes_03.png","dia_mes_04.png","dia_mes_05.png","dia_mes_06.png","dia_mes_07.png","dia_mes_08.png","dia_mes_09.png","dia_mes_10.png","dia_mes_11.png","dia_mes_12.png"],
              month_en_array: ["dia_mes_01.png","dia_mes_02.png","dia_mes_03.png","dia_mes_04.png","dia_mes_05.png","dia_mes_06.png","dia_mes_07.png","dia_mes_08.png","dia_mes_09.png","dia_mes_10.png","dia_mes_11.png","dia_mes_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 81,
              day_startY: 4,
              day_sc_array: ["dia_nro_00.png","dia_nro_01.png","dia_nro_02.png","dia_nro_03.png","dia_nro_04.png","dia_nro_05.png","dia_nro_06.png","dia_nro_07.png","dia_nro_08.png","dia_nro_09.png"],
              day_tc_array: ["dia_nro_00.png","dia_nro_01.png","dia_nro_02.png","dia_nro_03.png","dia_nro_04.png","dia_nro_05.png","dia_nro_06.png","dia_nro_07.png","dia_nro_08.png","dia_nro_09.png"],
              day_en_array: ["dia_nro_00.png","dia_nro_01.png","dia_nro_02.png","dia_nro_03.png","dia_nro_04.png","dia_nro_05.png","dia_nro_06.png","dia_nro_07.png","dia_nro_08.png","dia_nro_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 29,
              y: 6,
              week_en: ["dia_nombre_00.png","dia_nombre_01.png","dia_nombre_02.png","dia_nombre_03.png","dia_nombre_04.png","dia_nombre_05.png","dia_nombre_06.png"],
              week_tc: ["dia_nombre_00.png","dia_nombre_01.png","dia_nombre_02.png","dia_nombre_03.png","dia_nombre_04.png","dia_nombre_05.png","dia_nombre_06.png"],
              week_sc: ["dia_nombre_00.png","dia_nombre_01.png","dia_nombre_02.png","dia_nombre_03.png","dia_nombre_04.png","dia_nombre_05.png","dia_nombre_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 27,
              y: 63,
              font_array: ["clima_nro_00.png","clima_nro_01.png","clima_nro_02.png","clima_nro_03.png","clima_nro_04.png","clima_nro_05.png","clima_nro_06.png","clima_nro_07.png","clima_nro_08.png","clima_nro_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'clima_nro_10.png',
              unit_tc: 'clima_nro_10.png',
              unit_en: 'clima_nro_10.png',
              negative_image: 'clima_nro_11.png',
              invalid_image: 'clima_nro_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 41,
              image_array: ["Clima-ico-01.png","Clima-ico-02.png","Clima-ico-03.png","Clima-ico-04.png","Clima-ico-05.png","Clima-ico-06.png","Clima-ico-07.png","Clima-ico-08.png","Clima-ico-09.png","Clima-ico-10.png","Clima-ico-11.png","Clima-ico-12.png","Clima-ico-13.png","Clima-ico-14.png","Clima-ico-15.png","Clima-ico-16.png","Clima-ico-17.png","Clima-ico-18.png","Clima-ico-19.png","Clima-ico-20.png","Clima-ico-21.png","Clima-ico-22.png","Clima-ico-23.png","Clima-ico-24.png","Clima-ico-25.png","Clima-ico-26.png","Clima-ico-27.png","Clima-ico-28.png","Clima-ico-29.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 32,
              hour_startY: 194,
              hour_array: ["Hora_nro_00.png","Hora_nro_01.png","Hora_nro_02.png","Hora_nro_03.png","Hora_nro_04.png","Hora_nro_05.png","Hora_nro_06.png","Hora_nro_07.png","Hora_nro_08.png","Hora_nro_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 32,
              minute_startY: 263,
              minute_array: ["Hora_nro_min_00.png","Hora_nro_min_01.png","Hora_nro_min_02.png","Hora_nro_min_03.png","Hora_nro_min_04.png","Hora_nro_min_05.png","Hora_nro_min_06.png","Hora_nro_min_07.png","Hora_nro_min_08.png","Hora_nro_min_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 32,
              hour_startY: 194,
              hour_array: ["AOD-Hora_nro_00.png","AOD-Hora_nro_01.png","AOD-Hora_nro_02.png","AOD-Hora_nro_03.png","AOD-Hora_nro_04.png","AOD-Hora_nro_05.png","AOD-Hora_nro_06.png","AOD-Hora_nro_07.png","AOD-Hora_nro_08.png","AOD-Hora_nro_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 32,
              minute_startY: 263,
              minute_array: ["AOD-Hora_nro_00.png","AOD-Hora_nro_01.png","AOD-Hora_nro_02.png","AOD-Hora_nro_03.png","AOD-Hora_nro_04.png","AOD-Hora_nro_05.png","AOD-Hora_nro_06.png","AOD-Hora_nro_07.png","AOD-Hora_nro_08.png","AOD-Hora_nro_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 35,
              w: 140,
              h: 73,
              src: 'btn_transparente.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 3,
              y: 161,
              w: 83,
              h: 23,
              src: 'btn_transparente.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 156,
              y: 114,
              w: 28,
              h: 75,
              src: 'btn_transparente.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 86,
              y: 127,
              w: 67,
              h: 59,
              src: 'btn_transparente.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 9,
              y: 129,
              w: 77,
              h: 33,
              src: 'btn_transparente.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}