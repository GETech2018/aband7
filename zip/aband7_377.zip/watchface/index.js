﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright c SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let Transparent_Switch_BG = null;
let temporary_button = null;
let isLikeVisible = false;

// === Calendar overlay ===
//const CAL_X = 8;          // カレンダー左上X
//const CAL_Y = 74;         // カレンダー左上Y（ヘッダー含む領域上端）
//const GRID_Y = CAL_Y + 24;// グリッド開始Y（ヘッダーの下）
//const CELL_W = 26;
//const CELL_H = 26;
//const COLS = 7;
//const ROWS = 6;
//const GAP_X = 2;
//const GAP_Y = 2;
//const CAL_W = (CELL_W * COLS) + (GAP_X * (COLS - 1));  // 26*7 + 2*6 = 200 → はみ出し防止でXを少し調整
//const CAL_H = (CELL_H * ROWS) + (GAP_Y * (ROWS - 1));
//const HEADER_W = 194;
//const HEADER_H = 20;

//let calendarVisible = false;
//let calendarMonthOffset = 0; // 0=当月, -1=前月, +1=翌月
//let calendarHeaderText = null;
//let calendarDateTextArr = [];
//let calendarTodayCircleArr = [];
//let calTapLeft = null, calTapCenter = null, calTapRight = null;



        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_step_current_text_font = ''
        let normal_system_lock_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_outdoorRunning_jumpable_img_click = ''
        let normal_walking_jumpable_img_click = ''
        let normal_freeTraining_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['background1.png', 'background2.png', 'background3.png', 'background4.png', 'background5.png', 'background6.png', 'background7.png', 'background8.png', 'background9.png', 'background10.png', 'background11.png', 'background12.png', 'background13.png', 'background14.png', 'background15.png', 'background16.png', 'background17.png', 'background18.png', 'background19.png', 'background20.png', 'background21.png', 'background22.png', 'background23.png', 'background24.png', 'background25.png', 'background26.png', 'background27.png', 'background28.png', 'background29.png', 'background30.png', 'background31.png'];
        let backgroundToastList = ['Vivid', 'Reddish', 'Mono', 'Bluish', 'Dark Teal', 'Mica Red', 'Tokyo midnight', 'Hard-working', 'American Fuzzy Lop', 'Golden Retriever', 'Scotish Fold', 'Hiro Mamiya', 'Hiro Mamiya', 'Sun Li', 'Japanese Raden', 'Sea side', 'Superman', 'Captain Kirk', 'Wonder Woman', 'Challenge', 'Fighting spirit', 'Never give up', 'Samurai', 'LOVE', 'Connecting Dots', 'Every could has a siliver lining', 'Quote', 'Quote', 'Quote', 'Quote', 'Quote'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';




        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'background1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 134,
              y: 333,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png","Batt_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 64,
              y: 180,
              w: 66,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 180,
              w: 66,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 122,
              y: 180,
              w: 70,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 71,
              y: 330,
              src: 'locked.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 101,
              y: 330,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 139,
              y: 4,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 91,
              y: 5,
              w: 50,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Mon, Tue, Wed, Thu, Fri, Sat, Sun,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 16,
              y: 0,
              w: 135,
              h: 36,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 19,
              hour_startY: 42,
              hour_array: ["time_font_01.png","time_font_02.png","time_font_03.png","time_font_04.png","time_font_05.png","time_font_06.png","time_font_07.png","time_font_08.png","time_font_09.png","time_font_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 101,
              minute_startY: 42,
              minute_array: ["time_font_01.png","time_font_02.png","time_font_03.png","time_font_04.png","time_font_05.png","time_font_06.png","time_font_07.png","time_font_08.png","time_font_09.png","time_font_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 20,
              y: 330,
              src: 'screen.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 92,
              y: 65,
              src: 'colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'AnaBackground-02.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hours.png',
              hour_centerX: 99,
              hour_centerY: 184,
              hour_posX: 16,
              hour_posY: 114,
              hour_cover_path: '0_Empty.png',
              hour_cover_x: 0,
              hour_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minutes.png',
              minute_centerX: 99,
              minute_centerY: 184,
              minute_posX: 14,
              minute_posY: 153,
              minute_cover_path: '0_Empty.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 132,
              y: 130,
              w: 66,
              h: 66,
              src: '0_Empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 130,
              w: 66,
              h: 66,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 130,
              y: 0,
              w: 56,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 40,
              w: 95,
              h: 75,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,
              y: 40,
              w: 95,
              h: 75,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_outdoorRunning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 134,
              y: 216,
              w: 60,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.OUTDOOR_RUNNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_walking_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 216,
              w: 66,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.WALKING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_freeTraining_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 216,
              w: 66,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.FREE_TRAINING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 66,
              y: 130,
              w: 66,
              h: 66,
              src: '0_Empty.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 0,
              // y: 322,
              // w: 2,
              // h: 7,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 30,
              // radius: 12,
              // press_color: 0xFFA0A0A0,
              // normal_color: 0xFF696969,
              // bg_list: background1|background2|background3|background4|background5|background6|background7|background8|background9|background10|background11|background12|background13|background14|background15|background16|background17|background18|background19|background20|background21|background22|background23|background24|background25|background26|background27|background28|background29|background30|background31,
              // toast_list: Vivid|Reddish|Mono|Bluish|Dark Teal|Mica Red|Tokyo midnight|Hard-working|American Fuzzy Lop|Golden Retriever|Scotish Fold|Hiro Mamiya|Hiro Mamiya|Sun Li|Japanese Raden|Sea side|Superman|Captain Kirk|Wonder Woman|Challenge|Fighting spirit|Never give up|Samurai|LOVE|Connecting Dots|Every could has a siliver lining|Quote|Quote|Quote|Quote|Quote,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 322,
              w: 2,
              h: 7,
              text: '',
              color: 0xFFFF8C00,
              text_size: 30,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFF696969,
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

// 1秒間表示用のいいね画像を事前に作成（非表示でスタート）
let temporary_background_img = hmUI.createWidget(hmUI.widget.IMG, {
  x: 0,
  y: 0,
  w: 194,
  h: 368,
  src: "like.png",
  visible: true,
  show_level: hmUI.show_level.ONLY_NORMAL,
});

// 後から非表示に設定（createWidget 後に必ず呼ぶ）
temporary_background_img.setProperty(hmUI.prop.VISIBLE, false);


// 透明ボタンを配置（0, 0）に w142xh36
 temporary_button = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 0,
  y: 0,
  w: 142,
  h: 36,
  text: '',
  color: 0x00000000,         // 完全透明
  text_size: 0,
  radius: 0,
  press_src: '0_Empty.png',  // 透明画像
  normal_src: '0_Empty.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: function () {
    // トグル処理
    isLikeVisible = !isLikeVisible;
    temporary_background_img.setProperty(hmUI.prop.VISIBLE, isLikeVisible);

   // Calendar
    syncCalendarWithLikeVisibility();
  }
});

// === Calendar overlay ===
// ▼ CAL_Y を約10px上げる（74 → 64）
const CAL_X = 8;
const CAL_Y = 64;         // ← ここを 64 に
const HEADER_W = 194;
const HEADER_H = 20;      // 見出し高さは流用

// ▼ 曜日行の追加
const WEEK_LABELS = ['S','M','T','W','T','F','S'];
const WEEK_TEXT_SIZE = 16;
const WEEK_H = 18;        // 曜日テキストの行高さ
const WEEK_SPACING = 10;  // 見出しとの間隔 ≒10px

// ▼ グリッドの位置を「曜日行の下」に変更
// （以前は GRID_Y = CAL_Y + 24 でしたが、以下のように差し替え）
const GRID_TOP_GAP = 4;   // 曜日行とグリッドの間の小さな余白
const GRID_Y = CAL_Y + HEADER_H + WEEK_SPACING + WEEK_H + GRID_TOP_GAP;

// 以降は既存どおり
const CELL_W = 26;
const CELL_H = 26;
const COLS = 7;
const ROWS = 6;
const GAP_X = 2;
const GAP_Y = 2;
const CAL_W = (CELL_W * COLS) + (GAP_X * (COLS - 1));
const CAL_H = (CELL_H * ROWS) + (GAP_Y * (ROWS - 1));


let calendarVisible = false;
let calendarMonthOffset = 0; // 0=当月, -1=前月, +1=翌月
let calendarHeaderText = null;
let calendarDateTextArr = [];
let calendarTodayCircleArr = [];
let calTapLeft = null, calTapCenter = null, calTapRight = null;

let calendarWeekTextArr = [];  // ← 追加（曜日テキスト配列）

// ヘッダー（年/月）表示（既存）
calendarHeaderText = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 0,
  y: CAL_Y,
  w: HEADER_W,
  h: HEADER_H,
  text: '',
  text_size: 20,                 // 見出しのサイズは必要に応じて調整可
  color: 0xFFFFFFFF,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  show_level: hmUI.show_level.ONLY_NORMAL,
  visible: false,
});

// ▼ 曜日テキスト行（新規追加）
const weekBaseX = Math.floor((194 - CAL_W) / 2); // グリッドと同じ中央寄せ
const weekY = CAL_Y + HEADER_H + WEEK_SPACING;

for (let c = 0; c < COLS; c++) {
  const wx = weekBaseX + c * (CELL_W + GAP_X);
  const wtxt = hmUI.createWidget(hmUI.widget.TEXT, {
    x: wx,
    y: weekY,
    w: CELL_W,
    h: WEEK_H,
    text: WEEK_LABELS[c],
    text_size: WEEK_TEXT_SIZE,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    color: (c === 0) ? 0xFFFF0000       // 日曜=赤
         : (c === 6) ? 0xFF00BFFF       // 土曜=ディープスカイブルー
         : 0xFFFFFFFF,                  // 平日=白
    show_level: hmUI.show_level.ONLY_NORMAL,
    visible: false,
  });
  calendarWeekTextArr.push(wtxt);
}

// 42個のセル（テキスト＋今日○用IMG）
for (let i = 0; i < ROWS * COLS; i++) {
  const col = i % COLS;
  const row = Math.floor(i / COLS);
  const x = Math.floor((194 - CAL_W) / 2) + col * (CELL_W + GAP_X); // 画面中央寄せ
  const y = GRID_Y + row * (CELL_H + GAP_Y);

  // ○（今日マーク）
  const circle = hmUI.createWidget(hmUI.widget.IMG, {
    x: x + Math.floor((CELL_W - 20) / 2),
    y: y + Math.floor((CELL_H - 20) / 2),
    w: 20,
    h: 20,
    src: 'circle_hotpink.png', // 透過背景のホットピンク輪
    visible: false,
    show_level: hmUI.show_level.ONLY_NORMAL,
  });
  calendarTodayCircleArr.push(circle);

  // 日付テキスト
  const txt = hmUI.createWidget(hmUI.widget.TEXT, {
    x,
    y,
    w: CELL_W,
    h: CELL_H,
    text: '',
    text_size: 18,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    color: 0xFFFFFFFF,
    show_level: hmUI.show_level.ONLY_NORMAL,
    visible: false,
  });
  calendarDateTextArr.push(txt);
}

// 3分割タップ（左=前月 / 中=当月 / 右=翌月）
// カレンダーが非表示のときは自動的に無効化（visible=false）
const TAP_Y = CAL_Y;                 // ヘッダーからグリッド全体まで覆う
//const TAP_H = HEADER_H + 6 + CAL_H;  // ざっくり全体をカバー
const TAP_H = 312 - TAP_Y;  // 高さを312pxまでにする
const THIRD = Math.floor(194 / 3);

calTapLeft = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 0,
  y: TAP_Y,
  w: THIRD,
  h: TAP_H,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  color: 0x00000000,
  radius: 0,
  visible: false,
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    if (!calendarVisible) return;
    calendarMonthOffset -= 1;
    updateCalendar();
  }
});

calTapCenter = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: THIRD,
  y: TAP_Y,
  w: THIRD,
  h: TAP_H,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  color: 0x00000000,
  radius: 0,
  visible: false,
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    if (!calendarVisible) return;
    calendarMonthOffset = 0;
    updateCalendar();
  }
});

calTapRight = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: THIRD * 2,
  y: TAP_Y,
  w: 194 - THIRD * 2,
  h: TAP_H,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  color: 0x00000000,
  radius: 0,
  visible: false,
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    if (!calendarVisible) return;
    calendarMonthOffset += 1;
    updateCalendar();
  }
});

function setCalendarVisible(v) {
  calendarVisible = !!v;
  calendarHeaderText.setProperty(hmUI.prop.VISIBLE, calendarVisible);
  calendarDateTextArr.forEach(w => w.setProperty(hmUI.prop.VISIBLE, calendarVisible));
// ▼ 曜日行（追加）
  calendarWeekTextArr.forEach(w => w.setProperty(hmUI.prop.VISIBLE, calendarVisible));

  calendarTodayCircleArr.forEach(w => w.setProperty(hmUI.prop.VISIBLE, false)); // 初期は消しておく
  calTapLeft.setProperty(hmUI.prop.VISIBLE, calendarVisible);
  calTapCenter.setProperty(hmUI.prop.VISIBLE, calendarVisible);
  calTapRight.setProperty(hmUI.prop.VISIBLE, calendarVisible);
}

// ヘッダー表記：当月は "- YYYY/MM -"、それ以外は " YYYY/MM "
function headerLabel(year, month0based) {
  const y = year;
  const m = (month0based + 1).toString().padStart(2, '0');
  if (calendarMonthOffset === 0) return `- ${y}/${m} -`;
  return ` ${y}/${m} `;
}

// カレンダー描画本体
function updateCalendar() {
  // 基準日（端末の現在日）
  const now = new Date();
  const baseY = now.getFullYear();
  const baseM0 = now.getMonth(); // 0-11
  const baseD = now.getDate();

  // 表示対象（オフセット適用）
  const target = new Date(baseY, baseM0 + calendarMonthOffset, 1);
  const y = target.getFullYear();
  const m0 = target.getMonth();

  // 1日が週の何曜か（0=Sun..6=Sat）
  const firstDow = new Date(y, m0, 1).getDay();
  // 月末（日数）
  const daysInMonth = new Date(y, m0 + 1, 0).getDate();

  // ヘッダー更新
  calendarHeaderText.setProperty(hmUI.prop.TEXT, headerLabel(y, m0));

  // 42セルを埋める
  for (let i = 0; i < 42; i++) {
    const txt = calendarDateTextArr[i];
    const circle = calendarTodayCircleArr[i];

    const dayNum = i - firstDow + 1; // そのセルが示す当月日
    if (dayNum >= 1 && dayNum <= daysInMonth) {
      txt.setProperty(hmUI.prop.TEXT, `${dayNum}`);

      // 列から曜日色を決定（0=日,6=土）
      const col = i % 7;
      if (col === 0) txt.setProperty(hmUI.prop.COLOR, 0xFFFF0000);      // 日=赤
      else if (col === 6) txt.setProperty(hmUI.prop.COLOR, 0xFF00BFFF); // 土=ディープスカイブルー
      else txt.setProperty(hmUI.prop.COLOR, 0xFFFFFFFF);                // 平日=白

      // 今日マーク（当月かつ同日なら○）
      const isToday = (calendarMonthOffset === 0 && dayNum === baseD);
      circle.setProperty(hmUI.prop.VISIBLE, isToday);
    } else {
      // 当月外は空欄
      txt.setProperty(hmUI.prop.TEXT, '');
      circle.setProperty(hmUI.prop.VISIBLE, false);
    }
  }
}

// 既存の「いいね」トグルに連動してカレンダー表示を制御
// 既存 temporary_button の click_func の末尾にこの2行を追加してもOK
function syncCalendarWithLikeVisibility() {
  setCalendarVisible(isLikeVisible); // 非表示ならタップも消える
  if (calendarVisible) {
    // 初回は当月を出す
    if (calendarMonthOffset !== 0) calendarMonthOffset = 0;
    updateCalendar();
  }
}

// 初期は非表示
setCalendarVisible(false);


/// jumpableの表示・非表示他

// === jumpable の有効/無効制御 ===
function setJumpablesEnabled(enabled) {
  const vis = !!enabled;
  try { normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, vis); } catch(e) {}
  try { normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, vis); } catch(e) {}
  try { normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, vis); } catch(e) {}
  try { normal_freeTraining_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, vis); } catch(e) {}
  try { normal_walking_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, vis); } catch(e) {}
  try { normal_outdoorRunning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, vis); } catch(e) {}
}

// backgroundIndex に応じて反映
function updateJumpablesByBG() {
  const enabled = (backgroundIndex >= 0 && backgroundIndex <= 7);
  setJumpablesEnabled(enabled);
}

function updateTextFontProperties() {

  // 指定してOFF にする場合
  if (backgroundIndex >=0 && backgroundIndex <= 7) {
    normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
    normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
    normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
  }
  // デフォルトにする場合
  else {
    normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
    normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
  }
}


Transparent_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 0,
  y: 331,
  w: 127,
  h: 36,
  text: '',  // テキストなし
  color: 0x00000000,  // 透明
  text_size: '',       // 小さくして実質非表示
  radius: 0,
  color: 0xFFFF8C00,
  text_size: 30,
  press_src: '0_Empty.png',
  normal_src: '0_Empty.png',
  click_func: () => {
    // 背景インデックスを更新
    backgroundIndex++;
    if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;

    // 保存
    hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);

    // 背景変更
    if (normal_background_bg_img) {
      normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
    }

    // Jumpableの無効化・有効化
　　updateJumpablesByBG();

    // トースト表示
    const toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
    if (toastText.length > 0) {
      hmUI.showToast({ text: toastText });
    }

    updateTextFontProperties();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
});
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}