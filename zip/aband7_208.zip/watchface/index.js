(() => {
const wf = {
    isAOD: hmSetting.getScreenType() == hmSetting.screen_type.AOD,
    };

function widget0() {
    const data = {"color": 16777215, "color2": 16777215, "px": 0, "py": 0, "variant": "animation", "fps": 1, "locale": "all", "userFilesCount": 41, "alpha": 255};
    const i18n = {};
    const path = (i) => "w0" + (i !== "" ? "/" : "") + i;
    const imgArray = (p, c=10) => {
        const out = [];
        for(let i = 0; i < c; i++) {
            out.push(`w0/${p}${i}.png`);
        }
        return out;
    }

    if(wf.isAOD) return;

hmUI.createWidget(hmUI.widget.IMG_ANIM, {
    x: 0,
    y: 0,
    anim_path: path(""),
    anim_prefix: "user",
    anim_ext: "png",
    anim_fps: data.fps,
    anim_size: data.userFilesCount,
    repeat_count: 0,
    anim_status: hmUI.anim_status.START
});

;
}

function widget1() {
    const data = {"color": 63231, "color2": 63231, "px": 1, "py": 150, "variant": "default", "alpha": 255, "locale": "all"};
    const i18n = {};
    const path = (i) => "w1" + (i !== "" ? "/" : "") + i;
    const imgArray = (p, c=10) => {
        const out = [];
        for(let i = 0; i < c; i++) {
            out.push(`w1/${p}${i}.png`);
        }
        return out;
    }

    const font1 = imgArray("1/", 10);
const font2 = imgArray("2/", 10);
const clockParams = {
	hour_zero: 1,
	minute_zero: 1,
	hour_startX: data.px,
	hour_startY: data.py,
	minute_startX: data.px + 100,
	minute_startY: data.py,
	_col: true,
};
hmUI.createWidget(hmUI.widget.IMG_TIME, {
	...clockParams,
	hour_array: font1,
	minute_array: font1,
	_col: true,
});
hmUI.createWidget(hmUI.widget.IMG_TIME, {
	...clockParams,
	hour_array: font2,
	minute_array: font2,
	alpha: 200,
	_col: true,
});

;
}

function widget2() {
    const data = {"color": 16711908, "color2": 16711908, "px": 45, "py": 50, "variant": "default", "alpha": 255, "locale": "all"};
    const i18n = {};
    const path = (i) => "w2" + (i !== "" ? "/" : "") + i;
    const imgArray = (p, c=10) => {
        const out = [];
        for(let i = 0; i < c; i++) {
            out.push(`w2/${p}${i}.png`);
        }
        return out;
    }

    if(wf.isAOD) 
	return;

const datefont = imgArray("", 10);
hmUI.createWidget(hmUI.widget.IMG_DATE, {
	day_zero: 1,
	day_startX: data.px,
	day_startY: data.py,
	day_en_array: datefont,
	day_tc_array: datefont,
	day_sc_array: datefont,
	month_zero: 1,
	month_startX: data.px + 54,
	month_startY: data.py,
	month_en_array: datefont,
	month_tc_array: datefont,
	month_sc_array: datefont,
	_col: true,
});

;
}

function widget3() {
    const data = {"color": 63231, "color2": 63231, "px": 77, "py": 6, "variant": "default", "alpha": 255, "locale": "all"};
    const i18n = {};
    const path = (i) => "w3" + (i !== "" ? "/" : "") + i;
    const imgArray = (p, c=10) => {
        const out = [];
        for(let i = 0; i < c; i++) {
            out.push(`w3/${p}${i}.png`);
        }
        return out;
    }

    if(wf.isAOD)
	return;

hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
	x: data.px,
	y: data.py,
	image_array: imgArray("", 6),
	image_length: 6,
	type: hmUI.data_type.BATTERY,
	_col: true,
});

;
}

function widget4() {
    const data = {"color": 14858285, "color2": 14858285, "px": 0, "py": 250, "variant": "default", "alpha": 255, "locale": "all"};
    const i18n = {};
    const path = (i) => "w4" + (i !== "" ? "/" : "") + i;
    const imgArray = (p, c=10) => {
        const out = [];
        for(let i = 0; i < c; i++) {
            out.push(`w4/${p}${i}.png`);
        }
        return out;
    }

    if(wf.isAOD)
	return;

hmUI.createWidget(hmUI.widget.TEXT_IMG, {
	x: data.px,
	y: data.py,
	w: 194,
	h: 40,
	align_h: hmUI.align.CENTER_H,
	font_array: imgArray("", 10),
	show_level: hmUI.show_level.ONLY_NORMAL,
	type: hmUI.data_type.STEP,
	_col: true,
});


;
}


const app = __$$hmAppManager$$__.currentApp;
const currentApp = app.current;
currentApp.module = DeviceRuntimeCore.WatchFace({
onInit() {
widget0();
widget1();
widget2();
widget3();
widget4();
}
});

})();
