﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 316,
              font_array: ["snb_0.png","snb_1.png","snb_2.png","snb_3.png","snb_4.png","snb_5.png","snb_6.png","snb_7.png","snb_8.png","snb_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'ss_minus.png',
              unit_tc: 'ss_minus.png',
              unit_en: 'ss_minus.png',
              dot_image: 'ssb_colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 40,
              y: 318,
              src: 'icon_sunrise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 316,
              font_array: ["snb_0.png","snb_1.png","snb_2.png","snb_3.png","snb_4.png","snb_5.png","snb_6.png","snb_7.png","snb_8.png","snb_9.png"],
              padding: false,
              h_space: -2,
              dot_image: 'ssb_colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 12,
              y: 290,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 292,
              font_array: ["snb_0.png","snb_1.png","snb_2.png","snb_3.png","snb_4.png","snb_5.png","snb_6.png","snb_7.png","snb_8.png","snb_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'ssb_temp_n.png',
              unit_tc: 'ssb_temp_n.png',
              unit_en: 'ssb_temp_n.png',
              negative_image: 'ss_minus_n.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 94,
              y: 292,
              src: 'ssb_H.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 292,
              font_array: ["snb_0.png","snb_1.png","snb_2.png","snb_3.png","snb_4.png","snb_5.png","snb_6.png","snb_7.png","snb_8.png","snb_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'ssb_temp_n.png',
              unit_tc: 'ssb_temp_n.png',
              unit_en: 'ssb_temp_n.png',
              negative_image: 'ss_minus_n.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 144,
              y: 292,
              src: 'ssb_L.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 292,
              font_array: ["snb_0.png","snb_1.png","snb_2.png","snb_3.png","snb_4.png","snb_5.png","snb_6.png","snb_7.png","snb_8.png","snb_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ssb_temp_n.png',
              unit_tc: 'ssb_temp_n.png',
              unit_en: 'ssb_temp_n.png',
              negative_image: 'ss_minus_n.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 4,
              font_array: ["snb_0.png","snb_1.png","snb_2.png","snb_3.png","snb_4.png","snb_5.png","snb_6.png","snb_7.png","snb_8.png","snb_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ssb_par.png',
              unit_tc: 'ssb_par.png',
              unit_en: 'ssb_par.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 340,
              font_array: ["snb_0.png","snb_1.png","snb_2.png","snb_3.png","snb_4.png","snb_5.png","snb_6.png","snb_7.png","snb_8.png","snb_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'icon_heart.png',
              unit_tc: 'icon_heart.png',
              unit_en: 'icon_heart.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 340,
              font_array: ["snb_0.png","snb_1.png","snb_2.png","snb_3.png","snb_4.png","snb_5.png","snb_6.png","snb_7.png","snb_8.png","snb_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 8,
              y: 340,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 21,
              y: 362,
              image_array: ["step_0.png","step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 144,
              day_startY: 258,
              day_sc_array: ["dateb_0.png","dateb_1.png","dateb_2.png","dateb_3.png","dateb_4.png","dateb_5.png","dateb_6.png","dateb_7.png","dateb_8.png","dateb_9.png"],
              day_tc_array: ["dateb_0.png","dateb_1.png","dateb_2.png","dateb_3.png","dateb_4.png","dateb_5.png","dateb_6.png","dateb_7.png","dateb_8.png","dateb_9.png"],
              day_en_array: ["dateb_0.png","dateb_1.png","dateb_2.png","dateb_3.png","dateb_4.png","dateb_5.png","dateb_6.png","dateb_7.png","dateb_8.png","dateb_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 94,
              month_startY: 258,
              month_sc_array: ["dateb_0.png","dateb_1.png","dateb_2.png","dateb_3.png","dateb_4.png","dateb_5.png","dateb_6.png","dateb_7.png","dateb_8.png","dateb_9.png"],
              month_tc_array: ["dateb_0.png","dateb_1.png","dateb_2.png","dateb_3.png","dateb_4.png","dateb_5.png","dateb_6.png","dateb_7.png","dateb_8.png","dateb_9.png"],
              month_en_array: ["dateb_0.png","dateb_1.png","dateb_2.png","dateb_3.png","dateb_4.png","dateb_5.png","dateb_6.png","dateb_7.png","dateb_8.png","dateb_9.png"],
              month_zero: 0,
              month_space: 0,
              month_unit_sc: 'dateb_slash.png',
              month_unit_tc: 'dateb_slash.png',
              month_unit_en: 'dateb_slash.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 24,
              y: 258,
              week_en: ["wdb_0.png","wdb_1.png","wdb_2.png","wdb_3.png","wdb_4.png","wdb_5.png","wdb_6.png"],
              week_tc: ["wdb_0.png","wdb_1.png","wdb_2.png","wdb_3.png","wdb_4.png","wdb_5.png","wdb_6.png"],
              week_sc: ["wdb_0.png","wdb_1.png","wdb_2.png","wdb_3.png","wdb_4.png","wdb_5.png","wdb_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 4,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 10,
              hour_startY: 190,
              hour_array: ["timeb_0.png","timeb_1.png","timeb_2.png","timeb_3.png","timeb_4.png","timeb_5.png","timeb_6.png","timeb_7.png","timeb_8.png","timeb_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'time_colon.png',
              hour_unit_tc: 'time_colon.png',
              hour_unit_en: 'time_colon.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["timeb_0.png","timeb_1.png","timeb_2.png","timeb_3.png","timeb_4.png","timeb_5.png","timeb_6.png","timeb_7.png","timeb_8.png","timeb_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hh.png',
              hour_centerX: 100,
              hour_centerY: 104,
              hour_posX: 99,
              hour_posY: 197,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'mm.png',
              minute_centerX: 100,
              minute_centerY: 104,
              minute_posX: 6,
              minute_posY: 68,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'ss.png',
              second_centerX: 100,
              second_centerY: 104,
              second_posX: 99,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 4,
              font_array: ["sn_0.png","sn_1.png","sn_2.png","sn_3.png","sn_4.png","sn_5.png","sn_6.png","sn_7.png","sn_8.png","sn_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ss_per.png',
              unit_tc: 'ss_per.png',
              unit_en: 'ss_per.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 24,
              y: 258,
              week_en: ["wd_0.png","wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png"],
              week_tc: ["wd_0.png","wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png"],
              week_sc: ["wd_0.png","wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 94,
              month_startY: 258,
              month_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_zero: 0,
              month_space: 0,
              month_unit_sc: 'date_slash.png',
              month_unit_tc: 'date_slash.png',
              month_unit_en: 'date_slash.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 144,
              day_startY: 258,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 10,
              hour_startY: 190,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'time_colon.png',
              hour_unit_tc: 'time_colon.png',
              hour_unit_en: 'time_colon.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}