﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright c SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Overlay/Pop-up perpetual calendar by OnocoroMM
// All rights reserved.


// for calendar
let Transparent_Switch_BG = null;
let temporary_button = null;
let isLikeVisible = false;

// for brightness controll by @shockwave55
let btnbrightnessdown = ''
let btnbrightnessup = ''
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 97,
              font_array: ["pulseDigit__0000_0.png","pulseDigit__0001_1.png","pulseDigit__0002_2.png","pulseDigit__0003_3.png","pulseDigit__0004_4.png","pulseDigit__0005_5.png","pulseDigit__0006_6.png","pulseDigit__0007_7.png","pulseDigit__0008_8.png","pulseDigit__0009_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'celsius.png',
              unit_tc: 'celsius.png',
              unit_en: 'celsius.png',
              negative_image: 'negative.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 56,
              image_array: ["weatherIcon_0000_01.png","weatherIcon_0001_02.png","weatherIcon_0002_03.png","weatherIcon_0003_04.png","weatherIcon_0004_05.png","weatherIcon_0005_06.png","weatherIcon_0006_07.png","weatherIcon_0007_08.png","weatherIcon_0008_09.png","weatherIcon_0009_10.png","weatherIcon_0010_11.png","weatherIcon_0011_12.png","weatherIcon_0012_13.png","weatherIcon_0013_14.png","weatherIcon_0014_15.png","weatherIcon_0015_16.png","weatherIcon_0016_17.png","weatherIcon_0017_18.png","weatherIcon_0018_19.png","weatherIcon_0019_20.png","weatherIcon_0020_21.png","weatherIcon_0021_22.png","weatherIcon_0022_23.png","weatherIcon_0023_24.png","weatherIcon_0024_25.png","weatherIcon_0025_26.png","weatherIcon_0026_27.png","weatherIcon_0027_28.png","weatherIcon_0028_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

// if locale is Japan, then set weekday image to en, otherwise, follow EN and TC respectively

if (hmSetting.getLanguage() === 11){
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 117,
              y: 221,
              week_en: ["weekday_jp_01.png","weekday_jp_02.png","weekday_jp_03.png","weekday_jp_04.png","weekday_jp_05.png","weekday_jp_06.png","weekday_jp_07.png"],
              week_tc: ["weekday_tc_01.png","weekday_tc_02.png","weekday_tc_03.png","weekday_tc_04.png","weekday_tc_05.png","weekday_tc_06.png","weekday_tc_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}else{
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 117,
              y: 221,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_tc_01.png","weekday_tc_02.png","weekday_tc_03.png","weekday_tc_04.png","weekday_tc_05.png","weekday_tc_06.png","weekday_tc_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
}
// end of locale handling for date_week image

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 31,
              y: 219,
              w: 80,
              h: 30,
              text_size: 28,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 97,
              font_array: ["pulseDigit__0000_0.png","pulseDigit__0001_1.png","pulseDigit__0002_2.png","pulseDigit__0003_3.png","pulseDigit__0004_4.png","pulseDigit__0005_5.png","pulseDigit__0006_6.png","pulseDigit__0007_7.png","pulseDigit__0008_8.png","pulseDigit__0009_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 342,
              font_array: ["batteryDigits_0000_0.png","batteryDigits_0001_1.png","batteryDigits_0002_2.png","batteryDigits_0003_3.png","batteryDigits_0004_4.png","batteryDigits_0005_5.png","batteryDigits_0006_6.png","batteryDigits_0007_7.png","batteryDigits_0008_8.png","batteryDigits_0009_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 26,
              y: 342,
              image_array: ["s_10.png","s_20.png","s_30.png","s_40.png","s_50.png","s_60.png","s_70.png","s_80.png","s_90.png","s_100.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 5,
              y: 13,
              font_array: ["batteryDigits_0000_0.png","batteryDigits_0001_1.png","batteryDigits_0002_2.png","batteryDigits_0003_3.png","batteryDigits_0004_4.png","batteryDigits_0005_5.png","batteryDigits_0006_6.png","batteryDigits_0007_7.png","batteryDigits_0008_8.png","batteryDigits_0009_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'battery_percent.png',
              unit_tc: 'battery_percent.png',
              unit_en: 'battery_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 64,
              y: 13,
              image_array: ["b_10.png","b_20.png","b_30.png","b_40.png","b_50.png","b_60.png","b_70.png","b_80.png","b_90.png","b_100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 156,
              hour_array: ["timeDigits_0000_0.png","timeDigits_0001_1.png","timeDigits_0002_2.png","timeDigits_0003_3.png","timeDigits_0004_4.png","timeDigits_0005_5.png","timeDigits_0006_6.png","timeDigits_0007_7.png","timeDigits_0008_8.png","timeDigits_0009_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 106,
              minute_startY: 156,
              minute_array: ["timeDigits_0000_0.png","timeDigits_0001_1.png","timeDigits_0002_2.png","timeDigits_0003_3.png","timeDigits_0004_4.png","timeDigits_0005_5.png","timeDigits_0006_6.png","timeDigits_0007_7.png","timeDigits_0008_8.png","timeDigits_0009_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'AnaBackground-03.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hours.png',
              hour_centerX: 99,
              hour_centerY: 184,
              hour_posX: 16,
              hour_posY: 114,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'MinuteswSec.png',
              minute_centerX: 99,
              minute_centerY: 184,
              minute_posX: 14,
              minute_posY: 153,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Seconds.png',
              second_centerX: 99,
              second_centerY: 184,
              second_posX: 12,
              second_posY: 151,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

// ---- for Hiro Mamiya, BOD 1976/2/3
// 
//(function setHBVisibleForToday(){
//  const now = new Date();
//  const isBirthday = (now.getMonth() === 1 /* Feb */) && (now.getDate() === 3);
//  image_top_img.setProperty(hmUI.prop.VISIBLE, isBirthday);
//})();



//
// brightness controll by @shockwave55
//
btnbrightnessdown = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 0,
  y: 0,
  w: 97,
  h: 43,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  click_func: () => {
    const currentBrightness = hmSetting.getBrightness();
    if (currentBrightness >= 10){
      hmSetting.setBrightness(currentBrightness - 10);
    }
  },
  show_level: hmUI.show_level.ONLY_NORMAL
});
btnbrightnessdown.setProperty(hmUI.prop.VISIBLE, true);

btnbrightnessup = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 97,
  y: 0,
  w: 97,
  h: 43,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  click_func: () => {
    const currentBrightness = hmSetting.getBrightness();
    if (currentBrightness <= 90){
      hmSetting.setBrightness(currentBrightness + 10);
    }
  },
  show_level: hmUI.show_level.ONLY_NORMAL
});
btnbrightnessup.setProperty(hmUI.prop.VISIBLE, true);

//
// end brightness controll
//
            // end user_script_beforeShortcuts.js
            console.log('Watch_Face.Shortcuts');

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 52,
              w: 60,
              h: 74,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 52,
              w: 60,
              h: 74,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 102,
              y: 330,
              w: 90,
              h: 110,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 69,
              y: 268,
              w: 60,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 133,
              y: 268,
              w: 60,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneMusicCtrlScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 8,
              y: 215,
              w: 178,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 8,
              y: 150,
              w: 178,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

// ===============================
// user_script_end.js（祝日対応版＋ロケール対応）
// ===============================
// by OnocoroMM and ChatGPT
//
// ・temporary_button で like.png の表示をトグル
// ・同時に万年カレンダーをオーバーレイ表示
// ・日本の祝日／振替休日／国民の休日に対応（赤表示）※日本ロケールのみ
//   - 春分・秋分は近似式
//   - 成人の日（1月第2月曜）
//   - 海の日（7月第3月曜）
//   - 敬老の日（9月第3月曜）
//   - スポーツの日（10月第2月曜）
//   - 5/3?5/5 が日曜に重なった年の 5/6 を振替休日に
//   - 祝日に挟まれた平日は「国民の休日」
// ・当月表示中は“今日”にピンクの○（circle_hotpink.png）
//
// ロケール仕様：
//   lang === 11 → 日本語（祝日有効, 曜日: 日月火水木金土）
//   lang === 1 or 0 → 繁体/簡体（祝日無効, 曜日: 日一二三四五六）
//   その他 → 英語（祝日無効, 曜日: Sun..Sat）

// ========= 祝日ロジック =========

// ========= ロケール判定 =========
const lang = hmSetting.getLanguage();
// 日本(ja-JP)ロケール番号 = 11 とする
const isJapan = (lang === 11);

let holidayMapCache = {};  // 年ごとのキャッシュ

function getCachedHolidayMap(year) {
  // 日本ロケール以外では祝日マップは空（祝日機能オフ）
  if (!isJapan && !isTaiwan) {
    return {};
  }
  if (isTaiwan) {
    return getHolidayMapTW(year);
  }
  if (!holidayMapCache[year]) {
    holidayMapCache[year] = getHolidayMap(year);
  }
  return holidayMapCache[year];
}

function getHolidayMap(year) {
  // 固定日
  const fixedHolidays = {
    "1/1":  "元日",
    "2/11": "建国記念の日",
    "2/23": "天皇誕生日",
    "4/29": "昭和の日",
    "5/3":  "憲法記念日",
    "5/4":  "みどりの日",
    "5/5":  "こどもの日",
    "8/11": "山の日",
    "11/3": "文化の日",
    "11/23":"勤労感謝の日",
  };

  // 春分・秋分（近似）
  const shunbun = Math.floor(20.8431 + 0.242194 * (year - 1980)) - Math.floor((year - 1980)/4);
  const shubun  = Math.floor(23.2488 + 0.242194 * (year - 1980)) - Math.floor((year - 1980)/4);
  fixedHolidays[`3/${shunbun}`] = "春分の日";
  fixedHolidays[`9/${shubun}`]  = "秋分の日";

  // ハッピーマンデー：成人の日（1月第2月曜）
  {
    let count = 0;
    for (let d = 1; d <= 14; d++) {
      const tmp = new Date(year, 0, d);
      if (tmp.getDay() === 1) {
        count++;
        if (count === 2) {
          fixedHolidays[`1/${d}`] = "成人の日";
          break;
        }
      }
    }
  }

  // 海の日（7月第3月曜）
  {
    let count = 0;
    for (let d = 1; d <= 21; d++) {
      const tmp = new Date(year, 6, d);
      if (tmp.getDay() === 1) {
        count++;
        if (count === 3) {
          fixedHolidays[`7/${d}`] = "海の日";
          break;
        }
      }
    }
  }

  // 敬老の日（9月第3月曜）
  {
    let count = 0;
    for (let d = 1; d <= 21; d++) {
      const tmp = new Date(year, 8, d);
      if (tmp.getDay() === 1) {
        count++;
        if (count === 3) {
          fixedHolidays[`9/${d}`] = "敬老の日";
          break;
        }
      }
    }
  }

  // スポーツの日（10月第2月曜）
  {
    let count = 0;
    for (let d = 1; d <= 14; d++) {
      const tmp = new Date(year, 9, d);
      if (tmp.getDay() === 1) {
        count++;
        if (count === 2) {
          fixedHolidays[`10/${d}`] = "スポーツの日";
          break;
        }
      }
    }
  }

  // ゴールデンウィーク特例：5/3?5/5 のいずれかが日曜なら 5/6 を振替休日に
  {
    const mayCheck = [3, 4, 5];
    for (let i = 0; i < mayCheck.length; i++) {
      const checkDate = new Date(year, 4, mayCheck[i]); // 5月
      if (checkDate.getDay() === 0) {
        fixedHolidays["5/6"] = "振替休日";
        break;
      }
    }
  }

  // 「国民の休日」：祝日に挟まれた平日
  const holidayDates = Object.keys(fixedHolidays).map(key => {
    const [m, d] = key.split("/").map(Number);
    return new Date(year, m - 1, d).getTime();
  }).sort((a, b) => a - b);

  for (let i = 0; i < holidayDates.length - 1; i++) {
    const prev = new Date(holidayDates[i]);
    const next = new Date(holidayDates[i + 1]);
    const gapDays = (next.getTime() - prev.getTime()) / (24 * 60 * 60 * 1000);
    if (gapDays === 2) {
      const mid = new Date(prev.getTime() + 24 * 60 * 60 * 1000);
      const key = `${mid.getMonth() + 1}/${mid.getDate()}`;
      if (!fixedHolidays[key]) {
        fixedHolidays[key] = "国民の休日";
      }
    }
  }

  return fixedHolidays;
}
// ==== 台湾祝日追加 ====
const isTaiwan = (lang === 1);

// 台湾旧暦祝日テーブル（2020-2030）
const TAIWAN_CNY = {
  2020:{m:1,d:25},2021:{m:2,d:12},2022:{m:2,d:1},2023:{m:1,d:22},
  2024:{m:2,d:10},2025:{m:1,d:29},2026:{m:2,d:17},2027:{m:2,d:6},
  2028:{m:1,d:26},2029:{m:2,d:13},2030:{m:2,d:3},
};
const TAIWAN_DUANWU = {
  2020:{m:6,d:25},2021:{m:6,d:14},2022:{m:6,d:3},2023:{m:6,d:22},
  2024:{m:6,d:10},2025:{m:5,d:31},2026:{m:6,d:19},2027:{m:6,d:9},
  2028:{m:5,d:30},2029:{m:6,d:17},2030:{m:6,d:6},
};
const TAIWAN_MIDAUT = {
  2020:{m:10,d:1},2021:{m:9,d:21},2022:{m:9,d:10},2023:{m:9,d:29},
  2024:{m:9,d:17},2025:{m:10,d:6},2026:{m:9,d:25},2027:{m:9,d:15},
  2028:{m:10,d:3},2029:{m:9,d:22},2030:{m:9,d:12},
};

function getHolidayMapTW(year){
  const map={};
  function add(m,d,name){ map[`${m}/${d}`]=name; }
  add(1,1,"開国記念日");
  add(2,28,"和平記念日");
  add(4,4,"児童節");
  add(5,1,"労働節");
  add(10,10,"国慶日");
  // ★ 法改正で追加された祝日（固定日）
  add(9, 28, "孔子生誕記念日");
  add(10, 25, "台湾光復日");
  add(12, 25, "憲法施行記念日");

  const y=year%100;
  const qd=Math.floor(0.2422*y+4.81)-Math.floor((y-1)/4);
  if(qd>=3 && qd<=6) add(4,qd,"清明節");

  const cny=TAIWAN_CNY[year];
  if(cny){
    const eve=new Date(year,cny.m-1,cny.d-1);
    add(eve.getMonth()+1,eve.getDate(),"除夕");
    add(cny.m,cny.d,"春節");
  }
  const du=TAIWAN_DUANWU[year];
  if(du) add(du.m,du.d,"端午節");
  const ma=TAIWAN_MIDAUT[year];
  if(ma) add(ma.m,ma.d,"中秋節");

  const keys=Object.keys(map);
  for(const k of keys){
    const [m,d]=k.split("/").map(Number);
    const dt=new Date(year,m-1,d);
    const dow=dt.getDay();
    if(dow===6||dow===0){
      let step=dow===6?-1:1;
      let sub=new Date(year,m-1,d+step);
      while(sub.getDay()===0||sub.getDay()===6){
        sub=new Date(sub.getFullYear(),sub.getMonth(),sub.getDate()+step);
      }
      const sk=`${sub.getMonth()+1}/${sub.getDate()}`;
      if(!map[sk]) map[sk]="振替休日";
    }
  }
  return map;
}

// Modify getCachedHolidayMap and isHoliday to use Taiwan


// 祝日判定（振替休日：祝日が日曜なら翌月曜を振替）
// 日本ロケール以外では常に「祝日ではない」扱い
function isHoliday(year, month1, day, dow /*0=日..6=土*/, holidayMap) {
  // 日本ロケール以外では常に祝日ではない扱い
  if (!isJapan && !isTaiwan) return false;
  if (isTaiwan) return holidayMap.hasOwnProperty(`${month1}/${day}`);

  const key = `${month1}/${day}`;
  if (holidayMap.hasOwnProperty(key)) return true;

  // 月曜日で、前日が日曜かつ祝日なら振替
  if (dow === 1) {
    const yest = new Date(year, month1 - 1, day - 1);
    const yKey = `${yest.getMonth() + 1}/${yest.getDate()}`;
    if (yest.getDay() === 0 && holidayMap.hasOwnProperty(yKey)) {
      return true;
    }
  }
  return false;
}

// ========= カレンダーUI =========

// カレンダー画像を事前に作成（非表示でスタート）
let temporary_background_img = hmUI.createWidget(hmUI.widget.IMG, {
  x: 0, y: 0, w: 194, h: 368,
  src: "like.png",
  visible: true,
  show_level: hmUI.show_level.ONLY_NORMAL,
});
// 後から非表示に設定（createWidget 後に必ず呼ぶ）
temporary_background_img.setProperty(hmUI.prop.VISIBLE, false);

// 透明ボタンを配置（0, 264）に w96xh110
temporary_button = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 0, y: 264, w: 96, h: 110,
  text: '',
  color: 0x00000000,
  text_size: 0,
  radius: 0,
  press_src: '0_Empty.png',
  normal_src: '0_Empty.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: function () {
    // トグル処理
    isLikeVisible = !isLikeVisible;
    temporary_background_img.setProperty(hmUI.prop.VISIBLE, isLikeVisible);

    // Calendar
    syncCalendarWithLikeVisibility();
  }
});

// === Calendar overlay ===
const CAL_X = 8;
const CAL_Y = 64;
const HEADER_W = 194;
const HEADER_H = 20;

// ロケールに応じて曜日ラベルを切り替え
let WEEK_LABELS;
if (lang === 11) {
  // 日本語
  WEEK_LABELS = ['日','月','火','水','木','金','土'];
} else if (lang === 1 || lang === 0) {
  // 台湾・中国（繁体/簡体）: 一?六 表記
  WEEK_LABELS = ['日','一','二','三','四','五','六'];
} else {
  // それ以外は英語
  WEEK_LABELS = ['S','M','T','W','T','F','S'];
}

const WEEK_TEXT_SIZE = 16;
const WEEK_H = 18;
const WEEK_SPACING = 10;

const GRID_TOP_GAP = 4;
const GRID_Y = CAL_Y + HEADER_H + WEEK_SPACING + WEEK_H + GRID_TOP_GAP;

const CELL_W = 26;
const CELL_H = 26;
const COLS = 7;
const ROWS = 6;
const GAP_X = 2;
const GAP_Y = 2;
const CAL_W = (CELL_W * COLS) + (GAP_X * (COLS - 1));
// const CAL_H = (CELL_H * ROWS) + (GAP_Y * (ROWS - 1)); // 使わないがメモ

let calendarVisible = false;
let calendarMonthOffset = 0; // 0=当月, -1=前月, +1=翌月
let calendarHeaderText = null;
let calendarDateTextArr = [];
let calendarTodayCircleArr = [];
let calTapLeft = null, calTapCenter = null, calTapRight = null;
let calendarWeekTextArr = [];

// ヘッダー（年/月）
calendarHeaderText = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 0, y: CAL_Y, w: HEADER_W, h: HEADER_H,
  text: '',
  text_size: 20,
  color: 0xFFFFFFFF,
  align_h: hmUI.align.CENTER_H,
  align_v: hmUI.align.CENTER_V,
  show_level: hmUI.show_level.ONLY_NORMAL,
  visible: false,
});

// 曜日テキスト行
const weekBaseX = Math.floor((194 - CAL_W) / 2);
const weekY = CAL_Y + HEADER_H + WEEK_SPACING;
for (let c = 0; c < COLS; c++) {
  const wx = weekBaseX + c * (CELL_W + GAP_X);
  const color =
    (c === 0) ? 0xFFFF0000 :   // 日
    (c === 6) ? 0xFF00BFFF :   // 土
                0xFFFFFFFF;    // 平日
  const wtxt = hmUI.createWidget(hmUI.widget.TEXT, {
    x: wx, y: weekY, w: CELL_W, h: WEEK_H,
    text: WEEK_LABELS[c],
    text_size: WEEK_TEXT_SIZE,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    color,
    show_level: hmUI.show_level.ONLY_NORMAL,
    visible: false,
  });
  calendarWeekTextArr.push(wtxt);
}

// 6x7 の日付セル（テキスト＋今日○用IMG）
for (let i = 0; i < ROWS * COLS; i++) {
  const col = i % COLS;
  const row = Math.floor(i / COLS);
  const x = Math.floor((194 - CAL_W) / 2) + col * (CELL_W + GAP_X);
  const y = GRID_Y + row * (CELL_H + GAP_Y);

  // 今日マーク（○）
  const circle = hmUI.createWidget(hmUI.widget.IMG, {
    x: x + Math.floor((CELL_W - 20) / 2),
    y: y + Math.floor((CELL_H - 20) / 2),
    w: 20, h: 20,
    src: 'circle_hotpink.png',
    visible: false,
    show_level: hmUI.show_level.ONLY_NORMAL,
  });
  calendarTodayCircleArr.push(circle);

  // 日付テキスト
  const txt = hmUI.createWidget(hmUI.widget.TEXT, {
    x, y, w: CELL_W, h: CELL_H,
    text: '',
    text_size: 18,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    color: 0xFFFFFFFF,
    show_level: hmUI.show_level.ONLY_NORMAL,
    visible: false,
  });
  calendarDateTextArr.push(txt);
}

// 3分割タップ
const TAP_Y = CAL_Y;
const TAP_H = 312 - TAP_Y;  // 下部の他UIと干渉しない高さ
const THIRD = Math.floor(194 / 3);

calTapLeft = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 0, y: TAP_Y, w: THIRD, h: TAP_H,
  text: '', normal_src: '0_Empty.png', press_src: '0_Empty.png',
  color: 0x00000000, radius: 0,
  visible: false,
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    if (!calendarVisible) return;
    calendarMonthOffset -= 1;
    updateCalendar();
  }
});

calTapCenter = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: THIRD, y: TAP_Y, w: THIRD, h: TAP_H,
  text: '', normal_src: '0_Empty.png', press_src: '0_Empty.png',
  color: 0x00000000, radius: 0,
  visible: false,
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    if (!calendarVisible) return;
    calendarMonthOffset = 0;
    calendarTodayCircleArr.forEach(c => c.setProperty(hmUI.prop.VISIBLE, false));
    updateCalendar();
  }
});

calTapRight = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: THIRD * 2, y: TAP_Y, w: 194 - THIRD * 2, h: TAP_H,
  text: '', normal_src: '0_Empty.png', press_src: '0_Empty.png',
  color: 0x00000000, radius: 0,
  visible: false,
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    if (!calendarVisible) return;
    calendarMonthOffset += 1;
    updateCalendar();
  }
});

function setCalendarVisible(v) {
  calendarVisible = !!v;
  calendarHeaderText.setProperty(hmUI.prop.VISIBLE, calendarVisible);
  calendarDateTextArr.forEach(w => w.setProperty(hmUI.prop.VISIBLE, calendarVisible));
  calendarWeekTextArr.forEach(w => w.setProperty(hmUI.prop.VISIBLE, calendarVisible));
  calendarTodayCircleArr.forEach(w => w.setProperty(hmUI.prop.VISIBLE, false)); // 初期消し
  calTapLeft.setProperty(hmUI.prop.VISIBLE, calendarVisible);
  calTapCenter.setProperty(hmUI.prop.VISIBLE, calendarVisible);
  calTapRight.setProperty(hmUI.prop.VISIBLE, calendarVisible);
}

// ヘッダー表記
function headerLabel(year, month0based) {
  const y = year;
  const m = (month0based + 1).toString().padStart(2, '0');
  return (calendarMonthOffset === 0) ? `- ${y}/${m} -` : ` ${y}/${m} `;
}

// カレンダー描画（祝日対応）
function updateCalendar() {
  const now = new Date();
  const baseY = now.getFullYear();
  const baseM0 = now.getMonth(); // 0-11
  const baseD = now.getDate();

  // 表示対象（オフセット適用）
  const target = new Date(baseY, baseM0 + calendarMonthOffset, 1);
  const y = target.getFullYear();
  const m0 = target.getMonth();
  const month1 = m0 + 1;

  // 1日が週の何曜か（0=Sun..6=Sat）
  const firstDow = new Date(y, m0, 1).getDay();
  // 月末（日数）
  const daysInMonth = new Date(y, m0 + 1, 0).getDate();

  // ヘッダー更新
  calendarHeaderText.setProperty(hmUI.prop.TEXT, headerLabel(y, m0));

  // 当月表示なら “今日” のセルindex、他は -1
  const todayIndex = (calendarMonthOffset === 0)
    ? (firstDow + (baseD - 1))
    : -1;

  // 祝日マップ（年次キャッシュ）
  const holidayMap = getCachedHolidayMap(y);

  for (let i = 0; i < 42; i++) {
    const txt = calendarDateTextArr[i];
    const circle = calendarTodayCircleArr[i];

    const dayNum = i - firstDow + 1; // セルが示す当月日
    if (dayNum >= 1 && dayNum <= daysInMonth) {
      txt.setProperty(hmUI.prop.TEXT, `${dayNum}`);

      const dow = i % 7; // 0=日..6=土
      // 祝日判定（振替・国民の休日含む）
      const holiday = isHoliday(y, month1, dayNum, dow, holidayMap);

      // 色決定：祝日優先→土曜→平日
      let color;
      if (holiday) {
        color = 0xFFFF0000;            // 祝日=赤
      } else if (dow === 6) {
        color = 0xFF00BFFF;            // 土曜=ディープスカイブルー
      } else if (dow === 0) {
        color = 0xFFFF0000;            // 日曜=赤
      } else {
        color = 0xFFFFFFFF;            // 平日=白
      }
      txt.setProperty(hmUI.prop.COLOR, color);
    } else {
      // 当月外は空欄
      txt.setProperty(hmUI.prop.TEXT, '');
    }

    // “今日”の○は当月かつ i===todayIndex の時のみ表示
    const circleVisible = (dayNum >= 1 && dayNum <= daysInMonth && i === todayIndex);
    circle.setProperty(hmUI.prop.VISIBLE, circleVisible);
  }
}

// トグルに連動してカレンダー表示を制御
function syncCalendarWithLikeVisibility() {
  setCalendarVisible(isLikeVisible); // 非表示ならタップも消える
  if (calendarVisible) {
    if (calendarMonthOffset !== 0) calendarMonthOffset = 0;
    updateCalendar();
  }
}

// 初期は非表示
setCalendarVisible(false);

// 日付が変わったら、表示中のカレンダーを更新
if (!timeSensor) {
  timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
}
timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
  if (calendarVisible) {
    updateCalendar();
  }
  // ---- 0時を跨いだら HB.png の表示/非表示を更新 ----
//  const now = new Date();
//  const isBirthday = (now.getMonth() === 1) && (now.getDate() === 3);
//  image_top_img.setProperty(hmUI.prop.VISIBLE, isBirthday);

});
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

// update the today's mark
if (calendarVisible) updateCalendar();
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}