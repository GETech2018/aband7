﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: '00_fondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 39,
              y: 260,
              font_array: ["05_nros_widgets_00.png","05_nros_widgets_01.png","05_nros_widgets_02.png","05_nros_widgets_03.png","05_nros_widgets_04.png","05_nros_widgets_05.png","05_nros_widgets_06.png","05_nros_widgets_07.png","05_nros_widgets_08.png","05_nros_widgets_09.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 24,
              y: 334,
              image_array: ["06_bat_progreso_01.png","06_bat_progreso_02.png","06_bat_progreso_03.png","06_bat_progreso_04.png","06_bat_progreso_05.png","06_bat_progreso_06.png","06_bat_progreso_07.png","06_bat_progreso_08.png","06_bat_progreso_09.png","06_bat_progreso_10.png","06_bat_progreso_11.png","06_bat_progreso_12.png","06_bat_progreso_13.png","06_bat_progreso_14.png","06_bat_progreso_15.png","06_bat_progreso_16.png","06_bat_progreso_17.png","06_bat_progreso_18.png","06_bat_progreso_19.png","06_bat_progreso_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 1,
              month_startY: 199,
              month_sc_array: ["05_nros_widgets_00.png","05_nros_widgets_01.png","05_nros_widgets_02.png","05_nros_widgets_03.png","05_nros_widgets_04.png","05_nros_widgets_05.png","05_nros_widgets_06.png","05_nros_widgets_07.png","05_nros_widgets_08.png","05_nros_widgets_09.png"],
              month_tc_array: ["05_nros_widgets_00.png","05_nros_widgets_01.png","05_nros_widgets_02.png","05_nros_widgets_03.png","05_nros_widgets_04.png","05_nros_widgets_05.png","05_nros_widgets_06.png","05_nros_widgets_07.png","05_nros_widgets_08.png","05_nros_widgets_09.png"],
              month_en_array: ["05_nros_widgets_00.png","05_nros_widgets_01.png","05_nros_widgets_02.png","05_nros_widgets_03.png","05_nros_widgets_04.png","05_nros_widgets_05.png","05_nros_widgets_06.png","05_nros_widgets_07.png","05_nros_widgets_08.png","05_nros_widgets_09.png"],
              month_zero: 1,
              month_space: 4,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 119,
              day_startY: 199,
              day_sc_array: ["05_nros_widgets_00.png","05_nros_widgets_01.png","05_nros_widgets_02.png","05_nros_widgets_03.png","05_nros_widgets_04.png","05_nros_widgets_05.png","05_nros_widgets_06.png","05_nros_widgets_07.png","05_nros_widgets_08.png","05_nros_widgets_09.png"],
              day_tc_array: ["05_nros_widgets_00.png","05_nros_widgets_01.png","05_nros_widgets_02.png","05_nros_widgets_03.png","05_nros_widgets_04.png","05_nros_widgets_05.png","05_nros_widgets_06.png","05_nros_widgets_07.png","05_nros_widgets_08.png","05_nros_widgets_09.png"],
              day_en_array: ["05_nros_widgets_00.png","05_nros_widgets_01.png","05_nros_widgets_02.png","05_nros_widgets_03.png","05_nros_widgets_04.png","05_nros_widgets_05.png","05_nros_widgets_06.png","05_nros_widgets_07.png","05_nros_widgets_08.png","05_nros_widgets_09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 1,
              y: 135,
              week_en: ["04_dias_EN_00.png","04_dias_EN_01.png","04_dias_EN_02.png","04_dias_EN_03.png","04_dias_EN_04.png","04_dias_EN_05.png","04_dias_EN_06.png"],
              week_tc: ["04_dias_EN_00.png","04_dias_EN_01.png","04_dias_EN_02.png","04_dias_EN_03.png","04_dias_EN_04.png","04_dias_EN_05.png","04_dias_EN_06.png"],
              week_sc: ["04_dias_EN_00.png","04_dias_EN_01.png","04_dias_EN_02.png","04_dias_EN_03.png","04_dias_EN_04.png","04_dias_EN_05.png","04_dias_EN_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 1,
              am_y: 16,
              am_sc_path: '01_AM.png',
              am_en_path: '01_AM.png',
              pm_x: 1,
              pm_y: 16,
              pm_sc_path: '01_PM.png',
              pm_en_path: '01_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 0,
              hour_startY: 78,
              hour_array: ["02_Hora_00.png","02_Hora_01.png","02_Hora_02.png","02_Hora_03.png","02_Hora_04.png","02_Hora_05.png","02_Hora_06.png","02_Hora_07.png","02_Hora_08.png","02_Hora_09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 119,
              minute_startY: 78,
              minute_array: ["02_Hora_00.png","02_Hora_01.png","02_Hora_02.png","02_Hora_03.png","02_Hora_04.png","02_Hora_05.png","02_Hora_06.png","02_Hora_07.png","02_Hora_08.png","02_Hora_09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'AOD_fondo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 39,
              y: 260,
              font_array: ["AOD_hora_00.png","AOD_hora_01.png","AOD_hora_02.png","AOD_hora_03.png","AOD_hora_04.png","AOD_hora_05.png","AOD_hora_06.png","AOD_hora_07.png","AOD_hora_08.png","AOD_hora_09.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 0,
              hour_startY: 78,
              hour_array: ["AOD_hora_00.png","AOD_hora_01.png","AOD_hora_02.png","AOD_hora_03.png","AOD_hora_04.png","AOD_hora_05.png","AOD_hora_06.png","AOD_hora_07.png","AOD_hora_08.png","AOD_hora_09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 119,
              minute_startY: 78,
              minute_array: ["AOD_hora_00.png","AOD_hora_01.png","AOD_hora_02.png","AOD_hora_03.png","AOD_hora_04.png","AOD_hora_05.png","AOD_hora_06.png","AOD_hora_07.png","AOD_hora_08.png","AOD_hora_09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}