﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_text_font = ''
        let normal_hour_circle_scale = ''
        let normal_minute_circle_scale = ''
        let normal_second_circle_scale = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_heart_rate_circle_scale_2 = ''
        let idle_heart_rate_text_font = ''
        let idle_hour_circle_scale = ''
        let idle_minute_circle_scale = ''
        let normal_heart_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'background2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 96,
              center_y: 276,
              start_angle: -150,
              end_angle: 150,
              radius: 80,
              line_width: 12,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFFF0000,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 27,
              y: 240,
              w: 140,
              h: 70,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_hour_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 96,
              // center_y: 92,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 49,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFF00FF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_hour_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 96,
              center_y: 92,
              start_angle: 0,
              end_angle: 360,
              radius: 43,
              line_width: 12,
              corner_flag: 0,
              color: 0xFF00FF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_minute_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 96,
              // center_y: 92,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 67,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFF00FFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_minute_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 96,
              center_y: 92,
              start_angle: 0,
              end_angle: 360,
              radius: 61,
              line_width: 12,
              corner_flag: 0,
              color: 0xFF00FFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_second_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 96,
              // center_y: 92,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 85,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFF0000FF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 96,
              center_y: 92,
              start_angle: 0,
              end_angle: 360,
              radius: 79,
              line_width: 12,
              corner_flag: 0,
              color: 0xFF0000FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_time_circle_options = hmUI.createWidget(hmUI.widget.TIME_CIRCLE_OPTIONS, {
              // smooth: false,
              // format24h: false,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'background2-AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 96,
              center_y: 276,
              start_angle: -150,
              end_angle: 150,
              radius: 81,
              line_width: 3,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFF5F0000,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 27,
              y: 240,
              w: 140,
              h: 70,
              text_size: 30,
              char_space: 0,
              color: 0xFF5F0000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 96,
              // center_y: 92,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 49,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFF001F00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_hour_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 96,
              center_y: 92,
              start_angle: 0,
              end_angle: 360,
              radius: 48,
              line_width: 3,
              corner_flag: 0,
              color: 0xFF001F00,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_minute_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 96,
              // center_y: 92,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 67,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFF001F1F,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_minute_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 96,
              center_y: 92,
              start_angle: 0,
              end_angle: 360,
              radius: 66,
              line_width: 3,
              corner_flag: 0,
              color: 0xFF001F1F,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_time_circle_options = hmUI.createWidget(hmUI.widget.TIME_CIRCLE_OPTIONS, {
              // smooth: false,
              // format24h: false,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 190,
              w: 180,
              h: 170,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 5,
              w: 180,
              h: 180,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) { // Hour Circle
                let normal_circle_scale_hour = hour;
                if (normal_circle_scale_hour > 11) normal_circle_scale_hour -= 12;
                let normal_hourCircleProgress = normal_circle_scale_hour/12 + (minute/60)/12;
                normal_hourCircleProgress = normal_hourCircleProgress * 100;
                if (normal_hour_circle_scale) normal_hour_circle_scale.setProperty(hmUI.prop.LEVEL, normal_hourCircleProgress );
              };

              if (updateMinute) { // Minute Circle
                let normal_minuteCircleProgress = minute/60;
                normal_minuteCircleProgress = normal_minuteCircleProgress * 100;
                if (normal_minute_circle_scale) normal_minute_circle_scale.setProperty(hmUI.prop.LEVEL, normal_minuteCircleProgress );
              };

              // Second Circle
              let normal_secondCircleProgress = 100 * second/60;
              if (normal_second_circle_scale) normal_second_circle_scale.setProperty(hmUI.prop.LEVEL, normal_secondCircleProgress );

              if (updateMinute) { // Hour Circle
                let idle_circle_scale_hour = hour;
                if (idle_circle_scale_hour > 11) idle_circle_scale_hour -= 12;
                let idle_hourCircleProgress = idle_circle_scale_hour/12 + (minute/60)/12;
                idle_hourCircleProgress = idle_hourCircleProgress * 100;
                if (idle_hour_circle_scale) idle_hour_circle_scale.setProperty(hmUI.prop.LEVEL, idle_hourCircleProgress );
              };

              if (updateMinute) { // Minute Circle
                let idle_minuteCircleProgress = minute/60;
                idle_minuteCircleProgress = idle_minuteCircleProgress * 100;
                if (idle_minute_circle_scale) idle_minute_circle_scale.setProperty(hmUI.prop.LEVEL, idle_minuteCircleProgress );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}