﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'main1.png',
              show_level: hmUI.show_level.ALL,
            });


////////////////////////////////////////////////////////////////////
            // required variables
            const valueStepImg = new Array(5);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY[i] = "number_" + i + ".png";  // set of images with numbers
            }
            let units_step_img = ''
            // *******************************************************************
            // initial variables, affect the position and display of data
            // *******************************************************************
            const X_step = 6;                // X coordinate of the top right corner of the inscription
            const Y_step = 175;                // X coordinate of the top right corner of the inscription
            const Angle_step = -90;               // The angle of the inscription, 0 degrees corresponds to the horizontal position of the inscription
            const CharSpace_step = 3;            // Space between characters
            const ImageWidht_step = 13;          // Width of character image
            const ImageHeight_step = 18;         // Height of character image
            const UnitsWidht_step = 1;          // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
            const Aligment_step = 0;            // -1=Left aligment; 0=Centr aligment; 1=Right aligment.
             // *******************************************************************
            // auxiliary variables, for calculating the position of characters
            // *******************************************************************
            const Diagonal_step = Math.hypot(ImageWidht_step, ImageHeight_step);
            const DiagonalUnits_step = Math.hypot(UnitsWidht_step, ImageHeight_step);
            let WI_size_step = Diagonal_step * 2;                    // Widget hight and widht
            let WI_units_size_step = DiagonalUnits_step * 2;         // Widget units hight and widht
            // *******************************************************************
            let char_delta_x_step = Math.cos(toRadian(Angle_step)) * ( ImageWidht_step + CharSpace_step );
		        let char_delta_y_step = Math.sin(toRadian(Angle_step)) * ( ImageWidht_step + CharSpace_step );
            let StartPosX_step = X_step;
            let StartPosY_step = Y_step;
            // *******************************************************************
            // Auxiliary functions
            function toRadian(degree) {
                return degree * (Math.PI / 180);
            };
            // *******************************************************************

            for ( let i = 0; i < 5; i++ ){
              valueStepImg[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            
            units_step_img = hmUI.createWidget(hmUI.widget.IMG, { });
            // *******************************************************************
            // *******************************************************************



             // required variables
             const valueCalorieImg = new Array(5);  // maximum display data length 5 characters (99999)
             for (let i = 0; i < 10; i++) {
               ASCIIARRAY[i] = "number_" + i + ".png";  // set of images with numbers
             }
             let units_calorie_img = ''
             // *******************************************************************
             // initial variables, affect the position and display of data
             // *******************************************************************
             const X_calorie = 170;                // X coordinate of the top left corner of the inscription
             const Y_calorie = 175;                // X coordinate of the top left corner of the inscription
             const Angle_calorie = -90;               // The angle of the inscription, 0 degrees corresponds to the horizontal position of the inscription
             const CharSpace_calorie = 3;            // Space between characters
             const ImageWidht_calorie = 13;          // Width of character image
             const ImageHeight_calorie = 18;         // Height of character image
             const UnitsWidht_calorie = 1;          // Width of units image. The height of the units of measurement must be the same as the height of the images with numbers.
             const Aligment_calorie = 0;            // -1=Left aligment; 0=Centr aligment; 1=Right aligment.
             // *******************************************************************
             // auxiliary variables, for calculating the position of characters
             // *******************************************************************
             const Diagonal_calorie = Math.hypot(ImageWidht_calorie, ImageHeight_calorie);
             const DiagonalUnits_calorie = Math.hypot(UnitsWidht_calorie, ImageHeight_calorie);
             let WI_size_calorie = Diagonal_calorie * 2;                    // Widget hight and widht
             let WI_units_size_calorie = DiagonalUnits_calorie * 2;         // Widget units hight and widht
             // *******************************************************************
             let char_delta_x_calorie = Math.cos(toRadian(Angle_calorie)) * ( ImageWidht_calorie + CharSpace_calorie );
             let char_delta_y_calorie = Math.sin(toRadian(Angle_calorie)) * ( ImageWidht_calorie + CharSpace_calorie );
             let StartPosX_calorie = X_calorie;
             let StartPosY_calorie = Y_calorie;
             
             // *******************************************************************
 
             for ( let i = 0; i < 5; i++ ){
               valueCalorieImg[i] = hmUI.createWidget(hmUI.widget.IMG, { });
             }
             
             units_calorie_img = hmUI.createWidget(hmUI.widget.IMG, { });
             // *******************************************************************
             // *******************************************************************
            
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() { text_step_rotate() });  // Should update the text on the AOD screen if the data has changed
            
            
            function text_step_rotate() {  //  Get the parameter value and display it

              console.log('update STEP');
              
              let stepCurrent=step.current;
              let stepString = String(stepCurrent);
              let index = 0;
              valueStepImg[0].setProperty(hmUI.prop.SRC, "0_Empty.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueStepImg[i].setProperty(hmUI.prop.SRC, '0_Empty.png');
              }             
              if (isFinite(stepCurrent) && stepString.length>0 && stepString.length<6) {
                switch(Aligment_step)
                {
                  case -1:
                    console.log('Left aligment');
                    StartPosX_step = X_step;
                    StartPosY_step = Y_step;
                    break;
                  case 0:
                    console.log('Centr aligment');
                    StartPosX_step = X_step - Math.cos(toRadian(Angle_step)) * ( ImageWidht_step*stepString.length/2 + CharSpace_step*(stepString.length-1)/2 );
                    StartPosY_step = Y_step - Math.sin(toRadian(Angle_step)) * ( ImageWidht_step*stepString.length/2 + CharSpace_step*(stepString.length-1)/2 );
                    break;
                  case 1:
                    console.log('Right aligment');
                    StartPosX_step = X_step - Math.cos(toRadian(Angle_step)) * ( ImageWidht_step*stepString.length + CharSpace_step*(stepString.length-1) );
                    StartPosY_step = Y_step - Math.sin(toRadian(Angle_step)) * ( ImageWidht_step*stepString.length + CharSpace_step*(stepString.length-1) );
                    break;
                }

                for (let char of stepString) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  // if(charCode >= 0 && charCode < 10) valueImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
                  if(charCode >= 0 && charCode < 10) valueStepImg[index].setProperty(hmUI.prop.MORE, {  
                    x: StartPosX_step - Diagonal_step + char_delta_x_step * index,
                    y: StartPosY_step - Diagonal_step + char_delta_y_step * index,
                    w: WI_size_step,
                    h: WI_size_step,
                    pos_x: Diagonal_step,
                    pos_y: Diagonal_step,
                    center_x: Diagonal_step,
                    center_y:  Diagonal_step,
                    angle: Angle_step,
                    src: ASCIIARRAY[charCode],
                    show_level: hmUI.show_level.ALL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  
                  units_step_img.setProperty(hmUI.prop.VISIBLE, true);
                  units_step_img.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: StartPosX_step - DiagonalUnits_step + char_delta_x_step * stepString.length,
                    y: StartPosY_step - DiagonalUnits_step + char_delta_y_step * stepString.length,
                    w: WI_units_size_step,
                    h: WI_units_size_step,
                    pos_x: DiagonalUnits_step,
                    pos_y: DiagonalUnits_step,
                    center_x: DiagonalUnits_step,
                    center_y:  DiagonalUnits_step,
                    angle: Angle_step,
                    //angle: unit_angl,
                    src: "0_Empty.png",  // unit image
                    show_level: hmUI.show_level.ALL,
                  });
                }
                else units_step_img.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                switch(Aligment_step)
                {
                  case -1:
                    StartPosX_step = X_step;
                    StartPosY_step = Y_step;
                    break;
                  case 0:
                    StartPosX_step = X_step - Math.cos(toRadian(Angle_step)) * ( ImageWidht_step*0.5 );
                    StartPosY_step = Y_step - Math.sin(toRadian(Angle_step)) * ( ImageWidht_step*0.5 );
                    break;
                  case 1:
                    StartPosX_step = X_step - Math.cos(toRadian(Angle_step)) * ( ImageWidht_step );
                    StartPosY_step = Y_step - Math.sin(toRadian(Angle_step)) * ( ImageWidht_step );
                    break;
                }
                valueStepImg[0].setProperty(hmUI.prop.MORE, {  
                  x: StartPosX_step - Diagonal_step + char_delta_x_step * index,
                  y: StartPosY_step - Diagonal_step + char_delta_y_step * index,
                  w: WI_size_step,
                  h: WI_size_step,
                  pos_x: Diagonal_step,
                  pos_y: Diagonal_step,
                  center_x: Diagonal_step,
                  center_y:  Diagonal_step,
                  angle: Angle_step,
                  src: "0_Empty.png",
                  show_level: hmUI.show_level.ALL,
                });
                units_step_img.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };

            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() { text_calorie_rotate() });  // Should update the text on the AOD screen if the data has changed
            
            
            function text_calorie_rotate() {  //  Get the parameter value and display it

              console.log('update CALORIE');
              
              let calorieCurrent=calorie.current;
              let calorieString = String(calorieCurrent);
              let index = 0;
              valueCalorieImg[0].setProperty(hmUI.prop.SRC, "0_Empty.png"); // Image displayed when there is no data. Without this string, "0" will be displayed.
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueCalorieImg[i].setProperty(hmUI.prop.SRC, '0_Empty.png');
              }             
              if (isFinite(calorieCurrent) && calorieString.length>0 && calorieString.length<6) {
                switch(Aligment_calorie)
                {
                  case -1:
                    console.log('Left aligment');
                    StartPosX_calorie = X_calorie;
                    StartPosY_calorie = Y_calorie;
                    break;
                  case 0:
                    console.log('Centr aligment');
                    StartPosX_calorie = X_calorie - Math.cos(toRadian(Angle_calorie)) * ( ImageWidht_calorie*calorieString.length/2 + CharSpace_calorie*(calorieString.length-1)/2 );
                    StartPosY_calorie = Y_calorie - Math.sin(toRadian(Angle_calorie)) * ( ImageWidht_calorie*calorieString.length/2 + CharSpace_calorie*(calorieString.length-1)/2 );
                    break;
                  case 1:
                    console.log('Right aligment');
                    StartPosX_calorie = X_calorie - Math.cos(toRadian(Angle_calorie)) * ( ImageWidht_calorie*calorieString.length + CharSpace_calorie*(calorieString.length-1) );
                    StartPosY_calorie = Y_calorie - Math.sin(toRadian(Angle_calorie)) * ( ImageWidht_calorie*calorieString.length + CharSpace_calorie*(calorieString.length-1) );
                    break;
                }

                for (let char of calorieString) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  // if(charCode >= 0 && charCode < 10) valueImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
                  if(charCode >= 0 && charCode < 10) valueCalorieImg[index].setProperty(hmUI.prop.MORE, {  
                    x: StartPosX_calorie - Diagonal_calorie + char_delta_x_calorie * index,
                    y: StartPosY_calorie - Diagonal_calorie + char_delta_y_calorie * index,
                    w: WI_size_calorie,
                    h: WI_size_calorie,
                    pos_x: Diagonal_calorie,
                    pos_y: Diagonal_calorie,
                    center_x: Diagonal_calorie,
                    center_y:  Diagonal_calorie,
                    angle: Angle_calorie,
                    src: ASCIIARRAY[charCode],
                    show_level: hmUI.show_level.ALL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  
                  units_calorie_img.setProperty(hmUI.prop.VISIBLE, true);
                  units_calorie_img.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: StartPosX_calorie - DiagonalUnits_calorie + char_delta_x_calorie * calorieString.length,
                    y: StartPosY_calorie - DiagonalUnits_calorie + char_delta_y_calorie * calorieString.length,
                    w: WI_units_size_calorie,
                    h: WI_units_size_calorie,
                    pos_x: DiagonalUnits_calorie,
                    pos_y: DiagonalUnits_calorie,
                    center_x: DiagonalUnits_calorie,
                    center_y:  DiagonalUnits_calorie,
                    angle: Angle_calorie,
                    //angle: unit_angl,
                    src: "0_Empty.png",  // unit image
                    show_level: hmUI.show_level.ALL,
                  });
                }
                else units_calorie_img.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                switch(Aligment_calorie)
                {
                  case -1:
                    StartPosX_calorie = X_calorie;
                    StartPosY_calorie = Y_calorie;
                    break;
                  case 0:
                    StartPosX_calorie = X_calorie - Math.cos(toRadian(Angle_calorie)) * ( ImageWidht_calorie*0.5 );
                    StartPosY_calorie = Y_calorie - Math.sin(toRadian(Angle_calorie)) * ( ImageWidht_calorie*0.5 );
                    break;
                  case 1:
                    StartPosX_calorie = X_calorie - Math.cos(toRadian(Angle_calorie)) * ( ImageWidht_calorie );
                    StartPosY_calorie = Y_calorie - Math.sin(toRadian(Angle_calorie)) * ( ImageWidht_calorie );
                    break;
                }
                valueCalorieImg[0].setProperty(hmUI.prop.MORE, {  
                  x: StartPosX_calorie - Diagonal_calorie + char_delta_x_calorie * index,
                  y: StartPosY_calorie - Diagonal_calorie + char_delta_y_calorie * index,
                  w: WI_calorie_size,
                  h: WI_calorie_size,
                  pos_x: Diagonal_calorie,
                  pos_y: Diagonal_calorie,
                  center_x: Diagonal_calorie,
                  center_y:  Diagonal_calorie,
                  angle: Angle_calorie,
                  src: "0_Empty.png",
                  show_level: hmUI.show_level.ALL,
                });
                units_calorie_img.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };





            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 83,
              y: 176,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ALL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 6,
              y: 263,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ALL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 169,
              y: 267,
              src: 'System_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ALL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 325,
              font_array: ["Pulse_font_01.png","Pulse_font_02.png","Pulse_font_03.png","Pulse_font_04.png","Pulse_font_05.png","Pulse_font_06.png","Pulse_font_07.png","Pulse_font_08.png","Pulse_font_09.png","Pulse_font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Battery_symbo.png',
              unit_tc: 'Battery_symbo.png',
              unit_en: 'Battery_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ALL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 134,
              y: 316,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png","Batt_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ALL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 31,
              y: 325,
              font_array: ["Pulse_font_01.png","Pulse_font_02.png","Pulse_font_03.png","Pulse_font_04.png","Pulse_font_05.png","Pulse_font_06.png","Pulse_font_07.png","Pulse_font_08.png","Pulse_font_09.png","Pulse_font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ALL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 313,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ALL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 198,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ALL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 115,
              y: 239,
              w: 40,
              h: 16,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ALL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 236,
              font_array: ["Weather_font_01.png","Weather_font_02.png","Weather_font_03.png","Weather_font_04.png","Weather_font_05.png","Weather_font_06.png","Weather_font_07.png","Weather_font_08.png","Weather_font_09.png","Weather_font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'weather_symbo_02.png',
              unit_tc: 'weather_symbo_02.png',
              unit_en: 'weather_symbo_02.png',
              negative_image: 'weather_symbo_01.png',
              invalid_image: 'weather_symbo_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 41,
              y: 196,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 82,
              day_startY: 95,
              day_sc_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              day_tc_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              day_en_array: ["number_0.png","number_1.png","number_2.png","number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ALL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 111,
              y: 128,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ALL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 72,
              month_startY: 127,
              month_sc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_tc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_en_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ALL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 138,
              y: 108,
              image_array: ["Cal_icon_01.png","Cal_icon_02.png","Cal_icon_03.png","Cal_icon_04.png","Cal_icon_05.png","Cal_icon_06.png","Cal_icon_07.png","Cal_icon_08.png","Cal_icon_09.png","Cal_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ALL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 38,
              y: 108,
              image_array: ["Step_icon_01.png","Step_icon_02.png","Step_icon_03.png","Step_icon_04.png","Step_icon_05.png","Step_icon_06.png","Step_icon_07.png","Step_icon_08.png","Step_icon_09.png","Step_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ALL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 85,
              am_y: 10,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 85,
              pm_y: 10,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 9,
              hour_startY: 11,
              hour_array: ["Time_HG_01.png","Time_HG_02.png","Time_HG_03.png","Time_HG_04.png","Time_HG_05.png","Time_HG_06.png","Time_HG_07.png","Time_HG_08.png","Time_HG_09.png","Time_HG_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 109,
              minute_startY: 11,
              minute_array: ["Time_H_01.png","Time_H_02.png","Time_H_03.png","Time_H_04.png","Time_H_05.png","Time_H_06.png","Time_H_07.png","Time_H_08.png","Time_H_09.png","Time_H_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 86,
              second_startY: 68,
              second_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ALL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 114,
              y: 17,
              w: 67,
              h: 59,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ALL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 15,
              w: 61,
              h: 62,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ALL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 166,
              y: 253,
              w: 25,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ALL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 117,
              y: 194,
              w: 38,
              h: 67,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 39,
              y: 195,
              w: 38,
              h: 61,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 302,
              w: 54,
              h: 24,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ALL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 329,
              w: 55,
              h: 24,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ALL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 105,
              w: 21,
              h: 43,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ALL,
            });





            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_step_rotate();  // update text when screen turns on
                text_calorie_rotate();
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  