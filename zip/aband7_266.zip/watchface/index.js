﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: '00-fondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 32,
              am_y: 136,
              am_sc_path: '03_AM.png',
              am_en_path: '03_AM.png',
              pm_x: 32,
              pm_y: 136,
              pm_sc_path: '03_PM.png',
              pm_en_path: '03_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 69,
              hour_startY: 42,
              hour_array: ["00_hora_00.png","00_hora_01.png","00_hora_02.png","00_hora_03.png","00_hora_04.png","00_hora_05.png","00_hora_06.png","00_hora_07.png","00_hora_08.png","00_hora_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 113,
              minute_startY: 177,
              minute_array: ["01_min_00.png","01_min_01.png","01_min_02.png","01_min_03.png","01_min_04.png","01_min_05.png","01_min_06.png","01_min_07.png","01_min_08.png","01_min_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 104,
              second_startY: 294,
              second_array: ["02_seg_00.png","02_seg_01.png","02_seg_02.png","02_seg_03.png","02_seg_04.png","02_seg_05.png","02_seg_06.png","02_seg_07.png","02_seg_08.png","02_seg_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '03_Segundos.png',
              second_centerX: 50,
              second_centerY: 313,
              second_posX: 45,
              second_posY: 46,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'AOD-fondo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 32,
              am_y: 136,
              am_sc_path: 'AOD_AM.png',
              am_en_path: 'AOD_AM.png',
              pm_x: 32,
              pm_y: 136,
              pm_sc_path: 'AOD_PM.png',
              pm_en_path: 'AOD_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 69,
              hour_startY: 42,
              hour_array: ["AOD_Hora_00.png","AOD_Hora_01.png","AOD_Hora_02.png","AOD_Hora_03.png","AOD_Hora_04.png","AOD_Hora_05.png","AOD_Hora_06.png","AOD_Hora_07.png","AOD_Hora_08.png","AOD_Hora_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 113,
              minute_startY: 177,
              minute_array: ["AOD_nim_00.png","AOD_nim_01.png","AOD_nim_02.png","AOD_nim_03.png","AOD_nim_04.png","AOD_nim_05.png","AOD_nim_06.png","AOD_nim_07.png","AOD_nim_08.png","AOD_nim_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 104,
              second_startY: 294,
              second_array: ["AOD_seg_00.png","AOD_seg_01.png","AOD_seg_02.png","AOD_seg_03.png","AOD_seg_04.png","AOD_seg_05.png","AOD_seg_06.png","AOD_seg_07.png","AOD_seg_08.png","AOD_seg_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'AOD_SEG_ANALOG.png',
              second_centerX: 50,
              second_centerY: 313,
              second_posX: 45,
              second_posY: 46,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}