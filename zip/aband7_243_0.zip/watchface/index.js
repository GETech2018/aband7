﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_frame_animation_1 = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 194,
              // h: 368,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview1.png', path: 'F-10.png' },
                { id: 2, preview: 'bg_edit_2_preview1.png', path: 'F-02.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'F-03.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'F-04.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: 'F-05.png' },
                { id: 6, preview: 'bg_edit_6_preview.png', path: 'F-06.png' },
                { id: 7, preview: 'bg_edit_7_preview.png', path: 'F-07.png' },
                { id: 8, preview: 'bg_edit_8_preview.png', path: 'F-08.png' },
                { id: 9, preview: 'bg_edit_9_preview.png', path: 'F-09.png' },
              ],
              count: 9,
              default_id: 1,
              fg: 'preview_fondos.png',
              tips_bg: 'preview_fondos.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 110,
              day_startY: 241,
              day_sc_array: ["03-dia-nro-00.png","03-dia-nro-01.png","03-dia-nro-02.png","03-dia-nro-03.png","03-dia-nro-04.png","03-dia-nro-05.png","03-dia-nro-06.png","03-dia-nro-07.png","03-dia-nro-08.png","03-dia-nro-09.png"],
              day_tc_array: ["03-dia-nro-00.png","03-dia-nro-01.png","03-dia-nro-02.png","03-dia-nro-03.png","03-dia-nro-04.png","03-dia-nro-05.png","03-dia-nro-06.png","03-dia-nro-07.png","03-dia-nro-08.png","03-dia-nro-09.png"],
              day_en_array: ["03-dia-nro-00.png","03-dia-nro-01.png","03-dia-nro-02.png","03-dia-nro-03.png","03-dia-nro-04.png","03-dia-nro-05.png","03-dia-nro-06.png","03-dia-nro-07.png","03-dia-nro-08.png","03-dia-nro-09.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 49,
              y: 236,
              week_en: ["02-dia-ingles-00.png","02-dia-ingles-01.png","02-dia-ingles-02.png","02-dia-ingles-03.png","02-dia-ingles-04.png","02-dia-ingles-05.png","02-dia-ingles-06.png"],
              week_tc: ["02-dia-ingles-00.png","02-dia-ingles-01.png","02-dia-ingles-02.png","02-dia-ingles-03.png","02-dia-ingles-04.png","02-dia-ingles-05.png","02-dia-ingles-06.png"],
              week_sc: ["02-dia-ingles-00.png","02-dia-ingles-01.png","02-dia-ingles-02.png","02-dia-ingles-03.png","02-dia-ingles-04.png","02-dia-ingles-05.png","02-dia-ingles-06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 55,
              hour_startY: 120,
              hour_array: ["hora_nro_00.png","hora_nro_01.png","hora_nro_02.png","hora_nro_03.png","hora_nro_04.png","hora_nro_05.png","hora_nro_06.png","hora_nro_07.png","hora_nro_08.png","hora_nro_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 54,
              minute_startY: 178,
              minute_array: ["hora_nro_00.png","hora_nro_01.png","hora_nro_02.png","hora_nro_03.png","hora_nro_04.png","hora_nro_05.png","hora_nro_06.png","hora_nro_07.png","hora_nro_08.png","hora_nro_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Comp",
              anim_fps: 60,
              anim_size: 60,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'AOD-Watchface_fondo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 55,
              hour_startY: 120,
              hour_array: ["AOD-hora_nro_00.png","AOD-hora_nro_01.png","AOD-hora_nro_02.png","AOD-hora_nro_03.png","AOD-hora_nro_04.png","AOD-hora_nro_05.png","AOD-hora_nro_06.png","AOD-hora_nro_07.png","AOD-hora_nro_08.png","AOD-hora_nro_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 54,
              minute_startY: 178,
              minute_array: ["AOD-hora_nro_00.png","AOD-hora_nro_01.png","AOD-hora_nro_02.png","AOD-hora_nro_03.png","AOD-hora_nro_04.png","AOD-hora_nro_05.png","AOD-hora_nro_06.png","AOD-hora_nro_07.png","AOD-hora_nro_08.png","AOD-hora_nro_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}