﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: '00_fondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 142,
              y: 269,
              image_array: ["bateria_00.png","bateria_01.png","bateria_02.png","bateria_03.png","bateria_04.png","bateria_05.png","bateria_06.png","bateria_07.png","bateria_08.png","bateria_09.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: -2,
              y: 273,
              font_array: ["clima_nro_00.png","clima_nro_01.png","clima_nro_02.png","clima_nro_03.png","clima_nro_04.png","clima_nro_05.png","clima_nro_06.png","clima_nro_07.png","clima_nro_08.png","clima_nro_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'clima_nro_10.png',
              unit_tc: 'clima_nro_10.png',
              unit_en: 'clima_nro_10.png',
              negative_image: 'clima_nro_11.png',
              invalid_image: 'clima_nro_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 25,
              hour_startY: 9,
              hour_array: ["hora_hora_00.png","hora_hora_01.png","hora_hora_02.png","hora_hora_03.png","hora_hora_04.png","hora_hora_05.png","hora_hora_06.png","hora_hora_07.png","hora_hora_08.png","hora_hora_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 25,
              minute_startY: 133,
              minute_array: ["hora_m_00.png","hora_m_01.png","hora_m_02.png","hora_m_03.png","hora_m_04.png","hora_m_05.png","hora_m_06.png","hora_m_07.png","hora_m_08.png","hora_m_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 142,
              y: 269,
              image_array: ["AOD-bateria_00.png","AOD-bateria_01.png","AOD-bateria_02.png","AOD-bateria_03.png","AOD-bateria_04.png","AOD-bateria_05.png","AOD-bateria_06.png","AOD-bateria_07.png","AOD-bateria_08.png","AOD-bateria_09.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 25,
              hour_startY: 9,
              hour_array: ["AOD-hora_hora_00.png","AOD-hora_hora_01.png","AOD-hora_hora_02.png","AOD-hora_hora_03.png","AOD-hora_hora_04.png","AOD-hora_hora_05.png","AOD-hora_hora_06.png","AOD-hora_hora_07.png","AOD-hora_hora_08.png","AOD-hora_hora_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 25,
              minute_startY: 133,
              minute_array: ["AOD-hora_hora_00.png","AOD-hora_hora_01.png","AOD-hora_hora_02.png","AOD-hora_hora_03.png","AOD-hora_hora_04.png","AOD-hora_hora_05.png","AOD-hora_hora_06.png","AOD-hora_hora_07.png","AOD-hora_hora_08.png","AOD-hora_hora_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 23,
              y: 138,
              w: 154,
              h: 100,
              src: 'btn_transparente.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 133,
              y: 250,
              w: 52,
              h: 110,
              src: 'btn_transparente.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 23,
              y: 0,
              w: 154,
              h: 124,
              src: 'btn_transparente.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 13,
              y: 250,
              w: 115,
              h: 110,
              src: 'btn_transparente.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}