﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 50,
              font_array: ["widget_nro_00.png","widget_nro_01.png","widget_nro_02.png","widget_nro_03.png","widget_nro_04.png","widget_nro_05.png","widget_nro_06.png","widget_nro_07.png","widget_nro_08.png","widget_nro_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'widget_nro_10.png',
              unit_tc: 'widget_nro_10.png',
              unit_en: 'widget_nro_10.png',
              negative_image: 'widget_nro_11.png',
              invalid_image: 'widget_nro_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 157,
              y: 37,
              image_array: ["Clima-ico-01.png","Clima-ico-02.png","Clima-ico-03.png","Clima-ico-04.png","Clima-ico-05.png","Clima-ico-06.png","Clima-ico-07.png","Clima-ico-08.png","Clima-ico-09.png","Clima-ico-10.png","Clima-ico-11.png","Clima-ico-12.png","Clima-ico-13.png","Clima-ico-14.png","Clima-ico-15.png","Clima-ico-16.png","Clima-ico-17.png","Clima-ico-18.png","Clima-ico-19.png","Clima-ico-20.png","Clima-ico-21.png","Clima-ico-22.png","Clima-ico-23.png","Clima-ico-24.png","Clima-ico-25.png","Clima-ico-26.png","Clima-ico-27.png","Clima-ico-28.png","Clima-ico-29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: -1,
              y: 10,
              week_en: ["dias_ES_00.png","dias_ES_01.png","dias_ES_02.png","dias_ES_03.png","dias_ES_04.png","dias_ES_05.png","dias_ES_06.png"],
              week_tc: ["dias_ES_00.png","dias_ES_01.png","dias_ES_02.png","dias_ES_03.png","dias_ES_04.png","dias_ES_05.png","dias_ES_06.png"],
              week_sc: ["dias_ES_00.png","dias_ES_01.png","dias_ES_02.png","dias_ES_03.png","dias_ES_04.png","dias_ES_05.png","dias_ES_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 59,
              month_startY: 46,
              month_sc_array: ["Meses_ES_00.png","Meses_ES_01.png","Meses_ES_02.png","Meses_ES_03.png","Meses_ES_04.png","Meses_ES_05.png","Meses_ES_06.png","Meses_ES_07.png","Meses_ES_08.png","Meses_ES_09.png","Meses_ES_10.png","Meses_ES_11.png"],
              month_tc_array: ["Meses_ES_00.png","Meses_ES_01.png","Meses_ES_02.png","Meses_ES_03.png","Meses_ES_04.png","Meses_ES_05.png","Meses_ES_06.png","Meses_ES_07.png","Meses_ES_08.png","Meses_ES_09.png","Meses_ES_10.png","Meses_ES_11.png"],
              month_en_array: ["Meses_ES_00.png","Meses_ES_01.png","Meses_ES_02.png","Meses_ES_03.png","Meses_ES_04.png","Meses_ES_05.png","Meses_ES_06.png","Meses_ES_07.png","Meses_ES_08.png","Meses_ES_09.png","Meses_ES_10.png","Meses_ES_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 8,
              day_startY: 42,
              day_sc_array: ["dia_NRO_00.png","dia_NRO_01.png","dia_NRO_02.png","dia_NRO_03.png","dia_NRO_04.png","dia_NRO_05.png","dia_NRO_06.png","dia_NRO_07.png","dia_NRO_08.png","dia_NRO_09.png"],
              day_tc_array: ["dia_NRO_00.png","dia_NRO_01.png","dia_NRO_02.png","dia_NRO_03.png","dia_NRO_04.png","dia_NRO_05.png","dia_NRO_06.png","dia_NRO_07.png","dia_NRO_08.png","dia_NRO_09.png"],
              day_en_array: ["dia_NRO_00.png","dia_NRO_01.png","dia_NRO_02.png","dia_NRO_03.png","dia_NRO_04.png","dia_NRO_05.png","dia_NRO_06.png","dia_NRO_07.png","dia_NRO_08.png","dia_NRO_09.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 13,
              font_array: ["Nro_bat_00.png","Nro_bat_01.png","Nro_bat_02.png","Nro_bat_03.png","Nro_bat_04.png","Nro_bat_05.png","Nro_bat_06.png","Nro_bat_07.png","Nro_bat_08.png","Nro_bat_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Nro_bat_10.png',
              unit_tc: 'Nro_bat_10.png',
              unit_en: 'Nro_bat_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 14,
              src: 'ico_bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 0,
              hour_startY: 89,
              hour_array: ["Hora_00.png","Hora_01.png","Hora_02.png","Hora_03.png","Hora_04.png","Hora_05.png","Hora_06.png","Hora_07.png","Hora_08.png","Hora_09.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 214,
              minute_array: ["Hora_00.png","Hora_01.png","Hora_02.png","Hora_03.png","Hora_04.png","Hora_05.png","Hora_06.png","Hora_07.png","Hora_08.png","Hora_09.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 0,
              hour_startY: 89,
              hour_array: ["AOD_HORA_00.png","AOD_HORA_01.png","AOD_HORA_02.png","AOD_HORA_03.png","AOD_HORA_04.png","AOD_HORA_05.png","AOD_HORA_06.png","AOD_HORA_07.png","AOD_HORA_08.png","AOD_HORA_09.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 214,
              minute_array: ["AOD_HORA_00.png","AOD_HORA_01.png","AOD_HORA_02.png","AOD_HORA_03.png","AOD_HORA_04.png","AOD_HORA_05.png","AOD_HORA_06.png","AOD_HORA_07.png","AOD_HORA_08.png","AOD_HORA_09.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}