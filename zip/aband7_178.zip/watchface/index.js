﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

        let hands_toggle_state = ''
        let hands_toggle_btn = ''

    function loadSettings() {
      if (hmFS.SysProGetInt('kobe3_hands') === undefined) {
        hands_toggle_state = 0;
        hmFS.SysProSetInt('kobe3_hands', hands_toggle_state);
      }
      else {
        hands_toggle_state = hmFS.SysProGetInt('kobe3_hands');
      }

    }

    function click_hands_Switcher() {
      let hands_toggle_total = 2;

      hands_toggle_state = (hands_toggle_state + 1) % hands_toggle_total;

      hmFS.SysProSetInt('kobe3_hands', hands_toggle_state);

      apply_hands_Switcher();
    }

    function apply_hands_Switcher() {
      switch (hands_toggle_state) {
        case 0:
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: '0055.Hour.png',
            hour_centerX: 99,
            hour_centerY: 184,
            hour_posX: 12,
            hour_posY: 135,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: '0056.png',
            minute_centerX: 99,
            minute_centerY: 184,
            minute_posX: 13,
            minute_posY: 182,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            second_path: '0058.png',
            second_centerX: 99,
            second_centerY: 184,
            second_posX: 8,
            second_posY: 183,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          break;

        case 1:
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: 'hand_hour_red_3.png',
            hour_centerX: 99,
            hour_centerY: 184,
            hour_posX: 21,
            hour_posY: 106,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: 'hand_min_red_3.png',
            minute_centerX: 99,
            minute_centerY: 184,
            minute_posX: 16,
            minute_posY: 156,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });

          normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            second_path: 'hand_sec.png',
            second_centerX: 99,
            second_centerY: 184,
            second_posX: 14,
            second_posY: 189,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          break;

        default:
          break;
      }
    }



        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 164,
              y: 188,
              week_en: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              week_tc: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              week_sc: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 168,
              day_startY: 166,
              day_sc_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              day_tc_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              day_en_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 49,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 302,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: '0060.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 251,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 170,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: -13,
              y: 110,
              image_array: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.battery.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0055.Hour.png',
              hour_centerX: 99,
              hour_centerY: 184,
              hour_posX: 15,
              hour_posY: 135,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0056.png',
              minute_centerX: 99,
              minute_centerY: 184,
              minute_posX: 13,
              minute_posY: 182,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0058.png',
              second_centerX: 99,
              second_centerY: 184,
              second_posX: 8,
              second_posY: 182,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 83,
              hour_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: '0012.png',
              hour_unit_tc: '0012.png',
              hour_unit_en: '0012.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 94,
              minute_startY: 83,
              minute_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 145,
              second_startY: 94,
              second_array: ["seconds.0002.png","seconds.0003.png","seconds.0004.png","seconds.0005.png","seconds.0006.png","seconds.0007.png","seconds.0008.png","seconds.0009.png","seconds.0010.png","seconds.0011.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 54,
              y: 297,
              w: 89,
              h: 48,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 39,
              y: 44,
              w: 100,
              h: 27,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 163,
              y: 138,
              w: 31,
              h: 94,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 75,
              w: 141,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 14,
              y: 163,
              w: 51,
              h: 43,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 245,
              w: 100,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


        hands_toggle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 79,
          y: 162,
          text: '',
          w: 41,
          h: 41,
          normal_src: '0_Empty.png',
          press_src: '0_Empty.png',
          click_func: () => {
            click_hands_Switcher();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

         loadSettings();
         apply_hands_Switcher();

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}