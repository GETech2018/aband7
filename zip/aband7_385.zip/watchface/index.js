﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright c SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js


let holidayMapCache = {};  // 年ごとのキャッシュ

function getCachedHolidayMap(year) {
  if (!holidayMapCache[year]) {
    holidayMapCache[year] = getHolidayMap(year);
  }
  return holidayMapCache[year];
}

function getHolidayMap(year) {
  const fixedHolidays = {
    "1/1": "元日",
    "2/11": "建国記念の日",
    "2/23": "天皇誕生日",
    "4/29": "昭和の日",
    "5/3": "憲法記念日",
    "5/4": "みどりの日",
    "5/5": "こどもの日",
    "8/11": "山の日",
    "11/3": "文化の日",
    "11/23": "勤労感謝の日"
  };

  // 春分・秋分の日（近似）
  const shunbun = Math.floor(20.8431 + 0.242194 * (year - 1980)) - Math.floor((year - 1980)/4);
  const shubun = Math.floor(23.2488 + 0.242194 * (year - 1980)) - Math.floor((year - 1980)/4);
  fixedHolidays[`3/${shunbun}`] = "春分の日";
  fixedHolidays[`9/${shubun}`] = "秋分の日";

  // 成人の日（1月第2月曜日）
  let janMondayCount = 0;
  for (let d = 1; d <= 14; d++) {
    const tmp = new Date(year, 0, d);
    if (tmp.getDay() === 1) {
      janMondayCount++;
      if (janMondayCount === 2) {
        fixedHolidays[`1/${d}`] = "成人の日";
        break;
      }
    }
  }

  // スポーツの日（10月第2月曜日）
  let octMondayCount = 0;
  for (let d = 1; d <= 14; d++) {
    const tmp = new Date(year, 9, d);
    if (tmp.getDay() === 1) {
      octMondayCount++;
      if (octMondayCount === 2) {
        fixedHolidays[`10/${d}`] = "スポーツの日";
        break;
      }
    }
  }

  // 振替休日: 5月6日が対象（5月3〜5が日曜の場合）
  const mayCheck = [3, 4, 5];
  for (let i = 0; i < mayCheck.length; i++) {
    const checkDate = new Date(year, 4, mayCheck[i]); // May = 4
    if (checkDate.getDay() === 0) {
      fixedHolidays["5/6"] = "振替休日";
      break;
    }
  }

  // 敬老の日（9月第3月曜日）
  let sepMondayCount = 0;
  for (let d = 1; d <= 21; d++) {
    const tmp = new Date(year, 8, d);
    if (tmp.getDay() === 1) {
      sepMondayCount++;
      if (sepMondayCount === 3) {
        fixedHolidays[`9/${d}`] = "敬老の日";
        break;
      }
    }
  }

  // 海の日（7月第3月曜日）
  let julMondayCount = 0;
  for (let d = 1; d <= 21; d++) {
    const tmp = new Date(year, 6, d);
    if (tmp.getDay() === 1) {
      julMondayCount++;
      if (julMondayCount === 3) {
        fixedHolidays[`7/${d}`] = "海の日";
        break;
      }
    }
  }

  // 国民の休日（前後が祝日の平日）
  const holidayDates = Object.keys(fixedHolidays).map(key => {
    const [m, d] = key.split("/").map(Number);
    return new Date(year, m - 1, d).getTime();
  });
  holidayDates.sort((a, b) => a - b);

  for (let i = 0; i < holidayDates.length - 1; i++) {
    const prev = new Date(holidayDates[i]);
    const next = new Date(holidayDates[i + 1]);
    const gap = (next.getTime() - prev.getTime()) / (1000 * 60 * 60 * 24);

    if (gap === 2) {
      const mid = new Date(prev.getTime() + 24 * 60 * 60 * 1000);
      const key = `${mid.getMonth() + 1}/${mid.getDate()}`;
      if (!fixedHolidays[key]) {
        fixedHolidays[key] = "国民の休日";
      }
    }
  }

  return fixedHolidays;
}

function isHoliday(year, month, day, dayOfWeek, holidayMap) {
  const key = `${month}/${day}`;
  const isFixed = holidayMap.hasOwnProperty(key);

  // 振替休日（祝日が日曜日の場合、翌月曜日が振替休日）
  if (!isFixed && dayOfWeek === 1) {
    const yesterday = `${month}/${day - 1}`;
    const yesterdayDate = new Date(year, month - 1, day - 1);
    if (holidayMap.hasOwnProperty(yesterday) && yesterdayDate.getDay() === 0) {
      return true;
    }
  }
  return isFixed;
}

// --- カレンダーウィジェットを初期化して使い回す ---
let calendar_dateWidgets = [];
let calendar_headerWidget = null;
let calendar_weekdayWidgets = [];
let calendar_currentDate = new Date();
let calendar_lastCheckedDate = new Date();

// レイアウト定数（先に宣言しておく）
const calendar_baseX = 18;
const calendar_baseY = 135;
const calendar_cellW = 22;
const calendar_cellH = 21;

// 今日マーク（〇画像）は1個だけ
let calendar_todayImgWidget = null;
const todayImgSrc = 'circle_hotpink.png';
const todayImgW = calendar_cellW;
const todayImgH = calendar_cellH;

function initCalendarWidgets() {
  // 年月表示ウィジェット
  calendar_headerWidget = hmUI.createWidget(hmUI.widget.TEXT, {
    x: calendar_baseX,
    y: calendar_baseY - 5,
    w: 160,
    h: 32,
    text_size: 28,
    align_h: hmUI.align.CENTER_H,
    color: 0x000000,
    text: "",
    show_level: hmUI.show_level.ONLY_NORMAL,
  });

  // 今日マーク（1個だけ、最初は非表示）
  if (!calendar_todayImgWidget) {
    calendar_todayImgWidget = hmUI.createWidget(hmUI.widget.IMG, {
      x: -9999,
      y: -9999,
      w: todayImgW,
      h: todayImgH,
      src: todayImgSrc,
      show_level: hmUI.show_level.ONLY_NORMAL,
    });
    calendar_todayImgWidget.setProperty(hmUI.prop.VISIBLE, false);
  }

  // 曜日ウィジェット
  const weekdayColors = [0xFF0000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x4040FF];
  const weekdays = ["日", "月", "火", "水", "木", "金", "土"];
  for (let i = 0; i < 7; i++) {
    const widget = hmUI.createWidget(hmUI.widget.TEXT, {
      x: calendar_baseX + i * calendar_cellW,
      y: calendar_baseY + 40,
      w: calendar_cellW,
      h: calendar_cellH,
      text_size: 14,
      align_h: hmUI.align.CENTER_H,
      color: weekdayColors[i],
      text: weekdays[i],
      show_level: hmUI.show_level.ONLY_NORMAL,
    });
    calendar_weekdayWidgets.push(widget);
  }

  // 日付ウィジェット（42マス）
  const calendar_dateBaseY = calendar_baseY + 60;
  for (let row = 0; row < 6; row++) {
    for (let col = 0; col < 7; col++) {
      const widget = hmUI.createWidget(hmUI.widget.TEXT, {
        x: calendar_baseX + col * calendar_cellW,
        y: calendar_dateBaseY + row * calendar_cellH,
        w: calendar_cellW,
        h: calendar_cellH,
        text_size: 14,
        align_h: hmUI.align.CENTER_H,
        color: 0xFFFFFF,
        text: "",
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
      calendar_dateWidgets.push(widget);
    }
  }
}

function drawCalendar(date) {
  const weekdayColors = [0xFF0000, 0x000000, 0x000000, 0x000000, 0x000000, 0x000000, 0x4040FF];

  const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
  const startDay = firstDay.getDay();
  const daysInMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const today = new Date();

  const isCurrentMonth = (today.getFullYear() === date.getFullYear() && today.getMonth() === date.getMonth());

  let yearMonthStr = `${date.getFullYear()}/${String(date.getMonth() + 1).padStart(2, '0')}`;
  if (isCurrentMonth) yearMonthStr = `- ${yearMonthStr} -`;
  calendar_headerWidget.setProperty(hmUI.prop.MORE, { text: yearMonthStr });

  // 今日マーク（単一ウィジェット）を一旦非表示にする
  if (calendar_todayImgWidget) {
    calendar_todayImgWidget.setProperty(hmUI.prop.VISIBLE, false);
  }

  const calendar_dateBaseY = calendar_baseY + 60;
  let dateNum = 1;

  for (let i = 0; i < 42; i++) {
    const col = i % 7;
    const row = Math.floor(i / 7);

    if (i >= startDay && dateNum <= daysInMonth) {
      const holidayMap = getCachedHolidayMap(date.getFullYear());
      const isHolidayToday = isHoliday(date.getFullYear(), date.getMonth() + 1, dateNum, col, holidayMap);

      // 今日判定（表示中の月が今月 & 日付一致）
      const isTodayCell = isCurrentMonth && (dateNum === today.getDate());

      // 文字色は休日/曜日で決定（今日色ハイライトは廃止）
      const color = isHolidayToday ? 0xFF0000 : weekdayColors[col];

      // テキスト更新
      calendar_dateWidgets[i].setProperty(hmUI.prop.MORE, {
        text: String(dateNum).padStart(2, ' '),
        color: color
      });
      calendar_dateWidgets[i].setProperty(hmUI.prop.VISIBLE, true);

      // 今日セルには単一の〇画像を移動して表示
      if (isTodayCell && calendar_todayImgWidget) {
        const x = calendar_baseX + col * calendar_cellW;
        const y = calendar_dateBaseY + row * calendar_cellH;
        const px = x + Math.floor((calendar_cellW - todayImgW) / 2);
        const py = y + Math.floor((calendar_cellH - todayImgH) / 2);
        calendar_todayImgWidget.setProperty(hmUI.prop.MORE, { x: px, y: py, src: todayImgSrc });
        calendar_todayImgWidget.setProperty(hmUI.prop.VISIBLE, true);
      }

      dateNum++;
    } else {
      // 月に含まれないマスは非表示
      calendar_dateWidgets[i].setProperty(hmUI.prop.VISIBLE, false);
    }
  }
}

function checkTodayUpdate() {
  const now = new Date();
  if (now.getDate() !== calendar_lastCheckedDate.getDate() ||
      now.getMonth() !== calendar_lastCheckedDate.getMonth() ||
      now.getFullYear() !== calendar_lastCheckedDate.getFullYear()) {

    calendar_currentDate = new Date(now);
    drawCalendar(calendar_currentDate);
    calendar_lastCheckedDate = new Date(now);
  }
}

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['(月)', '(火)', '(水)', '(木)', '(金)', '(土)', '(日)'];
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_cal_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let timeSensor = '';




        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 332,
              font_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 14,
              y: 336,
              src: 'Steps3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 349,
              font_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 158,
              y: 336,
              image_array: ["batt_10.png","batt_11.png","batt_12.png","batt_13.png","batt_14.png","batt_15.png","batt_16.png","batt_17.png","batt_18.png","batt_19.png","batt_20.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 13,
              y: 15,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 51,
              y: 8,
              w: 79,
              h: 41,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 132,
              y: 16,
              w: 57,
              h: 43,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: (月), (火), (水), (木), (金), (土), (日),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 64,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 109,
              minute_startY: 64,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'AnaBackground-03.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hours.png',
              hour_centerX: 99,
              hour_centerY: 184,
              hour_posX: 16,
              hour_posY: 114,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minutes.png',
              minute_centerX: 99,
              minute_centerY: 184,
              minute_posX: 14,
              minute_posY: 153,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Seconds.png',
              second_centerX: 99,
              second_centerY: 184,
              second_posX: 12,
              second_posY: 151,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

// ---- HB.png を誕生日(2/3)のみ表示 ----
//(function setHBVisibleForToday(){
//  const now = new Date();
//  const isBirthday = (now.getMonth() === 1 /* Feb */) && (now.getDate() === 3);
//  image_top_img.setProperty(hmUI.prop.VISIBLE, isBirthday);
//})();



//
// brightness controll by @shockwave55
//
btnbrightnessdown = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 0,
  y: 0,
  w: 97,
  h: 25,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  click_func: () => {
    const currentBrightness = hmSetting.getBrightness();
    if (currentBrightness >= 10){
      hmSetting.setBrightness(currentBrightness - 10);
    }
  },
  show_level: hmUI.show_level.ONLY_NORMAL
});
btnbrightnessdown.setProperty(hmUI.prop.VISIBLE, true);

btnbrightnessup = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 97,
  y: 0,
  w: 97,
  h: 25,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  click_func: () => {
    const currentBrightness = hmSetting.getBrightness();
    if (currentBrightness <= 90){
      hmSetting.setBrightness(currentBrightness + 10);
    }
  },
  show_level: hmUI.show_level.ONLY_NORMAL
});
btnbrightnessup.setProperty(hmUI.prop.VISIBLE, true);

//
// end brightness controll
//
            // end user_script_beforeShortcuts.js
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 326,
              w: 194,
              h: 42,
              src: '0_Empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 64,
              w: 86,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,
              y: 64,
              w: 95,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 24,
              w: 196,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_end.js');
            // start user_script_end.js

     // カレンダー描画とタップエリア追加
    initCalendarWidgets();
    drawCalendar(calendar_currentDate);


const screenWidth = 194;
const tapAreaHeight = 200;
const tapAreaY = 130;


// 前月ボタン (左1/4)
const prevBtn = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 0,
  y: tapAreaY,
  w: screenWidth * 0.25, // 48px
  h: tapAreaHeight,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    calendar_currentDate.setMonth(calendar_currentDate.getMonth() - 1);
    drawCalendar(calendar_currentDate);
    checkTodayUpdate();
  }
});
prevBtn.setProperty(hmUI.prop.VISIBLE, true);

// 今月に戻るボタン (中央1/2)
const currentBtn = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: screenWidth * 0.25, // 48px
  y: tapAreaY,
  w: screenWidth * 0.5,  // 97px
  h: tapAreaHeight,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    calendar_currentDate = new Date();
    drawCalendar(calendar_currentDate);
    checkTodayUpdate();
  }
});
currentBtn.setProperty(hmUI.prop.VISIBLE, true);

// 次月ボタン (右1/4)
const nextBtn = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: screenWidth * 0.75, // 145px
  y: tapAreaY,
  w: screenWidth * 0.25, // 49px
  h: tapAreaHeight,
  text: '',
  normal_src: '0_Empty.png',
  press_src: '0_Empty.png',
  show_level: hmUI.show_level.ONLY_NORMAL,
  click_func: () => {
    calendar_currentDate.setMonth(calendar_currentDate.getMonth() + 1);
    drawCalendar(calendar_currentDate);
    checkTodayUpdate();
  }
});
nextBtn.setProperty(hmUI.prop.VISIBLE, true);

// 一度実行しておく
checkTodayUpdate();
///
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

calendar_currentDate = new Date();         // 現在日時を取得し直す
drawCalendar(calendar_currentDate);        // カレンダーを再描画
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}