﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_heart_rate_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_battery_icon_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'scale3-main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 334,
              font_array: ["r0.png","r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'rSpace.png',
              unit_tc: 'rSpace.png',
              unit_en: 'rSpace.png',
              dot_image: 'rDot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 334,
              src: 'Km.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 334,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 5,
              y: 334,
              src: 'Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 131,
              y: 287,
              week_en: ["we(1).png","we(2).png","we(3).png","we(4).png","we(5).png","we(6).png","we(7).png"],
              week_tc: ["we(1).png","we(2).png","we(3).png","we(4).png","we(5).png","we(6).png","we(7).png"],
              week_sc: ["we(1).png","we(2).png","we(3).png","we(4).png","we(5).png","we(6).png","we(7).png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 78,
              day_startY: 286,
              day_sc_array: ["SY-0.png","SY-1.png","SY-2.png","SY-3.png","SY-4.png","SY-5.png","SY-6.png","SY-7.png","SY-8.png","SY-9.png"],
              day_tc_array: ["SY-0.png","SY-1.png","SY-2.png","SY-3.png","SY-4.png","SY-5.png","SY-6.png","SY-7.png","SY-8.png","SY-9.png"],
              day_en_array: ["SY-0.png","SY-1.png","SY-2.png","SY-3.png","SY-4.png","SY-5.png","SY-6.png","SY-7.png","SY-8.png","SY-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 18,
              month_startY: 286,
              month_sc_array: ["SY-0.png","SY-1.png","SY-2.png","SY-3.png","SY-4.png","SY-5.png","SY-6.png","SY-7.png","SY-8.png","SY-9.png"],
              month_tc_array: ["SY-0.png","SY-1.png","SY-2.png","SY-3.png","SY-4.png","SY-5.png","SY-6.png","SY-7.png","SY-8.png","SY-9.png"],
              month_en_array: ["SY-0.png","SY-1.png","SY-2.png","SY-3.png","SY-4.png","SY-5.png","SY-6.png","SY-7.png","SY-8.png","SY-9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 64,
              y: 294,
              src: 'SY--.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 97,
              y: -2,
              w: 68,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF0000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 8,
              src: 'Heart_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 26,
              y: -2,
              w: 70,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FF00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 12,
              y: 7,
              src: 'Battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 15,
              hour_startY: 225,
              hour_array: ["CGG-Gr-0.png","CGG-Gr-1.png","CGG-Gr-2.png","CGG-Gr-3.png","CGG-Gr-4.png","CGG-Gr-5.png","CGG-Gr-6.png","CGG-Gr-7.png","CGG-Gr-8.png","CGG-Gr-9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 108,
              minute_startY: 225,
              minute_array: ["CGG-Gr-0.png","CGG-Gr-1.png","CGG-Gr-2.png","CGG-Gr-3.png","CGG-Gr-4.png","CGG-Gr-5.png","CGG-Gr-6.png","CGG-Gr-7.png","CGG-Gr-8.png","CGG-Gr-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: 239,
              src: 'DOT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour1-shadow_3.png',
              hour_centerX: 96,
              hour_centerY: 120,
              hour_posX: 13,
              hour_posY: 94,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute1-shadow_3.png',
              minute_centerX: 96,
              minute_centerY: 120,
              minute_posX: 13,
              minute_posY: 94,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second1-shadow_MS_3.png',
              second_centerX: 96,
              second_centerY: 120,
              second_posX: 13,
              second_posY: 94,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 15,
              hour_startY: 225,
              hour_array: ["CGG-40-0.png","CGG-40-1.png","CGG-40-2.png","CGG-40-3.png","CGG-40-4.png","CGG-40-5.png","CGG-40-6.png","CGG-40-7.png","CGG-40-8.png","CGG-40-9.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 108,
              minute_startY: 225,
              minute_array: ["CGG-40-0.png","CGG-40-1.png","CGG-40-2.png","CGG-40-3.png","CGG-40-4.png","CGG-40-5.png","CGG-40-6.png","CGG-40-7.png","CGG-40-8.png","CGG-40-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: 239,
              src: 'DOT-40.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}