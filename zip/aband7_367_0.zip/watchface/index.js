﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'Background-01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 95,
              month_startY: 262,
              month_sc_array: ["Montha.png","Monthb.png","Monthc.png","Monthd.png","Monthe.png","Monthf.png","Monthg.png","Monthh.png","Monthi.png","Monthj.png","Monthk.png","Monthl.png"],
              month_tc_array: ["Montha.png","Monthb.png","Monthc.png","Monthd.png","Monthe.png","Monthf.png","Monthg.png","Monthh.png","Monthi.png","Monthj.png","Monthk.png","Monthl.png"],
              month_en_array: ["Montha.png","Monthb.png","Monthc.png","Monthd.png","Monthe.png","Monthf.png","Monthg.png","Monthh.png","Monthi.png","Monthj.png","Monthk.png","Monthl.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 76,
              day_startY: 262,
              day_sc_array: ["Date0-01.png","Date1-01.png","Date2-01.png","Date3-01.png","Date4-01.png","Date5-01.png","Date6-01.png","Date7-01.png","Date8-01.png","Date9-01.png"],
              day_tc_array: ["Date0-01.png","Date1-01.png","Date2-01.png","Date3-01.png","Date4-01.png","Date5-01.png","Date6-01.png","Date7-01.png","Date8-01.png","Date9-01.png"],
              day_en_array: ["Date0-01.png","Date1-01.png","Date2-01.png","Date3-01.png","Date4-01.png","Date5-01.png","Date6-01.png","Date7-01.png","Date8-01.png","Date9-01.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 84,
              y: 229,
              week_en: ["Day1-01.png","Day2-01.png","Day3-01.png","Day4-01.png","Day5-01.png","Day6-01.png","Day7-01.png"],
              week_tc: ["Day1-01.png","Day2-01.png","Day3-01.png","Day4-01.png","Day5-01.png","Day6-01.png","Day7-01.png"],
              week_sc: ["Day1-01.png","Day2-01.png","Day3-01.png","Day4-01.png","Day5-01.png","Day6-01.png","Day7-01.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hours.png',
              hour_centerX: 99,
              hour_centerY: 184,
              hour_posX: 14,
              hour_posY: 114,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minutes.png',
              minute_centerX: 99,
              minute_centerY: 184,
              minute_posX: 14,
              minute_posY: 152,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Seconds.png',
              second_centerX: 99,
              second_centerY: 184,
              second_posX: 12,
              second_posY: 152,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 126,
              y: 113,
              w: 55,
              h: 140,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 113,
              w: 55,
              h: 140,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 268,
              w: 97,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}