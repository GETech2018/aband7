﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_image_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: '00-fondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 20,
              font_array: ["02-nro-00.png","02-nro-01.png","02-nro-02.png","02-nro-03.png","02-nro-04.png","02-nro-05.png","02-nro-06.png","02-nro-07.png","02-nro-08.png","02-nro-09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 21,
              src: 'ico-pasos.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 336,
              font_array: ["02-nro-00.png","02-nro-01.png","02-nro-02.png","02-nro-03.png","02-nro-04.png","02-nro-05.png","02-nro-06.png","02-nro-07.png","02-nro-08.png","02-nro-09.png"],
              padding: false,
              h_space: -1,
              unit_sc: '02-nro-10.png',
              unit_tc: '02-nro-10.png',
              unit_en: '02-nro-10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 75,
              y: 338,
              src: 'ico-bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 0,
              hour_startY: 52,
              hour_array: ["01-hora-nro-00.png","01-hora-nro-01.png","01-hora-nro-02.png","01-hora-nro-03.png","01-hora-nro-04.png","01-hora-nro-05.png","01-hora-nro-06.png","01-hora-nro-07.png","01-hora-nro-08.png","01-hora-nro-09.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 104,
              minute_startY: 52,
              minute_array: ["01-hora-nro-00.png","01-hora-nro-01.png","01-hora-nro-02.png","01-hora-nro-03.png","01-hora-nro-04.png","01-hora-nro-05.png","01-hora-nro-06.png","01-hora-nro-07.png","01-hora-nro-08.png","01-hora-nro-09.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 28,
              day_startY: 246,
              day_sc_array: ["03-fecha-00.png","03-fecha-01.png","03-fecha-02.png","03-fecha-03.png","03-fecha-04.png","03-fecha-05.png","03-fecha-06.png","03-fecha-07.png","03-fecha-08.png","03-fecha-09.png"],
              day_tc_array: ["03-fecha-00.png","03-fecha-01.png","03-fecha-02.png","03-fecha-03.png","03-fecha-04.png","03-fecha-05.png","03-fecha-06.png","03-fecha-07.png","03-fecha-08.png","03-fecha-09.png"],
              day_en_array: ["03-fecha-00.png","03-fecha-01.png","03-fecha-02.png","03-fecha-03.png","03-fecha-04.png","03-fecha-05.png","03-fecha-06.png","03-fecha-07.png","03-fecha-08.png","03-fecha-09.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 67,
              month_startY: 246,
              month_sc_array: ["03-fecha-00.png","03-fecha-01.png","03-fecha-02.png","03-fecha-03.png","03-fecha-04.png","03-fecha-05.png","03-fecha-06.png","03-fecha-07.png","03-fecha-08.png","03-fecha-09.png"],
              month_tc_array: ["03-fecha-00.png","03-fecha-01.png","03-fecha-02.png","03-fecha-03.png","03-fecha-04.png","03-fecha-05.png","03-fecha-06.png","03-fecha-07.png","03-fecha-08.png","03-fecha-09.png"],
              month_en_array: ["03-fecha-00.png","03-fecha-01.png","03-fecha-02.png","03-fecha-03.png","03-fecha-04.png","03-fecha-05.png","03-fecha-06.png","03-fecha-07.png","03-fecha-08.png","03-fecha-09.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '00-punto.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 0,
              hour_startY: 52,
              hour_array: ["AOD-01-hora-nro-00.png","AOD-01-hora-nro-01.png","AOD-01-hora-nro-02.png","AOD-01-hora-nro-03.png","AOD-01-hora-nro-04.png","AOD-01-hora-nro-05.png","AOD-01-hora-nro-06.png","AOD-01-hora-nro-07.png","AOD-01-hora-nro-08.png","AOD-01-hora-nro-09.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 104,
              minute_startY: 52,
              minute_array: ["AOD-01-hora-nro-00.png","AOD-01-hora-nro-01.png","AOD-01-hora-nro-02.png","AOD-01-hora-nro-03.png","AOD-01-hora-nro-04.png","AOD-01-hora-nro-05.png","AOD-01-hora-nro-06.png","AOD-01-hora-nro-07.png","AOD-01-hora-nro-08.png","AOD-01-hora-nro-09.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}