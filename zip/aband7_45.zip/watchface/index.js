﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_stand_icon_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_pai_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 36,
              font_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 36,
              font_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 124,
              y: 65,
              image_array: ["a10_heavy-snow.png","a11_heavyrain.png","a12_sandstorm.png","a13_sleet.png","a14_fog.png","a15_haze.png","a16_thunderstorm.png","a17_snowthunder.png","a18_dusty.png","a19_extreme-rain.png","a1_cloudy.png","a20_rainwithhail.png","a21_heavyrainwithhail.png","a22_rainthunder.png","a23_duststorm.png","a24_thunder.png","a25_heavyrain.png","a26_unknown.png","a27_night-cloudy.png","a28_night-rain.png","a29_clear-night.png","a2_chance-of-rain.png","a3_chance-of-snow.png","a4_sunny.png","a5_overcast.png","a6_lightrain.png","a7_lightsnow.png","a8_modrate-rain.png","a9_moderate-snow.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 41,
              day_startY: 104,
              day_sc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              day_tc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              day_en_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 17,
              y: 70,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 15,
              month_startY: 39,
              month_sc_array: ["MONTH_01.png","MONTH_02.png","MONTH_03.png","MONTH_04.png","MONTH_05.png","MONTH_06.png","MONTH_07.png","MONTH_08.png","MONTH_09.png","MONTH_10.png","MONTH_11.png","MONTH_12.png"],
              month_tc_array: ["MONTH_01.png","MONTH_02.png","MONTH_03.png","MONTH_04.png","MONTH_05.png","MONTH_06.png","MONTH_07.png","MONTH_08.png","MONTH_09.png","MONTH_10.png","MONTH_11.png","MONTH_12.png"],
              month_en_array: ["MONTH_01.png","MONTH_02.png","MONTH_03.png","MONTH_04.png","MONTH_05.png","MONTH_06.png","MONTH_07.png","MONTH_08.png","MONTH_09.png","MONTH_10.png","MONTH_11.png","MONTH_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 74,
              y: 335,
              src: 'percent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 31,
              y: 337,
              font_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 2,
              y: 302,
              image_array: ["bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 107,
              y: 301,
              src: 'adidas.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 132,
              y: 222,
              src: 'fire-white1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 260,
              font_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 35,
              y: 220,
              src: 'NicePng1_steps-png_1241229.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 11,
              y: 260,
              font_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 84,
              y: 214,
              src: 'divide.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 84,
              y: 8,
              src: 'divide.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -3,
              hour_startY: 132,
              hour_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              hour_zero: 1,
              hour_space: -8,
              hour_align: hmUI.align.LEFT,

              minute_startX: 95,
              minute_startY: 132,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: -8,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 74,
              y: 335,
              src: 'percent.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 31,
              y: 337,
              font_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 2,
              y: 302,
              image_array: ["bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -3,
              hour_startY: 132,
              hour_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              hour_zero: 1,
              hour_space: -8,
              hour_align: hmUI.align.LEFT,

              minute_startX: 95,
              minute_startY: 132,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: -8,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  