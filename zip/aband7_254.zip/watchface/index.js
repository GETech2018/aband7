﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_image_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: '木目2Dark-2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 312,
              week_en: ["Week_J(1).png","Week_J(2).png","Week_J(3).png","Week_J(4).png","Week_J(5).png","Week_J(6).png","Week_J(7).png"],
              week_tc: ["Week_J(1).png","Week_J(2).png","Week_J(3).png","Week_J(4).png","Week_J(5).png","Week_J(6).png","Week_J(7).png"],
              week_sc: ["Week_J(1).png","Week_J(2).png","Week_J(3).png","Week_J(4).png","Week_J(5).png","Week_J(6).png","Week_J(7).png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 4,
              month_startY: 318,
              month_sc_array: ["d(0).png","d(1).png","d(2).png","d(3).png","d(4).png","d(5).png","d(6).png","d(7).png","d(8).png","d(9).png"],
              month_tc_array: ["d(0).png","d(1).png","d(2).png","d(3).png","d(4).png","d(5).png","d(6).png","d(7).png","d(8).png","d(9).png"],
              month_en_array: ["d(0).png","d(1).png","d(2).png","d(3).png","d(4).png","d(5).png","d(6).png","d(7).png","d(8).png","d(9).png"],
              month_zero: 0,
              month_space: 0,
              month_unit_sc: 'unit_d.png',
              month_unit_tc: 'unit_d.png',
              month_unit_en: 'unit_d.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 278,
              font_array: ["step(0).png","step(1).png","step(2).png","step(3).png","step(4).png","step(5).png","step(6).png","step(7).png","step(8).png","step(9).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 12,
              y: 274,
              src: 'step_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'scale-bule_W&B.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 234,
              font_array: ["temp(0).png","temp(1).png","temp(2).png","temp(3).png","temp(4).png","temp(5).png","temp(6).png","temp(7).png","temp(8).png","temp(9).png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp_unit.png',
              unit_tc: 'temp_unit.png',
              unit_en: 'temp_unit.png',
              negative_image: 'temp_Negative.png',
              invalid_image: 'temp_no_data.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 152,
              y: 190,
              image_array: ["wea(10).png","wea(11).png","wea(12).png","wea(13).png","wea(14).png","wea(15).png","wea(16).png","wea(17).png","wea(18).png","wea(19).png","wea(20).png","wea(21).png","wea(22).png","wea(23).png","wea(24).png","wea(25).png","wea(26).png","wea(27).png","wea(28).png","wea(29).png","wea(30).png","wea(31).png","wea(32).png","wea(33).png","wea(34).png","wea(35).png","wea(36).png","wea(37).png","wea(38).png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 42,
              y: 4,
              font_array: ["batt_num(0).png","batt_num(1).png","batt_num(2).png","batt_num(3).png","batt_num(4).png","batt_num(5).png","batt_num(6).png","batt_num(7).png","batt_num(8).png","batt_num(9).png"],
              padding: false,
              h_space: 0,
              unit_sc: 'batt_percent.png',
              unit_tc: 'batt_percent.png',
              unit_en: 'batt_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 15,
              y: 0,
              src: 'batt_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 73,
              day_startY: 318,
              day_sc_array: ["d(0).png","d(1).png","d(2).png","d(3).png","d(4).png","d(5).png","d(6).png","d(7).png","d(8).png","d(9).png"],
              day_tc_array: ["d(0).png","d(1).png","d(2).png","d(3).png","d(4).png","d(5).png","d(6).png","d(7).png","d(8).png","d(9).png"],
              day_en_array: ["d(0).png","d(1).png","d(2).png","d(3).png","d(4).png","d(5).png","d(6).png","d(7).png","d(8).png","d(9).png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 2,
              hour_startY: 224,
              hour_array: ["Metal_LT0.png","Metal_LT1.png","Metal_LT2.png","Metal_LT3.png","Metal_LT4.png","Metal_LT5.png","Metal_LT6.png","Metal_LT7.png","Metal_LT8.png","Metal_LT9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'Metal_Unit.png',
              hour_unit_tc: 'Metal_Unit.png',
              hour_unit_en: 'Metal_Unit.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Metal_LT0.png","Metal_LT1.png","Metal_LT2.png","Metal_LT3.png","Metal_LT4.png","Metal_LT5.png","Metal_LT6.png","Metal_LT7.png","Metal_LT8.png","Metal_LT9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'clock_hour1-shadow2.png',
              hour_centerX: 100,
              hour_centerY: 120,
              hour_posX: 13,
              hour_posY: 94,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'clock_minute1-shadow2.png',
              minute_centerX: 100,
              minute_centerY: 120,
              minute_posX: 13,
              minute_posY: 94,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'clock_second1-shadow.png',
              second_centerX: 100,
              second_centerY: 120,
              second_posX: 13,
              second_posY: 94,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 42,
              y: 4,
              font_array: ["batt_num(0).png","batt_num(1).png","batt_num(2).png","batt_num(3).png","batt_num(4).png","batt_num(5).png","batt_num(6).png","batt_num(7).png","batt_num(8).png","batt_num(9).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 15,
              y: 0,
              src: 'batt_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 41,
              hour_startY: 120,
              hour_array: ["DigLTW00.png","DigLTW01.png","DigLTW02.png","DigLTW03.png","DigLTW04.png","DigLTW05.png","DigLTW06.png","DigLTW07.png","DigLTW08.png","DigLTW09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'DigLLW_unitpng.png',
              hour_unit_tc: 'DigLLW_unitpng.png',
              hour_unit_en: 'DigLLW_unitpng.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["DigLTW00.png","DigLTW01.png","DigLTW02.png","DigLTW03.png","DigLTW04.png","DigLTW05.png","DigLTW06.png","DigLTW07.png","DigLTW08.png","DigLTW09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 130,
              y: -10,
              w: 65,
              h: 60,
              src: 'Alarm1W.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}