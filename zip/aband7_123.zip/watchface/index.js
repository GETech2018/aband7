﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 149,
              y: 339,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 36,
              y: 163,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 12,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 51,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              unit_sc: 'Act_font_13.png',
              unit_tc: 'Act_font_13.png',
              unit_en: 'Act_font_13.png',
              negative_image: 'Act_font_12.png',
              invalid_image: 'Act_font_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 22,
              y: 7,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 8,
              y: 329,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 6,
              month_startY: 293,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 24,
              day_startY: 259,
              day_sc_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_tc_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_en_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 285,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 233,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              unit_sc: '0_Empty.png',
              unit_tc: '0_Empty.png',
              unit_en: '0_Empty.png',
              imperial_unit_sc: '0_Empty.png',
              imperial_unit_tc: '0_Empty.png',
              imperial_unit_en: '0_Empty.png',
              dot_image: 'Act_font_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 177,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 121,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 64,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              unit_sc: 'Act_font_14.png',
              unit_tc: 'Act_font_14.png',
              unit_en: 'Act_font_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 19,
              am_y: 162,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 19,
              pm_y: 162,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 5,
              hour_startY: 84,
              hour_array: ["Time_Color_Font_01.png","Time_Color_Font_02.png","Time_Color_Font_03.png","Time_Color_Font_04.png","Time_Color_Font_05.png","Time_Color_Font_06.png","Time_Color_Font_07.png","Time_Color_Font_08.png","Time_Color_Font_09.png","Time_Color_Font_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 5,
              minute_startY: 177,
              minute_array: ["time_font_01.png","time_font_02.png","time_font_03.png","time_font_04.png","time_font_05.png","time_font_06.png","time_font_07.png","time_font_08.png","time_font_09.png","time_font_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 316,
              w: 39,
              h: 42,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 82,
              y: 7,
              w: 39,
              h: 43,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}