try {
  (() => {
    const init_view = () => {
      let screenType = hmSetting.getScreenType()
      let wfScreen = screenType == hmSetting.screen_type.WATCHFACE
      let aodScreen = screenType == hmSetting.screen_type.AOD
      let editScreen = screenType == hmSetting.screen_type.SETTINGS

      const deviceInfo = hmSetting.getDeviceInfo()
      const screenWidth = deviceInfo.width
      const screenHeight = deviceInfo.height
      const DVC = screenHeight == 490 ? true : false
      const path = DVC ? 'XB7' : 'AB7'

      const P = [
        // Fill color; data_y XB7; bg_x;              bg_y; bg/anim_path -- on Normal Display
          [0xE5C63D,   239,        69,                48,   'funny' ], // 0 Funny Spanch Bob     442
          [0xE5C63D,   239,        97,                207,  'happy' ], // 1 Happy Spanch Bob     283
          [0xE5C63D,   239,        69,                48,   'coming'], // 2 Spanch Bob is coming 442
          [0xD84C38,   269,        screenWidth / 2,   319,  'krabs' ], // 3 Mr Krabs             171
          [0xD81858,   269,        screenWidth / 2,   254,  'patrik'], // 4 Patrik               236
          [0x53B895,   269,        95,                202,  'squid' ]] // 5 Squidward            288
    
      const AP = [
        // bg_y; bg_src -- on AoD
          [207,  'funny' ], // 0 Funny Spanch Bob     283
          [207,  'happy' ], // 1 Happy Spanch Bob     283
          [207,  'coming'], // 2 Spanch Bob is coming 283
          [319,  'krabs' ], // 3 Mr Krabs             171
          [254,  'patrik'], // 4 Patrik               236
          [202,  'squid' ]] // 5 Squidward            288

      let langIndex = hmSetting.getLanguage()
      let langArrayIndex = langIndex == 4 ? 0 : 1

      const LangArray = [ [ 'Шаги', 'Пульс', 'Калории', 'PAI за день'],
                          [ 'Steps', 'Pulse', 'Calories', 'PAI per day']]

      const eWT = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: 104,
        x: 0,
        y: 0,
        w: screenWidth,
        h: DVC ? 80 : 40,
        select_image: 'images/zero.png',
        un_select_image: 'images/zero.png',
        default_type: 0,
        optional_types: [
          {type: 0, preview: 'images/status/preview/0.png',  title_en: LangArray[langArrayIndex][0]},
          {type: 1, preview: 'images/status/preview/1.png',  title_en: LangArray[langArrayIndex][1]},
          {type: 2, preview: 'images/status/preview/2.png',  title_en: LangArray[langArrayIndex][2]},
          {type: 3, preview: 'images/status/preview/3.png',  title_en: LangArray[langArrayIndex][3]}
        ],
        count: 4,
        tips_x: 50,
        tips_y: 40,
        tips_width: 92,
        tips_margin: 5,
        tips_BG: 'images/tips_bg.png'
      })

      let eCT = eWT.getProperty(hmUI.prop.CURRENT_TYPE)

      const LangArray2 = [ [ 'Забавный', 'Счастливый', 'Грядущий', 'Крабс', 'Патрик', 'Сквидвард', 'Как на основном экране'],
                           [ 'Funny', 'Happy', 'Coming', 'Mr. Krabs', 'Patrik', 'Squidward', 'As on the main screen']]

      const eT = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: 101,
        x: screenWidth / 2 - 96,
        y: DVC ? 82 : 40,
        w: 96,
        h: DVC ? 326 : 288,
        select_image: 'images/zero.png',
        un_select_image: 'images/zero.png',
        default_type: 0,
        optional_types: [
          {type: 0, preview: `images/${path}_funny.png`,  title_en: LangArray2[langArrayIndex][0]},
          {type: 1, preview: `images/${path}_happy.png`,  title_en: LangArray2[langArrayIndex][1]},
          {type: 2, preview: `images/${path}_coming.png`, title_en: LangArray2[langArrayIndex][2]},
          {type: 3, preview: `images/${path}_krabs.png`,  title_en: LangArray2[langArrayIndex][3]},
          {type: 4, preview: `images/${path}_patrik.png`, title_en: LangArray2[langArrayIndex][4]},
          {type: 5, preview: `images/${path}_squid.png`,  title_en: LangArray2[langArrayIndex][5]}
        ],
        count: 6,
        tips_x: 2,
        tips_y: 150,
        tips_width: 92,
        tips_margin: 5,
        tips_BG: 'images/tips_bg.png'
      })

      let cT = eT.getProperty(hmUI.prop.CURRENT_TYPE)

      const eAT = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: 102,
        x: screenWidth / 2,
        y: DVC ? 82 : 40,
        w: 96,
        h: DVC ? 326 : 288,
        select_image: 'images/zero.png',
        un_select_image: 'images/zero.png',
        default_type: 0,
        optional_types: [
          {type: 0, preview: `images/aod/preview/${path}_colored.png`, title_en: LangArray2[langArrayIndex][6]},
          {type: 1, preview: `images/aod/preview/${path}_funny.png`,   title_en: LangArray2[langArrayIndex][0]},
          {type: 2, preview: `images/aod/preview/${path}_happy.png`,   title_en: LangArray2[langArrayIndex][1]},
          {type: 3, preview: `images/aod/preview/${path}_coming.png`,  title_en: LangArray2[langArrayIndex][2]},
          {type: 4, preview: `images/aod/preview/${path}_krabs.png`,   title_en: LangArray2[langArrayIndex][3]},
          {type: 5, preview: `images/aod/preview/${path}_patrik.png`,  title_en: LangArray2[langArrayIndex][4]},
          {type: 6, preview: `images/aod/preview/${path}_squid.png`,   title_en: LangArray2[langArrayIndex][5]}
        ],
        count: 7,
        tips_x: 2,
        tips_y: 150,
        tips_width: 92,
        tips_margin: 5,
        tips_BG: 'images/tips_bg.png'
      })

      const LangArray3 = [ [ 'Выкл', 'Белый', 'Цветной'],
                           [ 'Off', 'White', 'Colore']]

      const pV = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: 103,
        x: 0,
        y: DVC ? 410 : 328,
        w: screenWidth,
        h: DVC ? 80 : 40,
        select_image: 'images/zero.png',
        un_select_image: 'images/zero.png',
        default_type: 0,
        optional_types: [
          {type: 0, preview: 'images/aod/preview/0.png',  title_en: LangArray3[langArrayIndex][0]},
          {type: 1, preview: 'images/aod/preview/1.png',  title_en: LangArray3[langArrayIndex][1]},
          {type: 2, preview: 'images/aod/preview/2.png',  title_en: LangArray3[langArrayIndex][2]}
        ],
        count: 3,
        tips_x: 50,
        tips_y: -30,
        tips_width: 92,
        tips_margin: 5,
        tips_BG: 'images/tips_bg.png'
      })

      let cAT = 0
      if (editScreen) return
      else cAT = eAT.getProperty(hmUI.prop.CURRENT_TYPE) == 0
               ? eT.getProperty(hmUI.prop.CURRENT_TYPE)
               : eAT.getProperty(hmUI.prop.CURRENT_TYPE) - 1
      let cPVT = pV.getProperty(hmUI.prop.CURRENT_TYPE), pVP = ''
      cPVT == 1 ? pVP = 'white' : pVP = 'colored'

      if (wfScreen) {
        hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0,
          y: 0,
          w: screenWidth,
          h: screenHeight,
          radius: DVC ? 96 : 25,
          color: P[cT][0]
        })

        const heroBackground = hmUI.createWidget(hmUI.widget.IMG, {
          x: screenWidth / 2 - P[cT][2],
          y: screenHeight - P[cT][3],
          src: 'images/backgrounds/' + P[cT][4] + '.png'
        })

        if (cT == 2) heroBackground.setProperty(hmUI.prop.MORE, {src: 'images/backgrounds/funny.png'})

        let count = 0, vC = 0

        //[Анимация Забавного Спанч Боба]
        let aW01 = {}, aW02 = {}, aW03 = {}, aW04 = {}, aW05 = {}, aW06 = {}, aW07 = {}
        if (cT == 0) {        
          aW01 = hmUI.createWidget(hmUI.widget.IMG, { // Правая рука
            pos_x: screenWidth / 2 - 107,
            pos_y: screenHeight - 90,
            center_x: screenWidth / 2 - 69,
            center_y: screenHeight - 77,
            w: screenWidth,
            h: screenHeight,
            src: 'images/animation/' + P[cT][4] + '_1.png'
          })

          aW02 = hmUI.createWidget(hmUI.widget.IMG, { // Левая рука
            pos_x: screenWidth / 2 + 67,
            pos_y: screenHeight - 90,
            center_x: 165,
            center_y: screenHeight - 77,
            w: screenWidth,
            h: screenHeight,
            src: 'images/animation/' + P[cT][4] + '_2.png'
          })

          hmUI.createWidget(hmUI.widget.IMG, { // Тело
            x: screenWidth / 2 - 89,
            y: screenHeight - 207,
            src: 'images/animation/' + P[cT][4] + '_3.png'
          })

          // aW03 = hmUI.createWidget(hmUI.widget.IMG, { // Тело для анимации. Оставил на будущие версии браслета.
          //   pos_x: screenWidth / 2 - 89,
          //   pos_y: screenHeight - 207,
          //   center_x: screenWidth / 2,
          //   center_y: screenHeight - 46,
          //   w: screenWidth,
          //   h: screenHeight,
          //   src: 'images/animation/' + P[cT][4] + '_3.png'
          // })

          aW04 = hmUI.createWidget(hmUI.widget.IMG, { // Глаз
            pos_x: screenWidth / 2 - 38,
            pos_y: screenHeight - 173,
            center_x: screenWidth / 2 - 32,
            center_y: screenHeight - 150,
            w: screenWidth,
            h: screenHeight,
            src: 'images/animation/' + P[cT][4] + '_4.png'
          })

          aW05 = hmUI.createWidget(hmUI.widget.IMG, { // Глаз
            pos_x: screenWidth / 2 + 12,
            pos_y: screenHeight - 153,
            center_x: screenWidth / 2 + 32,
            center_y: screenHeight - 150,
            w: screenWidth,
            h: screenHeight,
            src: 'images/animation/' + P[cT][4] + '_4.png'
          })

          hmUI.createWidget(hmUI.widget.IMG, { // Веко + нос
            x: screenWidth / 2 - 66,
            y: screenHeight - 153,
            src: 'images/animation/' + P[cT][4] + '_5.png'
          })

          // aW06 = hmUI.createWidget(hmUI.widget.IMG, { // Веко + нос для анимации. Оставил на будущие версии браслета.
          //   pos_x: screenWidth / 2 - 66,
          //   pos_y: screenHeight - 153,
          //   center_x: screenWidth / 2,
          //   center_y: screenHeight - 46,
          //   w: screenWidth,
          //   h: screenHeight,
          //   src: 'images/animation/' + P[cT][4] + '_5.png'
          // })

          aW07 = hmUI.createWidget(hmUI.widget.IMG, { // Рот
            pos_x: screenWidth / 2 - 9,
            pos_y: screenHeight - 102,
            center_x: screenWidth / 2 - 39,
            center_y: screenHeight - 90,
            w: screenWidth,
            h: screenHeight,
            src: 'images/animation/' + P[cT][4] + '_6.png'
          })
        }

        function Animation0() {
          if (count < 10) vC = count
          else if (count < 18) vC = 19 - count
          else if (count < 27) vC = count - 18
          else if (count < 36) vC = 37 - count
          aW01.setProperty(hmUI.prop.ANGLE, vC / 2)
          aW02.setProperty(hmUI.prop.ANGLE, -vC / 2)
          aW04.setProperty(hmUI.prop.ANGLE, count * 10)
          aW05.setProperty(hmUI.prop.ANGLE, count * 10)
          aW07.setProperty(hmUI.prop.ANGLE, vC)
          // if (count < 18) { //Движение туловищем. Отключено, так как работает с тормозами.
          //   aW01.setProperty(hmUI.prop.POS_Y, 400 - vC / 4)
          //   aW02.setProperty(hmUI.prop.POS_Y, 400 + vC / 4)
          //   aW03.setProperty(hmUI.prop.ANGLE, vC / 5)
          //   aW06.setProperty(hmUI.prop.ANGLE, vC / 5)
          // }
          // else if (count < 36) {
          //   aW01.setProperty(hmUI.prop.POS_Y, 400 + vC / 4)
          //   aW02.setProperty(hmUI.prop.POS_Y, 400 - vC / 4)
          //   aW03.setProperty(hmUI.prop.ANGLE, -vC / 10)
          //   aW06.setProperty(hmUI.prop.ANGLE, -vC / 10)
          // }
          count++
          if (count > 36) count = 0
        }
        //[]

        //[Анимация Cчастливого Спанч Боба]
        let aW11 = {}, aW12 = {}, aW13 = {}, aW14 = {}, aW15 = {}, aW16 = {}, aW17 = {}, aW18 = {}, aW19 = {}, aW110 = {}, aW111 = {}
        if (cT == 1) {
          aW11 = hmUI.createWidget(hmUI.widget.IMG, { // Зубы
            x: screenWidth / 2 -18,
            y: screenHeight - 86,
            src: 'images/animation/' + P[cT][4] + '_4.png'
          })

          aW12 = hmUI.createWidget(hmUI.widget.STROKE_RECT, { // Рот
            x: screenWidth / 2 - 57,
            y: screenHeight - 189,
            w: 116,
            h: 106,
            radius: 53,
            color: 0x000000,
            line_width: 2
          })

          aW13 = hmUI.createWidget(hmUI.widget.IMG, { // Глаза + нос
            x: screenWidth / 2 - 60,
            y: screenHeight - 189,
            src: 'images/animation/' + P[cT][4] + '_1.png'
          })

          aW14 = hmUI.createWidget(hmUI.widget.IMG, { // Правая щека
            pos_x: screenWidth / 2 - 70,
            pos_y: screenHeight - 132,
            center_x: screenWidth / 2 - 68,
            center_y: screenHeight - 115,
            w: screenWidth,
            h: screenHeight,
            src: 'images/animation/' + P[cT][4] + '_2.png'
          })

          aW15 = hmUI.createWidget(hmUI.widget.IMG, { // Левая щека
            pos_x: screenWidth / 2 + 35,
            pos_y: screenHeight - 132,
            center_x: screenWidth / 2 + 68,
            center_y: screenHeight - 115,
            w: screenWidth,
            h: screenHeight,
            src: 'images/animation/' + P[cT][4] + '_3.png'
          })

          aW16 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Блик правого глаза
            center_x: screenWidth / 2 - 23,
            center_y: screenHeight - 153,
            radius: 6,
            color: 0xffffff
          })

          aW17 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Блик правого глаза
            center_x: screenWidth / 2 - 35,
            center_y: screenHeight - 145,
            radius: 4,
            color: 0xffffff
          })

          aW18 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Блик правого глаза
            center_x: screenWidth / 2 - 25,
            center_y: screenHeight - 138,
            radius: 3,
            color: 0xffffff
          })

          aW19 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Блик левого глаза
            center_x: screenWidth / 2 + 23,
            center_y: screenHeight - 153,
            radius: 6,
            color: 0xffffff
          })

          aW110 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Блик левого глаза
            center_x: screenWidth / 2 + 35,
            center_y: screenHeight - 145,
            radius: 4,
            color: 0xffffff
          })

          aW111 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Блик левого глаза
            center_x: screenWidth / 2 + 25,
            center_y: screenHeight - 138,
            radius: 3,
            color: 0xffffff
          })
        }

        function Animation1() {
          count < 10 ? vC = count : vC = 18 - count
          aW11.setProperty(hmUI.prop.Y, screenHeight - 86 - vC)
          aW12.setProperty(hmUI.prop.H, 106 - vC)
          aW12.setProperty(hmUI.prop.W, 116 + 0.5 * vC)
          aW12.setProperty(hmUI.prop.X, screenWidth / 2 - 57 - 0.25 * vC)
          aW12.setProperty(hmUI.prop.RADIUS, 53 - 0.3 * vC)
          aW13.setProperty(hmUI.prop.Y, screenHeight - 189 - vC)
          aW14.setProperty(hmUI.prop.ANGLE, - 2 * vC)
          aW15.setProperty(hmUI.prop.ANGLE, 2 * vC)
          aW16.setProperty(hmUI.prop.RADIUS, 6 + vC / 3)
          aW16.setProperty(hmUI.prop.CENTER_Y, screenHeight - 153 - vC)
          aW17.setProperty(hmUI.prop.RADIUS, 5 - vC / 3)
          aW17.setProperty(hmUI.prop.CENTER_Y, screenHeight - 145 - vC)
          aW18.setProperty(hmUI.prop.RADIUS, 3 + 2 / (vC + 1))
          aW18.setProperty(hmUI.prop.CENTER_Y, screenHeight - 138 - vC)
          aW19.setProperty(hmUI.prop.RADIUS, 6 - vC / 3)
          aW19.setProperty(hmUI.prop.CENTER_Y, screenHeight - 153 - vC)
          aW110.setProperty(hmUI.prop.RADIUS, 5 + vC / 3)
          aW110.setProperty(hmUI.prop.CENTER_Y, screenHeight - 145 - vC)
          aW111.setProperty(hmUI.prop.RADIUS, 3 + 2 / (vC + 1))
          aW111.setProperty(hmUI.prop.CENTER_Y, screenHeight - 138 - vC)
          count++
          if (count > 18) count = 0
        }
        //[]

        //[Анимация Грядущего Спанч Боба]
        let aW21 = {}, aW22 = {}, aW23 = {}, aW24 = {}, aW25 = {}, aW26 = {}, aW27 = {}, aW28 = {}, aW29 = {}, aW210 = {}, aW211 = {}, aW212 = {}
        let fC = 0x000000, fC2 = 0xffffff
        if (cT == 2) {    
          aW21 = hmUI.createWidget(hmUI.widget.IMG, { // Правая рука
            pos_x: screenWidth / 2 - 107,
            pos_y: screenHeight - 90,
            center_x: screenHeight / 2 - 69,
            center_y: screenHeight - 77,
            w: screenWidth,
            h: screenHeight,
            src: 'images/animation/' + P[0][4] + '_1.png'
          })

          aW22 = hmUI.createWidget(hmUI.widget.IMG, { // Тело
            x: screenWidth / 2 - 89,
            y: screenHeight - 207,
            src: 'images/animation/' + P[cT][4] + '_1.png'
          })

          aW23 = hmUI.createWidget(hmUI.widget.IMG, { // Рот
            x: screenWidth / 2 - 14,
            y: screenHeight - 98,
            src: 'images/animation/' + P[cT][4] + '_2.png'
          })

          aW24 = hmUI.createWidget(hmUI.widget.IMG, { // Левая рука
            pos_x: screenWidth / 2 - 11,
            pos_y: screenHeight - 90,
            center_x: screenWidth / 2 + 82,
            center_y: screenHeight - 87,
            w: screenWidth,
            h: screenHeight,
            src: 'images/animation/' + P[cT][4] + '_3.png'
          })

          aW25 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Правый глаз
            center_x: screenWidth / 2 - 34,
            center_y: screenHeight - 150,
            radius: 32,
            color: fC2
          })

          aW26 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Правый глаз
            center_x: screenWidth / 2 - 34,
            center_y: screenHeight - 150,
            radius: 30,
            color: fC
          })

          aW27 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Правый глаз
            center_x: screenWidth / 2 - 34,
            center_y: screenHeight - 150,
            radius: 20,
            color: fC2
          })

          aW28 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Правый глаз
            center_x: screenWidth / 2 - 34,
            center_y: screenHeight - 150,
            radius: 10,
            color: fC
          })

          aW29 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Левый глаз
            center_x: screenWidth / 2 + 34,
            center_y: screenHeight - 150,
            radius: 32,
            color: fC2
          })

          aW210 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Левый глаз
            center_x: screenWidth / 2 + 34,
            center_y: screenHeight - 150,
            radius: 30,
            color: fC
          })

          aW211 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Левый глаз
            center_x: screenWidth / 2 + 34,
            center_y: screenHeight - 150,
            radius: 20,
            color: fC2
          })

          aW212 = hmUI.createWidget(hmUI.widget.CIRCLE, { // Левый глаз
            center_x: screenWidth / 2 + 34,
            center_y: screenHeight - 150,
            radius: 10,
            color: fC
          })

          aW13 = hmUI.createWidget(hmUI.widget.IMG, { // Нос
            x: screenWidth / 2 - 10,
            y: screenHeight - 148,
            src: 'images/animation/' + P[cT][4] + '_4.png'
          })
        }

        function Animation2() {
          if (count == 0) {
            fC = fC2
            fC == 0xffffff ? fC2 = 0x000000 : fC2 = 0xffffff
            aW25.setProperty(hmUI.prop.COLOR, fC)
            aW26.setProperty(hmUI.prop.COLOR, fC2)
            aW27.setProperty(hmUI.prop.COLOR, fC)
            aW28.setProperty(hmUI.prop.COLOR, fC2)
            aW29.setProperty(hmUI.prop.COLOR, fC)
            aW210.setProperty(hmUI.prop.COLOR, fC2)
            aW211.setProperty(hmUI.prop.COLOR, fC)
            aW212.setProperty(hmUI.prop.COLOR, fC2)
          }

          count < 11 ? vC = count : vC = 20 - count
          aW21.setProperty(hmUI.prop.ANGLE, vC / 2)
          aW23.setProperty(hmUI.prop.Y, screenHeight - 98 - vC / 2)
          aW24.setProperty(hmUI.prop.ANGLE, -4 + 1.3 * vC)
          aW26.setProperty(hmUI.prop.RADIUS, 30 - count / 2)
          aW27.setProperty(hmUI.prop.RADIUS, 20 - count / 2)
          aW28.setProperty(hmUI.prop.RADIUS, 10 - count / 2)
          aW210.setProperty(hmUI.prop.RADIUS, 30 - count / 2)
          aW211.setProperty(hmUI.prop.RADIUS, 20 - count / 2)
          aW212.setProperty(hmUI.prop.RADIUS, 10 - count / 2)
          
          count++
          if (count > 20) count = 0
        }
        //[]

        //[Анимация Крабса]
        let aW31 = {}
        if (cT == 3) {
          aW31 = hmUI.createWidget(hmUI.widget.IMG, { // Нос
            pos_x: screenWidth / 2 - 37,
            pos_y: screenHeight - 154,
            center_x: screenWidth / 2 - 35,
            center_y: screenHeight - 126,
            w: screenWidth,
            h: screenHeight,
            angle: 0,
            src: 'images/animation/' + P[cT][4] + '.png'
          })
        }

        function Animation3() {
          count < 10 ? vC = count : vC = 18 - count
          aW31.setProperty(hmUI.prop.ANGLE, vC)
          count++
          if (count > 18) count = 0
        }
        //[]

        //[Анимация Патрика]
        let aW41 = {}, aW42 = {}
        if (cT == 4) {
          aW41 = hmUI.createWidget(hmUI.widget.IMG, { // Правая бровь
            pos_x: screenWidth / 2 - 39,
            pos_y: screenHeight - 197,
            center_x: screenWidth / 2 - 44,
            center_y: screenHeight - 175,
            w: screenWidth,
            h: screenHeight,
            src: 'images/animation/' + P[cT][4] + '_1.png'
          })

          aW42 = hmUI.createWidget(hmUI.widget.IMG, { // Левая бровь
            pos_x: screenWidth / 2 - 3,
            pos_y: screenHeight - 199,
            center_x: screenWidth / 2 + 29,
            center_y: screenHeight - 210,
            w: screenWidth,
            h: screenHeight,
            src: 'images/animation/' + P[cT][4] + '_2.png'
          })
        }

        function Animation4() {
          count < 10 ? vC = count : vC = 18 - count
          aW41.setProperty(hmUI.prop.ANGLE, - 1.5 * vC)
          aW42.setProperty(hmUI.prop.ANGLE, 1.5 * vC)
          count++
          if (count > 18) count = 0
        }
        //[]

        //[Анимация Сквидварда]
        let aW51 = {}, aW52 = {}, aW53 = {}
        if (cT == 5) {
          aW51 = hmUI.createWidget(hmUI.widget.IMG, { // Брови
            x: screenWidth / 2 + 8,
            y: screenHeight - 159,
            src: 'images/animation/' + P[cT][4] + '_1.png'
          })

          aW52 = hmUI.createWidget(hmUI.widget.IMG, { // Веко + зрачок
            x: screenWidth / 2 - 9,
            y: screenHeight - 129,
            src: 'images/animation/' + P[cT][4] + '_2.png'
          })

          aW53 = hmUI.createWidget(hmUI.widget.IMG, { // Нос
            x: screenWidth / 2 - 30,
            y: screenHeight - 80,
            src: 'images/animation/' + P[cT][4] + '_3.png'
          })
        }

        function Animation5() {
          if (count < 5) vC = count
          else if (count < 11) vC = 10 - count
          else if (count < 16) vC = count - 11
          else if (count < 21) vC = 20 - count
          else if (count < 26) vC = count - 21
          else if (count < 31) vC = 30 - count
          else if (count < 36) vC = count - 31
          else if (count < 42) vC = 41 - count

          if (count < 31) {
            aW51.setProperty(hmUI.prop.Y, screenHeight - 159 - 0.5 * vC)
            aW52.setProperty(hmUI.prop.Y, screenHeight - 129 - 0.3 * vC)
          }
          else aW53.setProperty(hmUI.prop.Y, screenHeight - 80 - 0.5 * vC)

          count++
          if (count > 42) count = 0
        }
        //[]

        timer.createTimer(0, 50, function () {
          switch(cT) {
            case 0:
              Animation0()
              break
            case 1:
              Animation1()
              break
            case 2:
              Animation2()
              break
            case 3:
              Animation3()
              break
            case 4:
              Animation4()
              break
            case 5:
              Animation5()
              break
          }
        })
      } else {
        if (cPVT != 0) {
          hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: screenHeight - AP[cAT][0],
            src: 'images/aod/bg/' + AP[cAT][1] + '_' + pVP + '.png'
          })
        }
      }

      hmUI.createWidget(hmUI.widget.IMG, {
        x: DVC ? 45 : 38,
        y: DVC ? 33 : 25,
        src: 'images/status/background.png',
        alpha: 90,
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: DVC ? 104 : 54,
        y: DVC ? 33 : 5,
        type: hmUI.data_type.BATTERY,
        image_array: Array.from(Array(10), (v, k) => 'images/status/battery_' + k + '.png'),
        image_length: 10,
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      hmUI.createWidget(hmUI.widget.IMG_STATUS, {
        x: DVC ? 45 : 38,
        y: DVC ? 33 : 25,
        type: hmUI.system_status.DISTURB,
        src: 'images/status/dnd.png',
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      hmUI.createWidget(hmUI.widget.IMG_STATUS, {
        x: DVC ? 65 : 58,
        y: DVC ? 33 : 25,
        type: hmUI.system_status.LOCK,
        src: 'images/status/lock.png',
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      hmUI.createWidget(hmUI.widget.IMG_STATUS, {
        x: DVC ? 85 : 78,
        y: DVC ? 33 : 25,
        type: hmUI.system_status.DISCONNECT,
        src: 'images/status/dc.png',
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      let sTT = 'time', sTS = 'status'
      wfScreen ? sTT = 'time' : sTT = sTS = 'aod'

      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        hour_zero: 1,
        hour_align: hmUI.align.LEFT,
        hour_array: Array.from(Array(10), (v, k) => 'images/' + sTT + '/white_' + k + '.png'),
        hour_startX: DVC ? 92 : 100,
        hour_startY: DVC ? 67 : 7,
        hour_space: 0,
        minute_zero: 1,
        minute_align: hmUI.align.LEFT,
        minute_array: Array.from(Array(10), (v, k) => 'images/' + sTT + '/black_' + k + '.png'),
        minute_startX: DVC ? 112 : 120,
        minute_startY: DVC ? 163 : 93,
        minute_space: 0,
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      const AB7C = [[60,  60,  60,  153, 153, 60 ], // Week X
                    [125, 125, 125, 260, 190, 125], // Week Y
                    [25,  25,  25,  116, 116, 25 ], // Day X
                    [98,  98,  98,  230, 163, 98 ], // Day Y
                    [61,  61,  61,  152, 152, 61 ], // Month X
                    [98,  98,  98,  230, 163, 98 ]] // Month Y

      hmUI.createWidget(hmUI.widget.IMG_DATE, { 
        month_zero: 1,
        month_startX: DVC ? 51 : aodScreen ? cPVT == 0 ? 61 : AB7C[4][cAT] : AB7C[4][cT],
        month_startY: DVC ? 125 : aodScreen ? cPVT == 0 ? 98 : AB7C[5][cAT] : AB7C[5][cT],
        month_space: 1,
        month_align: hmUI.align.RIGHT,
        month_en_array: Array.from(Array(10), (v, k) => 'images/text/' + k + '.png'),
        month_is_character: false,
        day_zero: 0,
        day_startX: DVC ? 15 : aodScreen ? cPVT == 0 ? 25 : AB7C[2][cAT] : AB7C[2][cT],
        day_startY: DVC ? 125 : aodScreen ? cPVT == 0 ? 98 : AB7C[3][cAT] : AB7C[3][cT],
        day_spase: 1,
        day_align: hmUI.align.RIGHT,
        day_en_array: Array.from(Array(10), (v, k) => 'images/text/' + k + '.png'),
        day_unit_en: 'images/text/dot.png',
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      let lang = langIndex == 4 ? 'ru' : 'en'

      hmUI.createWidget(hmUI.widget.IMG_WEEK, { 
        x: DVC ? 50 : aodScreen ? cPVT != 0 ? AB7C[0][cAT] : 60 : AB7C[0][cT],
        y: DVC ? 98 : aodScreen ? cPVT != 0 ? AB7C[1][cAT] : 125 : AB7C[1][cT],
        week_en: Array.from(Array(7), (v, k) => 'images/text/week_' + lang + k + '.png'),
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      const TypeData = [hmUI.data_type.STEP, hmUI.data_type.HEART, hmUI.data_type.CAL, hmUI.data_type.PAI_DAILY]
      const dataWidget = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        w: 74,
        h: 22,
        font_array: Array.from(Array(10), (v, k) => 'images/text/' + k + '.png'),
        h_space: 1,
        align_h: hmUI.align.RIGHT,
        type: TypeData[eCT],
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      let dataSensor = {}, currentData = eCT == 3 ? -1 : 0
      let xCorrection = 0, yCorrection = 0, xCorrection2 = 0, yCorrection2 = 0
      let cDT = Number, iconsData = [22, 27, 22, 36, 'steps', 'heart', 'calories', 'pai']
      aodScreen ? cDT = cAT : cDT = cT

      switch (eCT) {
        case 0:
          dataSensor = hmSensor.createSensor(hmSensor.id.STEP)
          break
        case 1:
          dataSensor = hmSensor.createSensor(hmSensor.id.HEART)
          break
        case 2:
          dataSensor = hmSensor.createSensor(hmSensor.id.CALORIE)
          break
      }

      if (DVC) xCorrection = eCT == 3 ? cDT != 3 & cDT != 4 ? 60 : aodScreen & cPVT == 0 ? 60 : 101 : 101
      else xCorrection = cDT == 3 ? cPVT == 0 & aodScreen ? eCT == 3 ? 73 : 109 : 109 : eCT == 3 ? aodScreen & cPVT == 0 ? 73 : - 24 : aodScreen & cPVT == 0 ? 109 : 18
      yCorrection = DVC ? 239 : cDT == 3 | cPVT == 0 & aodScreen ? 162 : 65
      dataWidget.setProperty(hmUI.prop.X, xCorrection)
      dataWidget.setProperty(hmUI.prop.Y, yCorrection)

      const dataIcon = hmUI.createWidget(hmUI.widget.IMG, {
        x: DVC ? 175 - iconsData[eCT] : cDT == 3 & (wfScreen | aodScreen & cPVT != 0) ? xCorrection + 38 : xCorrection + 79,
        y: DVC ? eCT == 3 & (cDT == 3 | cDT == 4) ? aodScreen & cPVT == 0 ? 239 : 269 : 239 : cDT == 3  ? wfScreen | aodScreen & cPVT != 0 ? yCorrection + 30 : yCorrection : aodScreen & cPVT == 0 ? 163 : 65,
        src: `images/${sTS}/${iconsData[eCT + 4]}.png`,
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
      })

      function UpdatePDI () {
        eCT == 1 ? currentData = dataSensor.last : currentData = dataSensor.current

        dataIcon.setProperty(hmUI.prop.VISIBLE, DVC | currentData == -1 ? true : !(currentData >= 1e4 & cDT != 3 & (wfScreen | aodScreen & cPVT != 0)))

        if (DVC) {
          xCorrection2 = 175 - iconsData[eCT]
          xCorrection2 -= (cDT == 3 | cDT == 4) & (cPVT != 0 & aodScreen | wfScreen) ? 0 : currentData.toString().length * 15 + 5
          yCorrection2 = (cDT == 3 | cDT == 4) & (wfScreen | aodScreen & cPVT != 0) ? yCorrection + 30 : yCorrection
          dataIcon.setProperty(hmUI.prop.X, xCorrection2)
          dataIcon.setProperty(hmUI.prop.Y, yCorrection2)
        } else {
          if (cDT == 3) xCorrection2 = wfScreen | aodScreen & cPVT != 0 ? 183 - iconsData[eCT] : 178 - iconsData[eCT] - currentData.toString().length * 15
          else  xCorrection2 = wfScreen | aodScreen & cPVT != 0 ? 87 - iconsData[eCT] - currentData.toString().length * 15 : 178 - iconsData[eCT] - currentData.toString().length * 15
          yCorrection2 = cDT == 3 & (wfScreen | aodScreen & cPVT != 0) ? yCorrection + 30 : yCorrection
          dataIcon.setProperty(hmUI.prop.X, xCorrection2)
          dataIcon.setProperty(hmUI.prop.Y, yCorrection2)
        }
      }

      if (eCT != 3) dataSensor.addEventListener(hmSensor.event.CHANGE, function () { UpdatePDI() })

      hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: function () { if (eCT != 3) UpdatePDI() },
        pause_call: function () { console.log("ui pause") }
      })
    }

    __$$hmAppManager$$__.currentApp.current.module = DeviceRuntimeCore.WatchFace({
      onInit() {},
      build() { init_view() },
      onDestory() {}
    })
  })()
}

catch (error) { console.log(error) }