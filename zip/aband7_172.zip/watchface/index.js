﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

//////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 3
        let namecolor = ''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "Blue"}
if ( colornumber == 2) { namecolor = "Orange"}
if ( colornumber == 3) { namecolor = "Alternate"}

hmUI.showToast({text: namecolor });

             normal_background_bg_img.setProperty(hmUI.prop.SRC, "background" + parseInt(colornumber) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////



        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'background1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 9,
              y: 6,
              font_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 3,
              font_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: 'MarineRed0092.png',
              unit_tc: 'MarineRed0092.png',
              unit_en: 'MarineRed0092.png',
              negative_image: 'MarineRed0091.png',
              invalid_image: 'MarineRed0091.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 0,
              image_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 16,
              day_startY: 337,
              day_sc_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              day_tc_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              day_en_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 52,
              y: 333,
              week_en: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              week_tc: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              week_sc: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 24,
              hour_startY: 34,
              hour_array: ["0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 23,
              minute_startY: 186,
              minute_array: ["0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 34,
              w: 74,
              h: 150,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 338,
              w: 165,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 0,
              w: 94,
              h: 33,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 23,
              y: 187,
              w: 74,
              h: 150,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 101,
              y: 187,
              w: 74,
              h: 150,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



//////////////////////////////////////////////////////////////////////////////////////////////////  

          // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 24,
              y: 34,
              text: '',
              w: 74,
              h: 150,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////



                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}