(() => {
const wf = {
    isAOD: hmSetting.getScreenType() == hmSetting.screen_type.AOD,
    };

function widget0() {
    const data = {"color": 16777215, "color2": 16777215, "px": 0, "py": 0, "variant": "image", "fps": 33, "locale": "all", "userFilesCount": 1, "alpha": 255};
    const i18n = {};
    const path = (i) => "w0" + (i !== "" ? "/" : "") + i;
    const imgArray = (p, c=10) => {
        const out = [];
        for(let i = 0; i < c; i++) {
            out.push(`w0/${p}${i}.png`);
        }
        return out;
    }

    if(wf.isAOD) return;

hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: path("user_0.rgba.png")
});

;
}

function widget1() {
    const data = {"color": 5025616, "color2": 5025616, "px": 109, "py": 253, "variant": "default", "alpha": 255, "locale": "all"};
    const i18n = {};
    const path = (i) => "w1" + (i !== "" ? "/" : "") + i;
    const imgArray = (p, c=10) => {
        const out = [];
        for(let i = 0; i < c; i++) {
            out.push(`w1/${p}${i}.png`);
        }
        return out;
    }

    const font = imgArray("", 10);

hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
	center_x: data.px + 31,
	center_y: data.py + 31,
	radius: 31,
	start_angle: 0,
	end_angle: 360,
	line_width: 2,
	color: data.color,
	type: hmUI.data_type.BATTERY,
	show_level: hmUI.show_level.ONLY_NORMAL,
	_col: true,
});

hmUI.createWidget(hmUI.widget.TEXT_IMG, {
	x: data.px,
	y: data.py + 21,
	w: 62,
	type: hmUI.data_type.BATTERY,
	font_array: font,
	align_h: hmUI.align.CENTER_H,
	h_space: 1,
	show_level: hmUI.show_level.ONLY_NORMAL,
	_col: true,
});

;
}

function widget2() {
    const data = {"color": 0, "color2": 0, "px": 139, "py": 109, "variant": "default", "alpha": 180, "locale": "all"};
    const i18n = {};
    const path = (i) => "w2" + (i !== "" ? "/" : "") + i;
    const imgArray = (p, c=10) => {
        const out = [];
        for(let i = 0; i < c; i++) {
            out.push(`w2/${p}${i}.png`);
        }
        return out;
    }

    hmUI.createWidget(hmUI.widget.IMG_TIME,	{
	second_zero: 1,
	second_startX: data.px,
	second_startY: data.py,
	second_array: imgArray("", 10),
	second_space: 0,
	show_level: hmUI.show_level.ONLY_NORMAL,
	_col: true
})

;
}

function widget3() {
    const data = {"color": 13491257, "color2": 13491257, "px": 8, "py": 100, "variant": "default", "alpha": 255, "locale": "all"};
    const i18n = {};
    const path = (i) => "w3" + (i !== "" ? "/" : "") + i;
    const imgArray = (p, c=10) => {
        const out = [];
        for(let i = 0; i < c; i++) {
            out.push(`w3/${p}${i}.png`);
        }
        return out;
    }

    const hour = imgArray("hour/", 10);
const minute = imgArray("minute/", 10);

hmUI.createWidget(hmUI.widget.IMG_TIME,	{
	hour_zero: 1,
	hour_startX: data.px,
	hour_startY: data.py,
	hour_array: hour,
	hour_space: 2,
	minute_zero: 1,
	minute_startX: data.px + 119,
	minute_startY: data.py + 36,
	minute_array: minute,
	minute_space: 2,
	minute_follow: 0,
	_col: true
});

;
}

function widget4() {
    const data = {"color": 7321571, "color2": 7321571, "px": -53, "py": 207, "variant": "steps", "alpha": 255, "locale": "all"};
    const i18n = {};
    const path = (i) => "w4" + (i !== "" ? "/" : "") + i;
    const imgArray = (p, c=10) => {
        const out = [];
        for(let i = 0; i < c; i++) {
            out.push(`w4/${p}${i}.png`);
        }
        return out;
    }

    function draw(type) {
	hmUI.createWidget(hmUI.widget.TEXT_IMG, {
		x: data.px,
		y: data.py,
		w: 192,
		type,
		font_array: imgArray("", 10),
		align_h: hmUI.align.CENTER_H,
		h_space: 1,
		dot_image: path('dot.png'),
		show_level: hmUI.show_level.ONLY_NORMAL,
		_col: true,
	})
}

draw(hmUI.data_type.STEP);

;
}

function widget5() {
    const data = {"color": 7321571, "color2": 7321571, "px": 50, "py": 206, "variant": "heartrate", "alpha": 255, "locale": "all"};
    const i18n = {};
    const path = (i) => "w5" + (i !== "" ? "/" : "") + i;
    const imgArray = (p, c=10) => {
        const out = [];
        for(let i = 0; i < c; i++) {
            out.push(`w5/${p}${i}.png`);
        }
        return out;
    }

    function draw(type) {
	hmUI.createWidget(hmUI.widget.TEXT_IMG, {
		x: data.px,
		y: data.py,
		w: 192,
		type,
		font_array: imgArray("", 10),
		align_h: hmUI.align.CENTER_H,
		h_space: 1,
		dot_image: path('dot.png'),
		show_level: hmUI.show_level.ONLY_NORMAL,
		_col: true,
	})
}

draw(hmUI.data_type.HEART);

;
}

function widget6() {
    const data = {"color": 9159498, "color2": 9159498, "px": -58, "py": 271, "variant": "pai", "alpha": 255, "locale": "all"};
    const i18n = {};
    const path = (i) => "w6" + (i !== "" ? "/" : "") + i;
    const imgArray = (p, c=10) => {
        const out = [];
        for(let i = 0; i < c; i++) {
            out.push(`w6/${p}${i}.png`);
        }
        return out;
    }

    function draw(type) {
	hmUI.createWidget(hmUI.widget.TEXT_IMG, {
		x: data.px,
		y: data.py,
		w: 192,
		type,
		font_array: imgArray("", 10),
		align_h: hmUI.align.CENTER_H,
		h_space: 1,
		dot_image: path('dot.png'),
		show_level: hmUI.show_level.ONLY_NORMAL,
		_col: true,
	})
}

draw(hmUI.data_type.PAI_WEEKLY);

;
}


const app = __$$hmAppManager$$__.currentApp;
const currentApp = app.current;
currentApp.module = DeviceRuntimeCore.WatchFace({
onInit() {
widget0();
widget1();
widget2();
widget3();
widget4();
widget5();
widget6();
}
});

})();
