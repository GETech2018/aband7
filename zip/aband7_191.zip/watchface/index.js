﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_linear_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_image_progress_img_progress = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''



//////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change

        let btncolor = ''
        let colornumber = 1
        let totalcolors = 4
        let namecolor = ''

function click_Color() 
{

 if(colornumber>=totalcolors) 
    {
     colornumber=1;
    }

 else 
     {
      colornumber=colornumber+1;
     }

 if ( colornumber == 1) { namecolor = "Yellow"
                          normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
                          src: '0005.png',
                          center_x: 26,
                          center_y: 174,
                          x: 36,
                          y: 49,
                          start_angle: -38,
                          end_angle: 113,
                          type: hmUI.data_type.BATTERY,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                          });

                          normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
                          src: '0005.png',
                          center_x: 170,
                          center_y: 170,
                          x: 36,
                          y: 49,
                          start_angle: -133,
                          end_angle: -273,
                          type: hmUI.data_type.STEP,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                          });
            
                        }

 if ( colornumber == 2) { namecolor = "Green"
                          normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
                          src: '0005.green.png',
                          center_x: 26,
                          center_y: 174,
                          x: 36,
                          y: 49,
                          start_angle: -38,
                          end_angle: 113,
                          type: hmUI.data_type.BATTERY,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                          });

                          normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
                          src: '0005.green.png',
                          center_x: 170,
                          center_y: 170,
                          x: 36,
                          y: 49,
                          start_angle: -133,
                          end_angle: -273,
                          type: hmUI.data_type.STEP,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                          });
            
                        }

 if ( colornumber == 3) { namecolor = "Cyan"
                          normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
                          src: '0005.cyan.png',
                          center_x: 26,
                          center_y: 174,
                          x: 36,
                          y: 49,
                          start_angle: -38,
                          end_angle: 113,
                          type: hmUI.data_type.BATTERY,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                          });

                          normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
                          src: '0005.cyan.png',
                          center_x: 170,
                          center_y: 170,
                          x: 36,
                          y: 49,
                          start_angle: -133,
                          end_angle: -273,
                          type: hmUI.data_type.STEP,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                          });
            
                        }


 if ( colornumber == 4) { namecolor = "Purple"
                          normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
                          src: '0005.purple.png',
                          center_x: 26,
                          center_y: 174,
                          x: 36,
                          y: 49,
                          start_angle: -38,
                          end_angle: 113,
                          type: hmUI.data_type.BATTERY,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                          });

                          normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
                          src: '0005.purple.png',
                          center_x: 170,
                          center_y: 170,
                          x: 36,
                          y: 49,
                          start_angle: -133,
                          end_angle: -273,
                          type: hmUI.data_type.STEP,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                          });
            
                        }


 hmUI.showToast({text: namecolor });

 normal_background_bg_img.setProperty(hmUI.prop.SRC, "background" + parseInt(colornumber) + ".png");
                           
}

//////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'background1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 96,
              font_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              unit_sc: 'weather.0040.png',
              unit_tc: 'weather.0040.png',
              unit_en: 'weather.0040.png',
              negative_image: 'weather.0041.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 83,
              y: 266,
              image_array: ["weather.0063.png","weather.0064.png","weather.0065.png","weather.0066.png","weather.0067.png","weather.0068.png","weather.0069.png","weather.0070.png","weather.0071.png","weather.0072.png","weather.0073.png","weather.0074.png","weather.0075.png","weather.0076.png","weather.0077.png","weather.0078.png","weather.0079.png","weather.0080.png","weather.0081.png","weather.0082.png","weather.0083.png","weather.0084.png","weather.0085.png","weather.0086.png","weather.0087.png","weather.0088.png","weather.0089.png","weather.0090.png","weather.0091.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 19,
              // start_y: 148,
              // color: 0xFFEEAD0A,
              // lenght: 16,
              // line_width: 9,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0005.png',
              center_x: 26,
              center_y: 174,
              x: 36,
              y: 49,
              start_angle: -38,
              end_angle: 113,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 9,
              y: 193,
              font_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              unit_sc: '0115.png',
              unit_tc: '0115.png',
              unit_en: '0115.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0005.png',
              center_x: 170,
              center_y: 170,
              x: 36,
              y: 49,
              start_angle: -133,
              end_angle: -273,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 272,
              font_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 272,
              font_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: '0057.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [15,15,22,28,35,47,56],
              y: [102,92,82,74,72,71,71],
              image_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 84,
              day_startY: 129,
              day_sc_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              day_tc_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              day_en_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 67,
              y: 108,
              week_en: ["day.0033.png","day.0034.png","day.0035.png","day.0036.png","day.0037.png","day.0038.png","day.0039.png"],
              week_tc: ["day.0033.png","day.0034.png","day.0035.png","day.0036.png","day.0037.png","day.0038.png","day.0039.png"],
              week_sc: ["day.0033.png","day.0034.png","day.0035.png","day.0036.png","day.0037.png","day.0038.png","day.0039.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 42,
              hour_startY: 232,
              hour_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 108,
              minute_startY: 232,
              minute_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 159,
              second_startY: 234,
              second_array: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 93,
              y: 235,
              src: '0016.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0004.png',
              hour_centerX: 99,
              hour_centerY: 184,
              hour_posX: 23,
              hour_posY: 167,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0003.png',
              minute_centerX: 99,
              minute_centerY: 184,
              minute_posX: 21,
              minute_posY: 178,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0002.png',
              second_centerX: 99,
              second_centerY: 184,
              second_posX: 20,
              second_posY: 176,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0004.png',
              hour_centerX: 99,
              hour_centerY: 184,
              hour_posX: 23,
              hour_posY: 167,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0003.png',
              minute_centerX: 99,
              minute_centerY: 184,
              minute_posX: 21,
              minute_posY: 178,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 231,
              w: 114,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 107,
              w: 56,
              h: 43,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 74,
              w: 56,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 132,
              y: 145,
              w: 62,
              h: 71,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 36,
              y: 270,
              w: 124,
              h: 31,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 19;
                  let start_y_normal_battery = 148;
                  let lenght_ls_normal_battery = 16;
                  let line_width_ls_normal_battery = 9;
                  let color_ls_normal_battery = 0xFFEEAD0A;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });


//////////////////////////////////////////////////////////////////////////////////////////////////  

          // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 74,
              y: 155,
              text: '',
              w: 53,
              h: 60,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end

    
//////////////////////////////////////////////////////////////////////////////////////////////////


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}