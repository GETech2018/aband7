﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''

        let normal_digital_clock_img_time_hour = ''
        let normal_digital2_clock_img_time_hour = ''
        let normal_digital3_clock_img_time_hour = ''
        let normal_digital4_clock_img_time_hour = ''
        let normal_digital5_clock_img_time_hour = ''
        let normal_digital6_clock_img_time_hour = ''

        let idle_background_bg_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Activity select
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 3
        let cc = 0

        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }

    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Steps'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Calorie'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Distance'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //steps
        function UpdateBackgroundOne(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Calorie
        function UpdateBackgroundTwo(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Distance
        function UpdateBackgroundThree(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////

        // color select
        let btncolorfont = ''
        let colornumber = 1
        let totalcolorpictures = 6

        function click_color() {
            if(colornumber>=totalcolorpictures) {
            colornumber=1;
                UpdatecolorOne();
                }
            else {
                colornumber=colornumber+1;
                if(colornumber==2) {
                  UpdatecolorTwo();
                }
                if(colornumber==3) {
                  UpdatecolorThree();
                }
                if(colornumber==4) {
                  UpdatecolorFour();
                }
                if(colornumber==5) {
                  UpdatecolorFive();
                }
                if(colornumber==6) {
                  UpdatecolorSix();
                }
 
            }
          if(colornumber==1) hmUI.showToast({text: "Blue"});
          if(colornumber==2) hmUI.showToast({text: "Red"});
          if(colornumber==3) hmUI.showToast({text: "Yellow"});
          if(colornumber==4) hmUI.showToast({text: "Green"});
          if(colornumber==5) hmUI.showToast({text: "Rust"});
          if(colornumber==6) hmUI.showToast({text: "Black & White"});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //color change
        function UpdatecolorOne(){


        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);

        normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        function UpdatecolorTwo(){

        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);

        normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        function UpdatecolorThree(){

        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);

        normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        function UpdatecolorFour(){

        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);

        normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        function UpdatecolorFive(){

        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);

        normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        function UpdatecolorSix(){

        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);

        normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");


        }

//////////////////////////////////////////////////////////////////////////////////////////////////



        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 171,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_KM.png',
              unit_tc: 'ACT_KM.png',
              unit_en: 'ACT_KM.png',
              imperial_unit_sc: 'ACT_Mi.png',
              imperial_unit_tc: 'ACT_Mi.png',
              imperial_unit_en: 'ACT_Mi.png',
              dot_image: 'ACT_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 17,
              y: 164,
              src: 'icon_distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 171,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 18,
              y: 164,
              src: 'icon_calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 171,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 168,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 135,
              y: 287,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 290,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 41,
              y: 116,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 11,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 14,
              font_array: ["Pulse_Font_01.png","Pulse_Font_02.png","Pulse_Font_03.png","Pulse_Font_04.png","Pulse_Font_05.png","Pulse_Font_06.png","Pulse_Font_07.png","Pulse_Font_08.png","Pulse_Font_09.png","Pulse_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_Weather_Font_01.png',
              unit_tc: 'ACT_Weather_Font_01.png',
              unit_en: 'ACT_Weather_Font_01.png',
              negative_image: 'ACT_Weather_Font_02.png',
              invalid_image: 'ACT_Weather_Font_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 120,
              y: 14,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 330,
              font_array: ["Pulse_Font_01.png","Pulse_Font_02.png","Pulse_Font_03.png","Pulse_Font_04.png","Pulse_Font_05.png","Pulse_Font_06.png","Pulse_Font_07.png","Pulse_Font_08.png","Pulse_Font_09.png","Pulse_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Battery_Symob.png',
              unit_tc: 'Battery_Symob.png',
              unit_en: 'Battery_Symob.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 103,
              y: 331,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 285,
              font_array: ["Pulse_Font_01.png","Pulse_Font_02.png","Pulse_Font_03.png","Pulse_Font_04.png","Pulse_Font_05.png","Pulse_Font_06.png","Pulse_Font_07.png","Pulse_Font_08.png","Pulse_Font_09.png","Pulse_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 49,
              y: 254,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 37,
              year_startY: 226,
              year_sc_array: ["Date_Font_01.png","Date_Font_02.png","Date_Font_03.png","Date_Font_04.png","Date_Font_05.png","Date_Font_06.png","Date_Font_07.png","Date_Font_08.png","Date_Font_09.png","Date_Font_10.png"],
              year_tc_array: ["Date_Font_01.png","Date_Font_02.png","Date_Font_03.png","Date_Font_04.png","Date_Font_05.png","Date_Font_06.png","Date_Font_07.png","Date_Font_08.png","Date_Font_09.png","Date_Font_10.png"],
              year_en_array: ["Date_Font_01.png","Date_Font_02.png","Date_Font_03.png","Date_Font_04.png","Date_Font_05.png","Date_Font_06.png","Date_Font_07.png","Date_Font_08.png","Date_Font_09.png","Date_Font_10.png"],
              year_zero: 1,
              year_space: 3,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 24,
              month_startY: 210,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 105,
              y: 209,
              week_en: ["week_icon_01.png","week_icon_02.png","week_icon_03.png","week_icon_04.png","week_icon_05.png","week_icon_06.png","week_icon_07.png"],
              week_tc: ["week_icon_01.png","week_icon_02.png","week_icon_03.png","week_icon_04.png","week_icon_05.png","week_icon_06.png","week_icon_07.png"],
              week_sc: ["week_icon_01.png","week_icon_02.png","week_icon_03.png","week_icon_04.png","week_icon_05.png","week_icon_06.png","week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 127,
              day_startY: 235,
              day_sc_array: ["Date_Font_01.png","Date_Font_02.png","Date_Font_03.png","Date_Font_04.png","Date_Font_05.png","Date_Font_06.png","Date_Font_07.png","Date_Font_08.png","Date_Font_09.png","Date_Font_10.png"],
              day_tc_array: ["Date_Font_01.png","Date_Font_02.png","Date_Font_03.png","Date_Font_04.png","Date_Font_05.png","Date_Font_06.png","Date_Font_07.png","Date_Font_08.png","Date_Font_09.png","Date_Font_10.png"],
              day_en_array: ["Date_Font_01.png","Date_Font_02.png","Date_Font_03.png","Date_Font_04.png","Date_Font_05.png","Date_Font_06.png","Date_Font_07.png","Date_Font_08.png","Date_Font_09.png","Date_Font_10.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 37,
              am_y: 139,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 37,
              pm_y: 139,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 120,
              second_startY: 65,
              second_array: ["Time_min_Font_01.png","Time_min_Font_02.png","Time_min_Font_03.png","Time_min_Font_04.png","Time_min_Font_05.png","Time_min_Font_06.png","Time_min_Font_07.png","Time_min_Font_08.png","Time_min_Font_09.png","Time_min_Font_10.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 99,
              minute_startY: 106,
              minute_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

/////////////////// Hour color ///////////

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 54,
              hour_array: ["Time_H_Font_01.png","Time_H_Font_02.png","Time_H_Font_03.png","Time_H_Font_04.png","Time_H_Font_05.png","Time_H_Font_06.png","Time_H_Font_07.png","Time_H_Font_08.png","Time_H_Font_09.png","Time_H_Font_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital2_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 54,
              hour_array: ["Time_H_Font_M2_01.png","Time_H_Font_M2_02.png","Time_H_Font_M2_03.png","Time_H_Font_M2_04.png","Time_H_Font_M2_05.png","Time_H_Font_M2_06.png","Time_H_Font_M2_07.png","Time_H_Font_M2_08.png","Time_H_Font_M2_09.png","Time_H_Font_M2_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital3_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 54,
              hour_array: ["Time_H_Font_M3_01.png","Time_H_Font_M3_02.png","Time_H_Font_M3_03.png","Time_H_Font_M3_04.png","Time_H_Font_M3_05.png","Time_H_Font_M3_06.png","Time_H_Font_M3_07.png","Time_H_Font_M3_08.png","Time_H_Font_M3_09.png","Time_H_Font_M3_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital4_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 54,
              hour_array: ["Time_H_Font_M4_01.png","Time_H_Font_M4_02.png","Time_H_Font_M4_03.png","Time_H_Font_M4_04.png","Time_H_Font_M4_05.png","Time_H_Font_M4_06.png","Time_H_Font_M4_07.png","Time_H_Font_M4_08.png","Time_H_Font_M4_09.png","Time_H_Font_M4_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital5_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 54,
              hour_array: ["Time_H_Font_M5_01.png","Time_H_Font_M5_02.png","Time_H_Font_M5_03.png","Time_H_Font_M5_04.png","Time_H_Font_M5_05.png","Time_H_Font_M5_06.png","Time_H_Font_M5_07.png","Time_H_Font_M5_08.png","Time_H_Font_M5_09.png","Time_H_Font_M5_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital6_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 54,
              hour_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

/////////////////////////  end change hour color ////////////////////


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 194,
              h: 368,
              src: 'main6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 171,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 168,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 135,
              y: 287,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 290,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 41,
              y: 116,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 11,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 14,
              font_array: ["Pulse_Font_01.png","Pulse_Font_02.png","Pulse_Font_03.png","Pulse_Font_04.png","Pulse_Font_05.png","Pulse_Font_06.png","Pulse_Font_07.png","Pulse_Font_08.png","Pulse_Font_09.png","Pulse_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_Weather_Font_01.png',
              unit_tc: 'ACT_Weather_Font_01.png',
              unit_en: 'ACT_Weather_Font_01.png',
              negative_image: 'ACT_Weather_Font_02.png',
              invalid_image: 'ACT_Weather_Font_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 120,
              y: 14,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 330,
              font_array: ["Pulse_Font_01.png","Pulse_Font_02.png","Pulse_Font_03.png","Pulse_Font_04.png","Pulse_Font_05.png","Pulse_Font_06.png","Pulse_Font_07.png","Pulse_Font_08.png","Pulse_Font_09.png","Pulse_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Battery_Symob.png',
              unit_tc: 'Battery_Symob.png',
              unit_en: 'Battery_Symob.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 103,
              y: 331,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 285,
              font_array: ["Pulse_Font_01.png","Pulse_Font_02.png","Pulse_Font_03.png","Pulse_Font_04.png","Pulse_Font_05.png","Pulse_Font_06.png","Pulse_Font_07.png","Pulse_Font_08.png","Pulse_Font_09.png","Pulse_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 49,
              y: 254,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 37,
              year_startY: 226,
              year_sc_array: ["Date_Font_01.png","Date_Font_02.png","Date_Font_03.png","Date_Font_04.png","Date_Font_05.png","Date_Font_06.png","Date_Font_07.png","Date_Font_08.png","Date_Font_09.png","Date_Font_10.png"],
              year_tc_array: ["Date_Font_01.png","Date_Font_02.png","Date_Font_03.png","Date_Font_04.png","Date_Font_05.png","Date_Font_06.png","Date_Font_07.png","Date_Font_08.png","Date_Font_09.png","Date_Font_10.png"],
              year_en_array: ["Date_Font_01.png","Date_Font_02.png","Date_Font_03.png","Date_Font_04.png","Date_Font_05.png","Date_Font_06.png","Date_Font_07.png","Date_Font_08.png","Date_Font_09.png","Date_Font_10.png"],
              year_zero: 1,
              year_space: 3,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 24,
              month_startY: 210,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 105,
              y: 209,
              week_en: ["week_icon_01.png","week_icon_02.png","week_icon_03.png","week_icon_04.png","week_icon_05.png","week_icon_06.png","week_icon_07.png"],
              week_tc: ["week_icon_01.png","week_icon_02.png","week_icon_03.png","week_icon_04.png","week_icon_05.png","week_icon_06.png","week_icon_07.png"],
              week_sc: ["week_icon_01.png","week_icon_02.png","week_icon_03.png","week_icon_04.png","week_icon_05.png","week_icon_06.png","week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 127,
              day_startY: 235,
              day_sc_array: ["Date_Font_01.png","Date_Font_02.png","Date_Font_03.png","Date_Font_04.png","Date_Font_05.png","Date_Font_06.png","Date_Font_07.png","Date_Font_08.png","Date_Font_09.png","Date_Font_10.png"],
              day_tc_array: ["Date_Font_01.png","Date_Font_02.png","Date_Font_03.png","Date_Font_04.png","Date_Font_05.png","Date_Font_06.png","Date_Font_07.png","Date_Font_08.png","Date_Font_09.png","Date_Font_10.png"],
              day_en_array: ["Date_Font_01.png","Date_Font_02.png","Date_Font_03.png","Date_Font_04.png","Date_Font_05.png","Date_Font_06.png","Date_Font_07.png","Date_Font_08.png","Date_Font_09.png","Date_Font_10.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 37,
              am_y: 139,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 37,
              pm_y: 139,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 120,
              second_startY: 65,
              second_array: ["Time_min_Font_01.png","Time_min_Font_02.png","Time_min_Font_03.png","Time_min_Font_04.png","Time_min_Font_05.png","Time_min_Font_06.png","Time_min_Font_07.png","Time_min_Font_08.png","Time_min_Font_09.png","Time_min_Font_10.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 99,
              minute_startY: 106,
              minute_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 54,
              hour_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 114,
              y: 112,
              w: 49,
              h: 41,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 114,
              y: 64,
              w: 59,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 112,
              w: 44,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 3,
              w: 40,
              h: 40,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 10,
              w: 85,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 23,
              y: 251,
              w: 66,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 28,
              y: 286,
              w: 62,
              h: 23,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 105,
              y: 209,
              w: 70,
              h: 70,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 168,
              w: 146,
              h: 29,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


/////////////////Show element at the first time //////////

if (cc==0) {
  cc = 1
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);


        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);

 
}
//////////////////////////////////////////////////////////////////////////////////////////////////
 
           // Element on/off
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 10,
              y: 164,
              text: '',
              w: 45,
              h: 37,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ALL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////

          // color  select //
            btncolorfont = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 23,
              y: 55,
              text: '',
              w: 75,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_color();
              },
              show_level: hmUI.show_level.ALL,
            });
            btncolorfont.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}